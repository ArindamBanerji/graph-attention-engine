"""FastMCP - A more ergonomic interface for MCP servers."""

from __future__ import annotations

import asyncio
import logging
import secrets
from collections.abc import (
    AsyncGenerator,
    Callable,
    Sequence,
)
from contextlib import (
    AbstractAsyncContextManager,
    asynccontextmanager,
)
from functools import partial
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
    Generic,
    Literal,
    TypeVar,
    cast,
    get_args,
    overload,
)

import httpx2
import mcp_types
from mcp.server.lowlevel.server import LifespanResultT
from mcp.server.request_state import RequestStateSecurity
from mcp.shared.exceptions import MCPError
from mcp_types import (
    Annotations,
    CallToolRequestParams,
    ToolAnnotations,
)
from mcp_types.jsonrpc import MISSING_REQUIRED_CLIENT_CAPABILITY
from pydantic import AnyUrl
from pydantic import ValidationError as PydanticValidationError
from pydantic_core import ErrorType
from starlette.routing import BaseRoute
from typing_extensions import Self

import fastmcp
import fastmcp.server
from fastmcp.apps.config import (
    AppConfig,
    app_config_to_meta_dict,
    resolve_ui_mime_type,
)
from fastmcp.exceptions import (
    AuthorizationError,
    FastMCPError,
    NotFoundError,
    PromptError,
    ResourceError,
    ResourceSecurityError,
    ToolError,
    ValidationError,
)
from fastmcp.mcp_config import MCPConfig
from fastmcp.prompts import Prompt
from fastmcp.prompts.base import PromptResult
from fastmcp.prompts.function_prompt import FunctionPrompt
from fastmcp.resources.base import Resource, ResourceResult
from fastmcp.resources.security import (
    DEFAULT_RESOURCE_SECURITY,
    INHERIT_SECURITY,
    InheritSecurity,
    ResourceSecurity,
)
from fastmcp.resources.template import ResourceTemplate
from fastmcp.server.auth import AuthCheck, AuthContext, AuthProvider, run_auth_checks
from fastmcp.server.caching import build_cache_hints
from fastmcp.server.completions import CompletionHandler
from fastmcp.server.dependencies import _dispatching_tool_call
from fastmcp.server.extensions import _extension_tool_call_scope
from fastmcp.server.lifespan import Lifespan
from fastmcp.server.low_level import LowLevelServer
from fastmcp.server.middleware import CallNext, Middleware, MiddlewareContext
from fastmcp.server.middleware.middleware import (
    MiddlewarePhase,
    _dispatch_phase,
    mark_interior_dispatched,
)
from fastmcp.server.middleware.tool_injection import ToolInjectionMiddleware
from fastmcp.server.mixins import LifespanMixin, MCPOperationsMixin, TransportMixin
from fastmcp.server.mixins.extensions import ExtensionsMixin
from fastmcp.server.providers import LocalProvider, Provider
from fastmcp.server.providers.addressing import (
    parse_hashed_backend_name,
    tool_identity,
)
from fastmcp.server.providers.aggregate import AggregateProvider
from fastmcp.server.providers.base import hashed_lookup_target
from fastmcp.server.telemetry import server_span
from fastmcp.server.transforms import (
    ToolTransform,
    Transform,
)
from fastmcp.server.transforms.visibility import apply_session_transforms, is_enabled
from fastmcp.settings import DuplicateBehavior as DuplicateBehaviorSetting
from fastmcp.tools.base import Tool, ToolResult
from fastmcp.tools.function_tool import FunctionTool
from fastmcp.tools.tool_transform import ToolTransformConfig
from fastmcp.utilities.components import FastMCPComponent, _coerce_version
from fastmcp.utilities.exceptions import get_http_status_code, is_timeout_error
from fastmcp.utilities.logging import get_logger
from fastmcp.utilities.tasks import TaskConfig
from fastmcp.utilities.types import AnyFunction, FastMCPBaseModel, NotSet, NotSetT
from fastmcp.utilities.versions import (
    VersionSpec,
    version_sort_key,
)

if TYPE_CHECKING:
    from key_value.aio.adapters.pydantic import PydanticAdapter
    from key_value.aio.protocols import AsyncKeyValue

    from fastmcp.client import Client
    from fastmcp.client.client import SDKServer
    from fastmcp.client.transports import ClientTransport, ClientTransportT
    from fastmcp.server.extensions import ServerExtension
    from fastmcp.server.providers.openapi import ComponentFn as OpenAPIComponentFn
    from fastmcp.server.providers.openapi import RouteMap
    from fastmcp.server.providers.openapi import RouteMapFn as OpenAPIRouteMapFn
    from fastmcp.server.providers.proxy import FastMCPProxy

logger = get_logger(__name__)

_BUILTIN_VALIDATION_ERROR_TYPES = frozenset(get_args(ErrorType))


def _validation_error_summary(error: PydanticValidationError) -> dict[str, Any]:
    """Keep counts and built-in codes, never input-derived validation details."""
    error_types = {
        detail["type"]
        if detail["type"] in _BUILTIN_VALIDATION_ERROR_TYPES
        else "custom_error"
        for detail in error.errors(
            include_url=False, include_context=False, include_input=False
        )
    }
    return {"error_count": error.error_count(), "error_types": sorted(error_types)}


def _version_request_meta(
    version: VersionSpec | None,
) -> mcp_types.RequestParamsMeta | None:
    if version is None:
        return None

    if version.eq is not None and version.gte is None and version.lt is None:
        version_value: str | dict[str, str] = version.eq
    else:
        version_value = {
            key: value
            for key, value in {
                "gte": version.gte,
                "lt": version.lt,
                "eq": version.eq,
            }.items()
            if value is not None
        }

    if not version_value:
        return None

    # RequestParamsMeta does not declare application-specific extension keys.
    return {"fastmcp": {"version": version_value}}


# The MCP SDK warns "Tool X not listed, no validation will be performed"
# for every call addressed by hashed backend name, since that address is
# an identity rather than a listed tool name. This fires even when
# validate_input=False. Suppress it.
class _SuppressUnlistedToolWarning(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        return "not listed, no validation" not in record.getMessage()


logging.getLogger("mcp.server.lowlevel.server").addFilter(
    _SuppressUnlistedToolWarning()
)

F = TypeVar("F", bound=Callable[..., Any])

DuplicateBehavior = Literal["warn", "error", "replace", "ignore"]


_REMOVED_KWARGS: dict[str, str] = {
    "host": "Pass `host` to `run_http_async()`, or set FASTMCP_HOST.",
    "port": "Pass `port` to `run_http_async()`, or set FASTMCP_PORT.",
    "sse_path": "Pass `path` to `run_http_async()` or `http_app()`, or set FASTMCP_SSE_PATH.",
    "message_path": "Set FASTMCP_MESSAGE_PATH.",
    "streamable_http_path": "Pass `path` to `run_http_async()` or `http_app()`, or set FASTMCP_STREAMABLE_HTTP_PATH.",
    "json_response": "Pass `json_response` to `run_http_async()` or `http_app()`, or set FASTMCP_JSON_RESPONSE.",
    "stateless_http": "Pass `stateless_http` to `run_http_async()` or `http_app()`, or set FASTMCP_STATELESS_HTTP.",
    "debug": "Set FASTMCP_DEBUG.",
    "log_level": "Pass `log_level` to `run_http_async()`, or set FASTMCP_LOG_LEVEL.",
    "on_duplicate_tools": "Use `on_duplicate=` instead.",
    "on_duplicate_resources": "Use `on_duplicate=` instead.",
    "on_duplicate_prompts": "Use `on_duplicate=` instead.",
    "tool_serializer": "Return ToolResult from your tools instead. See https://gofastmcp.com/servers/tools#custom-serialization",
    "include_tags": "Use `server.enable(tags=..., only=True)` after creating the server.",
    "exclude_tags": "Use `server.disable(tags=...)` after creating the server.",
    "tool_transformations": "Use `server.add_transform(ToolTransform(...))` after creating the server.",
    "sampling_handler": "Server-initiated sampling is deprecated in MCP (SEP-2577) and the 2026-07-28 protocol has no back-channel for it (SEP-2322). Call an LLM directly from your tool.",
    "sampling_handler_behavior": "Server-initiated sampling is deprecated in MCP (SEP-2577) and the 2026-07-28 protocol has no back-channel for it (SEP-2322). Call an LLM directly from your tool.",
}


def _check_removed_kwargs(kwargs: dict[str, Any]) -> None:
    """Raise helpful TypeErrors for kwargs FastMCP no longer accepts."""
    for key in kwargs:
        if key in _REMOVED_KWARGS:
            raise TypeError(
                f"FastMCP() no longer accepts `{key}`. {_REMOVED_KWARGS[key]}"
            )
    if kwargs:
        raise TypeError(
            f"FastMCP() got unexpected keyword argument(s): {', '.join(repr(k) for k in kwargs)}"
        )


Transport = Literal["stdio", "http", "sse", "streamable-http"]


LifespanCallable = Callable[
    ["FastMCP[LifespanResultT]"], AbstractAsyncContextManager[LifespanResultT]
]


async def _component_auth_allows(
    component: Tool | Resource | ResourceTemplate | Prompt,
) -> bool:
    """Whether the component's own `auth` check admits the current request."""
    skip_auth, token = _get_auth_context()
    if skip_auth or component.auth is None:
        return True
    ctx = AuthContext(token=token, component=component)
    try:
        return await run_auth_checks(component.auth, ctx)
    except AuthorizationError:
        return False


def _get_auth_context() -> tuple[bool, Any]:
    """Get auth context for the current request.

    Returns a tuple of (skip_auth, token) where:
    - skip_auth=True means auth checks should be skipped (STDIO transport)
    - token is the access token for HTTP transports (may be None if unauthenticated)

    Uses late import to avoid circular import with context.py.
    """
    from fastmcp.server.context import _current_transport

    is_stdio = _current_transport.get() == "stdio"
    if is_stdio:
        # STDIO trusts the local execution environment; component authorization
        # provides no access restriction on this transport.
        return (True, None)
    from fastmcp.server.dependencies import get_access_token

    return (False, get_access_token())


@asynccontextmanager
async def default_lifespan(
    server: FastMCP[LifespanResultT],
) -> AsyncGenerator[Any, None]:
    """Default lifespan context manager that does nothing.

    Args:
        server: The server instance this lifespan is managing

    Returns:
        An empty dictionary as the lifespan result.
    """
    yield {}


def _lifespan_proxy(
    fastmcp_server: FastMCP[LifespanResultT],
) -> Callable[
    [LowLevelServer[LifespanResultT]], AbstractAsyncContextManager[LifespanResultT]
]:
    @asynccontextmanager
    async def wrap(
        low_level_server: LowLevelServer[LifespanResultT],
    ) -> AsyncGenerator[LifespanResultT, None]:
        # Drive the FastMCP lifespan rather than merely reading it back. The
        # SDK enters this proxy exactly once per manager/server run (via
        # ``StreamableHTTPSessionManager.run`` → ``app.lifespan(app)`` or
        # ``Server.run`` → ``self.lifespan(self)``) and reuses the yielded
        # state for every session. ``_lifespan_manager`` is ref-counted, so
        # when an outer caller (``run_http_async``/``run_stdio_async``) has
        # already entered it, this nested entry reuses the existing result
        # instead of re-running setup.
        async with fastmcp_server._lifespan_manager():
            yield fastmcp_server._lifespan_result  # ty:ignore[invalid-yield]

    return wrap


class StateValue(FastMCPBaseModel):
    """Wrapper for stored context state values."""

    value: Any


class FastMCP(
    AggregateProvider,
    ExtensionsMixin,
    LifespanMixin,
    MCPOperationsMixin,
    TransportMixin,
    Generic[LifespanResultT],
):
    def __init__(
        self,
        name: str | None = None,
        instructions: str | None = None,
        *,
        version: str | int | float | None = None,
        website_url: str | None = None,
        icons: list[mcp_types.Icon] | None = None,
        auth: AuthProvider | None = None,
        middleware: Sequence[Middleware] | None = None,
        providers: Sequence[Provider] | None = None,
        transforms: Sequence[Transform] | None = None,
        lifespan: LifespanCallable | Lifespan | None = None,
        tools: Sequence[Tool | Callable[..., Any]] | None = None,
        on_duplicate: DuplicateBehavior | None = None,
        mask_error_details: bool | None = None,
        dereference_schemas: bool = True,
        strict_input_validation: bool | None = None,
        list_page_size: int | None = None,
        resource_security: ResourceSecurity | None = DEFAULT_RESOURCE_SECURITY,
        request_state_security: RequestStateSecurity | None = None,
        cache_ttl: int | None = None,
        cache_scope: Literal["public", "private"] | None = None,
        tasks: bool | None = None,
        session_state_store: AsyncKeyValue | None = None,
        client_log_level: mcp_types.LoggingLevel | None = None,
        experimental_capabilities: dict[str, dict[str, Any]] | None = None,
        **kwargs: Any,
    ):
        _check_removed_kwargs(kwargs)

        # Initialize Provider (sets up _transforms)
        super().__init__()

        self._on_duplicate: DuplicateBehaviorSetting = on_duplicate or "warn"

        # Resolve server default for background task support
        self._support_tasks_by_default: bool = tasks if tasks is not None else False

        # Docket and Worker instances (set during lifespan for cross-task access)
        self._docket = None
        self._worker = None

        self._additional_http_routes: list[BaseRoute] = []

        # Session-scoped state store (shared across all requests)
        self._state_storage: AsyncKeyValue | None = session_state_store
        self.__state_store: PydanticAdapter[StateValue] | None = None

        # Create LocalProvider for local components
        self._local_provider: LocalProvider = LocalProvider(
            on_duplicate=self._on_duplicate
        )

        for t in transforms or []:
            self.add_transform(t)

        # Store mask_error_details for execution error handling
        self._mask_error_details: bool = (
            mask_error_details
            if mask_error_details is not None
            else fastmcp.settings.mask_error_details
        )

        # Store list_page_size for pagination of list operations
        if list_page_size is not None and list_page_size <= 0:
            raise ValueError("list_page_size must be a positive integer")
        self._list_page_size: int | None = list_page_size

        # Server-wide default path-security policy for templated resources.
        # Applied before the handler runs to every templated read whose
        # component does not override it. DEFAULT_RESOURCE_SECURITY screens
        # traversal, absolute paths, and null bytes; None disables screening
        # server-wide.
        self._resource_security: ResourceSecurity | None = resource_security

        # Server-level integrity policy for the multi-round-trip `requestState`
        # (SEP-2322). Consumed by the low-level server, which installs the SDK's
        # `RequestStateBoundary` middleware to seal every outgoing
        # `InputRequiredResult.request_state` and unseal every inbound echo.
        # None means "seal under a per-process ephemeral key" — correct for
        # single-process deployments; multi-replica deployments must pass a
        # policy carrying shared `keys=[...]`.
        if (
            request_state_security is not None
            and request_state_security.audience is None
            and not name  # None or "" both yield a random per-replica name
        ):
            # The request-state boundary stamps an audience claim, defaulting to
            # the server name — which is auto-generated (random) when unnamed, so
            # a shared-key multi-replica policy would mint tokens no other
            # replica accepts. A policy object can't reveal whether its keys are
            # shared (ephemeral and shared-key policies both collapse into a
            # codec), so single-process customization stays allowed and the
            # multi-replica footgun is a warning, not an error.
            logger.warning(
                "request_state_security was provided without an audience on an "
                "unnamed server; if this policy's keys are shared across "
                "replicas, sealed request state will not verify between them. "
                "Pass FastMCP(name=...) or RequestStateSecurity(audience=...) "
                "for a stable audience."
            )
        self._request_state_security: RequestStateSecurity | None = (
            request_state_security
        )

        # Server-level SEP-2549 cache hints, applied uniformly to every
        # SDK-cacheable result by the low-level server's runner (raises on
        # invalid ttl/scope).
        cache_hints = build_cache_hints(cache_ttl, cache_scope)

        # Handle Lifespan instances (they're callable) or regular lifespan functions
        if lifespan is not None:
            self._lifespan: LifespanCallable[LifespanResultT] = cast(
                LifespanCallable[LifespanResultT], lifespan
            )
        else:
            self._lifespan = cast(LifespanCallable[LifespanResultT], default_lifespan)
        self._lifespan_result: LifespanResultT | None = None
        self._lifespan_result_set: bool = False
        # Snapshot of SharedContext ContextVar values captured during the
        # lifespan, re-applied per request by FastMCPServerMiddleware because
        # the SDK v2 dispatcher runs handlers in the sender's context.
        self._shared_context_snapshot: dict[Any, Any] | None = None
        self._lifespan_ref_count: int = 0
        self._lifespan_lock: asyncio.Lock = asyncio.Lock()
        self._started: asyncio.Event = asyncio.Event()

        # Generate random ID if no name provided
        self._mcp_server: LowLevelServer[LifespanResultT] = LowLevelServer[
            LifespanResultT
        ](
            fastmcp=self,
            name=name or self.generate_name(),
            version=_coerce_version(version) or fastmcp.__version__,
            instructions=instructions,
            website_url=website_url,
            icons=icons,
            lifespan=_lifespan_proxy(fastmcp_server=self),
            cache_hints=cache_hints,
        )

        self.auth: AuthProvider | None = auth

        if tools:
            for tool in tools:
                if not isinstance(tool, Tool):
                    tool = Tool.from_function(tool)
                self.add_tool(tool)

        self.strict_input_validation: bool = (
            strict_input_validation
            if strict_input_validation is not None
            else fastmcp.settings.strict_input_validation
        )

        self.client_log_level: mcp_types.LoggingLevel | None = (
            client_log_level
            if client_log_level is not None
            else fastmcp.settings.client_log_level
        )

        # Per-session minimum log level requested by clients via logging/setLevel.
        # Keyed by session id (a sentinel for stdio where session_id is None).
        # v2 sessions are per-request so this state lives on the server, not the
        # session object.
        self._client_log_levels: dict[str, mcp_types.LoggingLevel] = {}

        self.experimental_capabilities: dict[str, dict[str, Any]] = (
            experimental_capabilities or {}
        )

        # Server-level argument completion handler (set via @mcp.completion).
        # The completions capability is declared only once this is set, because
        # add_completion_handler registers the low-level completion/complete
        # handler at that point (the SDK derives the capability from the handler).
        self._completion_handler: CompletionHandler | None = None

        self.middleware: list[Middleware] = list(middleware or [])

        # Registered server extensions (SEP-2133), keyed by reverse-DNS
        # identifier. Populated by add_extension; consumed by the low-level
        # server (capability advertisement), the tool-call path (interception),
        # and the lifespan manager (extension lifespans).
        self._extensions: dict[str, ServerExtension] = {}
        self._auto_extensions: set[str] = set()
        self._extension_methods: dict[str, tuple[str, ...]] = {}
        self._extension_conflicts: set[str] = set()
        self._extensions_started = False

        # Add providers using AggregateProvider's add_provider
        # LocalProvider is always first (no namespace)
        self.add_provider(self._local_provider)
        for p in providers or []:
            self.add_provider(p)

        if dereference_schemas:
            from fastmcp.server.middleware.dereference import (
                DereferenceRefsMiddleware,
            )

            self.middleware.append(DereferenceRefsMiddleware())

        # Set up MCP protocol handlers
        self._setup_handlers()

    def __repr__(self) -> str:
        return f"{type(self).__name__}({self.name!r})"

    @property
    def _state_store(self) -> PydanticAdapter[StateValue]:
        """Create the session-state adapter only when state is first used."""
        if self.__state_store is None:
            from key_value.aio.adapters.pydantic import PydanticAdapter
            from key_value.aio.stores.memory import MemoryStore

            if self._state_storage is None:
                self._state_storage = MemoryStore()
            self.__state_store = PydanticAdapter[StateValue](
                key_value=self._state_storage,
                pydantic_model=StateValue,
                default_collection="fastmcp_state",
            )
        return self.__state_store

    @property
    def name(self) -> str:
        return self._mcp_server.name

    @property
    def instructions(self) -> str | None:
        return self._mcp_server.instructions

    @instructions.setter
    def instructions(self, value: str | None) -> None:
        self._mcp_server.instructions = value

    @property
    def version(self) -> str | None:
        return self._mcp_server.version

    @property
    def website_url(self) -> str | None:
        return self._mcp_server.website_url

    @property
    def icons(self) -> list[mcp_types.Icon]:
        if self._mcp_server.icons is None:
            return []
        else:
            return list(self._mcp_server.icons)

    @property
    def local_provider(self) -> LocalProvider:
        """The server's local provider, which stores directly-registered components.

        Use this to remove components:

            mcp.local_provider.remove_tool("my_tool")
            mcp.local_provider.remove_resource("data://info")
            mcp.local_provider.remove_prompt("my_prompt")
        """
        return self._local_provider

    async def _run_middleware(
        self,
        context: MiddlewareContext[Any],
        call_next: CallNext[Any, Any],
        *,
        phase: MiddlewarePhase = "all",
    ) -> Any:
        """Builds and executes the middleware chain for a single dispatch phase.

        ``phase`` selects whether a pass runs only the method-agnostic hooks
        (``"outer"``, at the root dispatch) or only the typed per-method hook
        (``"typed"``, interior); it defaults to ``"all"`` for the direct
        programmatic path. It is conveyed through the ``_dispatch_phase``
        ContextVar rather than the middleware call signature, so user middleware
        overriding the documented ``__call__(context, call_next)`` is unaffected.
        """
        chain = call_next
        for mw in reversed(self.middleware):
            next_chain: CallNext[Any, Any] = chain

            async def wrapped(
                context: MiddlewareContext[Any],
                mw: Middleware = mw,
                call_next: CallNext[Any, Any] = next_chain,
            ) -> Any:
                return await mw(context, call_next)

            chain = cast(CallNext[Any, Any], wrapped)
        token = _dispatch_phase.set(phase)
        try:
            return await chain(context)
        finally:
            _dispatch_phase.reset(token)

    async def _dispatch_component_middleware(
        self,
        context: MiddlewareContext[Any],
        call_next: CallNext[Any, Any],
    ) -> Any:
        """Run the interior middleware chain for a component operation.

        This is the dispatch site for the component methods (``tools/call``,
        ``tools/list``, ``resources/read``, ...). It runs the whole FastMCP chain
        (``on_message`` -> ``on_request`` -> the typed per-method hook) in one
        pass, so error-observing middleware see a tool exception propagate through
        ``on_message``/``on_request`` exactly as they always have. It also records
        (via ``mark_interior_dispatched``) that the chain fired for this wire
        message, so the root dispatch knows not to observe it a second
        time.
        """
        mark_interior_dispatched()
        return await self._run_middleware(context, call_next, phase="all")

    def add_middleware(self, middleware: Middleware) -> None:
        self.middleware.append(middleware)

    def _injected_tools(self) -> list[Tool]:
        """Tools added by `ToolInjectionMiddleware`, one per name.

        Each name maps to the tool `_get_injected_tool()` resolves for it: the
        one from the outermost middleware that injects that name.
        """
        by_name: dict[str, Tool] = {}
        for middleware in self.middleware:
            if isinstance(middleware, ToolInjectionMiddleware):
                for tool in middleware.injected_tools:
                    by_name.setdefault(tool.name, tool)
        return list(by_name.values())

    def _get_injected_tool(self, name: str) -> Tool | None:
        """The injected tool with this name from the outermost middleware that has one."""
        for middleware in self.middleware:
            if isinstance(middleware, ToolInjectionMiddleware):
                tool = middleware.get_injected_tool(name)
                if tool is not None:
                    return tool
        return None

    def required_extensions(self) -> Sequence[ServerExtension]:
        """Bundled extensions and auto-registerable registrations for composition."""
        return self._required_extensions()

    def add_provider(self, provider: Provider, *, namespace: str = "") -> None:
        """Add a provider for dynamic tools, resources, and prompts.

        Providers are queried in registration order. The first provider to return
        a non-None result wins. Static components (registered via decorators)
        always take precedence over providers.

        Args:
            provider: A Provider instance that will provide components dynamically.
            namespace: Optional namespace prefix. When set:
                - Tools become "namespace_toolname"
                - Resources become "protocol://namespace/path"
                - Prompts become "namespace_promptname"
        """
        self._validate_provider_extensions(provider)
        self._register_provider_extensions(provider)
        super().add_provider(provider, namespace=namespace)

    def _rewrite_prefab_uris(self, tools: list[Tool]) -> list[Tool]:
        """Replace placeholder Prefab URIs with per-tool hashed ones.

        For each tool whose ``meta.ui.resourceUri`` is the placeholder,
        reads the tool's stored hash from ``meta.fastmcp.tool_hash``
        and rewrites the URI to the per-tool form. Also strips CSP from
        tool meta (it belongs on the resource). Produces ``model_copy``
        views — originals are untouched.
        """
        from fastmcp.server.providers.prefab_synthesis import (
            _is_prefab_tool,
            rewrite_tool_meta_for_wire,
        )

        return [
            rewrite_tool_meta_for_wire(t) if _is_prefab_tool(t) else t for t in tools
        ]

    async def _rebind_prefab_tool_names(self, result: Any) -> Any:
        """Re-address a Prefab payload's tool references to this server's names.

        Runs on the way out of every ``tools/call``, above the middleware
        chain so a payload is re-addressed however it was produced. Servers
        unwind innermost-first, so the outermost server rewrites last and its
        names — the only ones a client can actually invoke — are what ship.

        A call does not always answer with a tool result: submitting a task
        answers with the task's metadata. Anything that is not a tool result
        passes through untouched.

        An identity claimed by more than one tool is not bound. That happens
        when one app is composed into a server twice, which leaves no fact
        anywhere in the listing that says which copy a UI belongs to. The
        reference keeps its identity-addressed form, and the dispatcher
        reports the ambiguity rather than binding to a coin flip.
        """
        from fastmcp.server.providers.prefab_payload import (
            payload_has_identities,
            rewrite_payload_tool_names,
        )

        if not isinstance(result, ToolResult):
            return result

        payload = result.structured_content
        if not payload_has_identities(payload):
            return result

        # Binding is safe only where one identity, one name, and one
        # component all agree. Each is tracked separately: collapsing them
        # early is what lets a duplicated app pass as a single tool.
        #
        # The middleware chain runs, because the binding has to describe the
        # listing a client will actually see. Middleware adds, removes and
        # shadows tools — an injected tool sharing a backend's name owns that
        # name at call time, and a listing taken beneath middleware would not
        # know it exists.
        claimed_by: dict[str, list[Tool]] = {}
        owners_of: dict[str, set[str | None]] = {}
        for tool in await self.list_tools():
            identity = tool_identity(tool)
            owners_of.setdefault(tool.name, set()).add(identity)
            if identity is not None:
                claimed_by.setdefault(identity, []).append(tool)

        def resolve(identity: str) -> str | None:
            tools = claimed_by.get(identity, [])
            names = {tool.name for tool in tools}
            if len(names) != 1:
                # Several names carry this identity: the app is composed more
                # than once and nothing says which copy the UI belongs to.
                return None

            # One name can still be several components. `key` is the canonical
            # identity — type, name and version — so versions of one tool have
            # distinct keys while copies of one app repeat a key. A repeat
            # means two components are indistinguishable, which is worse than
            # the renamed case, not better.
            if len({tool.key for tool in tools}) != len(tools):
                return None

            (name,) = names
            # And the name has to lead back. Two apps can each expose `save`,
            # or a plain tool can share the name — binding then hands one
            # app's button to someone else's implementation.
            return name if owners_of.get(name) == {identity} else None

        rewrite_payload_tool_names(payload, resolve)
        return result

    # -------------------------------------------------------------------------
    # Provider interface overrides - inherited from AggregateProvider
    # -------------------------------------------------------------------------
    # _list_tools, _list_resources, _list_resource_templates, _list_prompts
    # are inherited from AggregateProvider which handles aggregation and namespacing

    async def get_tasks(self) -> Sequence[FastMCPComponent]:
        """Get task-eligible components with server-level transforms applied.

        Overrides AggregateProvider.get_tasks() to apply server-level transforms
        after aggregation. AggregateProvider handles provider-level namespacing.
        """
        # Get tasks from AggregateProvider (handles aggregation and namespacing)
        components = list(await super().get_tasks())

        # An injected tool owns its name, as in `list_tools()` and
        # `get_tool()`: tools with that name are not registered, so the
        # injected tool is the only one that runs as a background task.
        injected = self._injected_tools()
        claimed = {tool.name for tool in injected}

        return [
            *[t for t in injected if t.task_config.supports_tasks()],
            *[
                c
                for c in await self._apply_task_transforms(components)
                if c.task_config.supports_tasks()
                and not (isinstance(c, Tool) and c.name in claimed)
            ],
        ]

    def add_transform(self, transform: Transform) -> None:
        """Add a server-level transform.

        Server-level transforms are applied after all providers are aggregated.
        They transform tools, resources, and prompts from ALL providers.

        Args:
            transform: The transform to add.

        Example:
            ```python
            from fastmcp.server.transforms import Namespace

            server = FastMCP("Server")
            server.add_transform(Namespace("api"))
            # All tools from all providers become "api_toolname"
            ```
        """
        self._transforms.append(transform)

    async def list_tools(self, *, run_middleware: bool = True) -> Sequence[Tool]:
        """List all enabled tools from providers.

        Overrides Provider.list_tools() to add enabled filtering, auth filtering,
        and middleware execution. Returns all versions (no deduplication).
        Protocol handlers deduplicate for MCP wire format.
        """
        async with fastmcp.server.context.Context(fastmcp=self) as ctx:
            if run_middleware:
                mw_context = MiddlewareContext(
                    message=mcp_types.ListToolsRequest(method="tools/list"),
                    source="client",
                    type="request",
                    method="tools/list",
                    fastmcp_context=ctx,
                )
                return await self._dispatch_component_middleware(
                    context=mw_context,
                    call_next=lambda context: self.list_tools(run_middleware=False),
                )

            # Core logic: list tools
            with server_span("tools/list", "tools/list", self.name, "tool", ""):
                # Get all tools, apply session transforms, then filter enabled.
                # App-only tools (meta.ui.visibility == ["app"]) are listed:
                # the mcp-apps spec puts visibility filtering on the host, and
                # a tool absent from tools/list cannot be forwarded by any
                # intermediary that routes by name.
                tools = list(await super().list_tools())
                tools = await apply_session_transforms(tools)
                tools = [t for t in tools if is_enabled(t)]

                # Rewrite per-tool Prefab renderer URIs based on the tool's
                # mount-point address. The walk pairs each tool with the
                # provider that yielded it, computes the hashed URI, and
                # produces a model_copy with the URI in place. Original
                # Tool objects are not mutated.
                tools = self._rewrite_prefab_uris(tools)

                # Tools from ToolInjectionMiddleware are listed ahead of the
                # providers' tools and authorized the same way. An injected
                # tool owns its name, so provider tools with that name are not
                # listed, matching what `get_tool()` resolves.
                injected = self._injected_tools()
                claimed = {tool.name for tool in injected}
                tools = [*injected, *(t for t in tools if t.name not in claimed)]

                return [tool for tool in tools if await _component_auth_allows(tool)]

    async def _get_tool(
        self, name: str, version: VersionSpec | None = None
    ) -> Tool | None:
        """Get a tool by name via aggregation from providers.

        Extends AggregateProvider._get_tool() with component-level auth checks.

        Args:
            name: The tool name.
            version: Version filter (None returns highest version).

        Returns:
            The tool if found and authorized, None if not found or unauthorized.
        """
        # Get tool from AggregateProvider (handles aggregation and namespacing)
        tool = await super()._get_tool(name, version)
        if tool is None:
            return None

        # Component auth - return None if unauthorized (consistent with list filtering)
        return tool if await _component_auth_allows(tool) else None

    async def _check_hashed_target(self, tool: Tool) -> Tool | None:
        """Check auth on the found tool, as `_get_tool()` does for a name."""
        return tool if await _component_auth_allows(tool) else None

    async def get_tool(
        self, name: str, version: VersionSpec | None = None
    ) -> Tool | None:
        """Get a tool by name, filtering disabled tools.

        Overrides Provider.get_tool() to filter disabled tools after all
        transforms (including session-level) have been applied. This ensures
        session transforms can override provider-level disables.

        When the highest version is disabled and no explicit version was
        requested, falls back to the next-highest enabled version.

        A tool from `ToolInjectionMiddleware` takes precedence over a provider
        tool with the same name. It is matched by name alone, so a requested
        version is ignored, and it is subject to its own `auth` check but not
        to transforms or visibility.

        Args:
            name: The tool name.
            version: Version filter (None returns highest version).

        Returns:
            The tool if found, enabled, and authorized, None otherwise.
        """
        # A hashed lookup resolves one identity; injected tools have none.
        injected = (
            self._get_injected_tool(name)
            if hashed_lookup_target(self) is None
            else None
        )
        if injected is not None:
            return injected if await _component_auth_allows(injected) else None

        tool = await super().get_tool(name, version)
        if tool is None:
            return None

        # Apply session transforms to single item
        tools = await apply_session_transforms([tool])
        # Transforms can change what `auth` sees (a tag, for one), so the check made
        # on the pre-transform component is not enough.
        if tools and is_enabled(tools[0]) and await _component_auth_allows(tools[0]):
            return tools[0]

        # The highest version is disabled. If an explicit version was
        # requested, respect that. Otherwise fall back to the next-highest
        # enabled version.
        if version is not None:
            return None

        all_tools = [t for t in await super().list_tools() if t.name == name]
        # During a hashed lookup, only versions of the identity being looked
        # up qualify; another tool listed under the same name does not.
        found = hashed_lookup_target(self)
        if found is not None:
            identity = tool_identity(found)
            all_tools = [t for t in all_tools if tool_identity(t) == identity]
        all_tools = list(await apply_session_transforms(all_tools))
        enabled = [t for t in all_tools if is_enabled(t)]

        authorized = [t for t in enabled if await _component_auth_allows(t)]

        if not authorized:
            return None
        return max(authorized, key=version_sort_key)

    async def list_resources(
        self, *, run_middleware: bool = True
    ) -> Sequence[Resource]:
        """List all enabled resources from providers.

        Overrides Provider.list_resources() to add visibility filtering, auth filtering,
        and middleware execution. Returns all versions (no deduplication).
        Protocol handlers deduplicate for MCP wire format.
        """
        async with fastmcp.server.context.Context(fastmcp=self) as ctx:
            if run_middleware:
                mw_context = MiddlewareContext(
                    message={},
                    source="client",
                    type="request",
                    method="resources/list",
                    fastmcp_context=ctx,
                )
                return await self._dispatch_component_middleware(
                    context=mw_context,
                    call_next=lambda context: self.list_resources(run_middleware=False),
                )

            # Core logic: list resources
            with server_span(
                "resources/list", "resources/list", self.name, "resource", ""
            ):
                # Get all resources, apply session transforms, then filter enabled
                resources = list(await super().list_resources())
                resources = await apply_session_transforms(resources)
                resources = [r for r in resources if is_enabled(r)]

                # Append synthetic Prefab renderer resources — one per
                # prefab tool, hashed by mount address. These don't live on
                # any provider's storage; they're computed on demand.
                from fastmcp.server.providers.prefab_synthesis import (
                    synthesize_prefab_resources,
                )

                resources.extend(await synthesize_prefab_resources(self))

                skip_auth, token = _get_auth_context()
                authorized: list[Resource] = []
                for resource in resources:
                    if not skip_auth and resource.auth is not None:
                        ctx = AuthContext(token=token, component=resource)
                        try:
                            if not await run_auth_checks(resource.auth, ctx):
                                continue
                        except AuthorizationError:
                            continue
                    authorized.append(resource)
                return authorized

    async def _get_resource(
        self, uri: str, version: VersionSpec | None = None
    ) -> Resource | None:
        """Get a resource by URI via aggregation from providers.

        Extends AggregateProvider._get_resource() with component-level auth checks.

        Args:
            uri: The resource URI.
            version: Version filter (None returns highest version).

        Returns:
            The resource if found and authorized, None if not found.

        Raises:
            AuthorizationError: The resource exists but access is denied.
        """
        # Get resource from AggregateProvider (handles aggregation and namespacing)
        resource = await super()._get_resource(uri, version)
        if resource is None:
            return None

        if not await _component_auth_allows(resource):
            raise AuthorizationError(f"Access denied to resource: {uri!r}")

        return resource

    async def get_resource(
        self, uri: str, version: VersionSpec | None = None
    ) -> Resource | None:
        """Get a resource by URI, filtering disabled resources.

        Overrides Provider.get_resource() to add visibility filtering after all
        transforms (including session-level) have been applied.

        When the highest version is disabled and no explicit version was
        requested, falls back to the next-highest enabled version.

        Args:
            uri: The resource URI.
            version: Version filter (None returns highest version).

        Returns:
            The resource if found and enabled, None otherwise.
        """
        resource, _ = await self._lookup_resource(uri, version)
        return resource

    async def _lookup_resource(
        self, uri: str, version: VersionSpec | None = None
    ) -> tuple[Resource | None, bool]:
        """Resolve a resource as `get_resource` does.

        Also reports whether a concrete resource exists at `uri` at all, so
        reads can tell a hidden resource apart from a missing one.
        """
        try:
            resource = await super().get_resource(uri, version)
        except AuthorizationError:
            return None, True
        if resource is None:
            return None, False

        # Apply session transforms to single item
        resources = await apply_session_transforms([resource])
        if (
            resources
            and is_enabled(resources[0])
            and await _component_auth_allows(resources[0])
        ):
            return resources[0], True

        if version is not None:
            return None, True

        all_resources = [r for r in await super().list_resources() if str(r.uri) == uri]
        all_resources = list(await apply_session_transforms(all_resources))
        enabled = [r for r in all_resources if is_enabled(r)]

        skip_auth, token = _get_auth_context()
        authorized: list[Resource] = []
        for r in enabled:
            if not skip_auth and r.auth is not None:
                ctx = AuthContext(token=token, component=r)
                try:
                    if not await run_auth_checks(r.auth, ctx):
                        continue
                except AuthorizationError:
                    continue
            authorized.append(r)

        if not authorized:
            return None, True
        return max(authorized, key=version_sort_key), True

    async def list_resource_templates(
        self, *, run_middleware: bool = True
    ) -> Sequence[ResourceTemplate]:
        """List all enabled resource templates from providers.

        Overrides Provider.list_resource_templates() to add visibility filtering,
        auth filtering, and middleware execution. Returns all versions (no deduplication).
        Protocol handlers deduplicate for MCP wire format.
        """
        async with fastmcp.server.context.Context(fastmcp=self) as ctx:
            if run_middleware:
                mw_context = MiddlewareContext(
                    message={},
                    source="client",
                    type="request",
                    method="resources/templates/list",
                    fastmcp_context=ctx,
                )
                return await self._dispatch_component_middleware(
                    context=mw_context,
                    call_next=lambda context: self.list_resource_templates(
                        run_middleware=False
                    ),
                )

            # Core logic: list resource templates
            with server_span(
                "resources/templates/list",
                "resources/templates/list",
                self.name,
                "resource_template",
                "",
            ):
                # Get all templates, apply session transforms, then filter enabled
                templates = list(await super().list_resource_templates())
                templates = await apply_session_transforms(templates)
                templates = [t for t in templates if is_enabled(t)]

                skip_auth, token = _get_auth_context()
                authorized: list[ResourceTemplate] = []
                for template in templates:
                    if not skip_auth and template.auth is not None:
                        ctx = AuthContext(token=token, component=template)
                        try:
                            if not await run_auth_checks(template.auth, ctx):
                                continue
                        except AuthorizationError:
                            continue
                    authorized.append(template)
                return authorized

    async def _get_resource_template(
        self, uri: str, version: VersionSpec | None = None
    ) -> ResourceTemplate | None:
        """Get a resource template by URI via aggregation from providers.

        Extends AggregateProvider._get_resource_template() with component-level auth checks.

        Args:
            uri: The template URI to match.
            version: Version filter (None returns highest version).

        Returns:
            The template if found and authorized, None if not found or unauthorized.
        """
        # Get template from AggregateProvider (handles aggregation and namespacing)
        template = await super()._get_resource_template(uri, version)
        if template is None:
            return None

        # Component auth - return None if unauthorized (consistent with list filtering)
        skip_auth, token = _get_auth_context()
        if not skip_auth and template.auth is not None:
            ctx = AuthContext(token=token, component=template)
            try:
                if not await run_auth_checks(template.auth, ctx):
                    return None
            except AuthorizationError:
                return None

        return template

    async def get_resource_template(
        self, uri: str, version: VersionSpec | None = None
    ) -> ResourceTemplate | None:
        """Get a resource template by URI, filtering disabled templates.

        Overrides Provider.get_resource_template() to add visibility filtering after
        all transforms (including session-level) have been applied.

        When the highest version is disabled and no explicit version was
        requested, falls back to the next-highest enabled version.

        Args:
            uri: The template URI.
            version: Version filter (None returns highest version).

        Returns:
            The template if found and enabled, None otherwise.
        """
        template = await super().get_resource_template(uri, version)
        if template is None:
            return None

        # Apply session transforms to single item
        templates = await apply_session_transforms([template])
        # Transforms can change what `auth` sees (a tag, for one), so the check made
        # on the pre-transform component is not enough.
        if (
            templates
            and is_enabled(templates[0])
            and await _component_auth_allows(templates[0])
        ):
            return templates[0]

        if version is not None:
            return None

        all_templates = [
            t
            for t in await super().list_resource_templates()
            if t.matches(uri) is not None
        ]
        all_templates = list(await apply_session_transforms(all_templates))
        enabled = [t for t in all_templates if is_enabled(t)]

        skip_auth, token = _get_auth_context()
        authorized: list[ResourceTemplate] = []
        for t in enabled:
            if not skip_auth and t.auth is not None:
                ctx = AuthContext(token=token, component=t)
                try:
                    if not await run_auth_checks(t.auth, ctx):
                        continue
                except AuthorizationError:
                    continue
            authorized.append(t)

        if not authorized:
            return None
        return max(authorized, key=version_sort_key)

    async def list_prompts(self, *, run_middleware: bool = True) -> Sequence[Prompt]:
        """List all enabled prompts from providers.

        Overrides Provider.list_prompts() to add visibility filtering, auth filtering,
        and middleware execution. Returns all versions (no deduplication).
        Protocol handlers deduplicate for MCP wire format.
        """
        async with fastmcp.server.context.Context(fastmcp=self) as ctx:
            if run_middleware:
                mw_context = MiddlewareContext(
                    message={},
                    source="client",
                    type="request",
                    method="prompts/list",
                    fastmcp_context=ctx,
                )
                return await self._dispatch_component_middleware(
                    context=mw_context,
                    call_next=lambda context: self.list_prompts(run_middleware=False),
                )

            # Core logic: list prompts
            with server_span("prompts/list", "prompts/list", self.name, "prompt", ""):
                # Get all prompts, apply session transforms, then filter enabled
                prompts = list(await super().list_prompts())
                prompts = await apply_session_transforms(prompts)
                prompts = [p for p in prompts if is_enabled(p)]

                skip_auth, token = _get_auth_context()
                authorized: list[Prompt] = []
                for prompt in prompts:
                    if not skip_auth and prompt.auth is not None:
                        ctx = AuthContext(token=token, component=prompt)
                        try:
                            if not await run_auth_checks(prompt.auth, ctx):
                                continue
                        except AuthorizationError:
                            continue
                    authorized.append(prompt)
                return authorized

    async def _get_prompt(
        self, name: str, version: VersionSpec | None = None
    ) -> Prompt | None:
        """Get a prompt by name via aggregation from providers.

        Extends AggregateProvider._get_prompt() with component-level auth checks.

        Args:
            name: The prompt name.
            version: Version filter (None returns highest version).

        Returns:
            The prompt if found and authorized, None if not found or unauthorized.
        """
        # Get prompt from AggregateProvider (handles aggregation and namespacing)
        prompt = await super()._get_prompt(name, version)
        if prompt is None:
            return None

        # Component auth - return None if unauthorized (consistent with list filtering)
        skip_auth, token = _get_auth_context()
        if not skip_auth and prompt.auth is not None:
            ctx = AuthContext(token=token, component=prompt)
            try:
                if not await run_auth_checks(prompt.auth, ctx):
                    return None
            except AuthorizationError:
                return None

        return prompt

    async def get_prompt(
        self, name: str, version: VersionSpec | None = None
    ) -> Prompt | None:
        """Get a prompt by name, filtering disabled prompts.

        Overrides Provider.get_prompt() to add visibility filtering after all
        transforms (including session-level) have been applied.

        When the highest version is disabled and no explicit version was
        requested, falls back to the next-highest enabled version.

        Args:
            name: The prompt name.
            version: Version filter (None returns highest version).

        Returns:
            The prompt if found and enabled, None otherwise.
        """
        prompt = await super().get_prompt(name, version)
        if prompt is None:
            return None

        # Apply session transforms to single item
        prompts = await apply_session_transforms([prompt])
        # Transforms can change what `auth` sees (a tag, for one), so the check made
        # on the pre-transform component is not enough.
        if (
            prompts
            and is_enabled(prompts[0])
            and await _component_auth_allows(prompts[0])
        ):
            return prompts[0]

        if version is not None:
            return None

        all_prompts = [p for p in await super().list_prompts() if p.name == name]
        all_prompts = list(await apply_session_transforms(all_prompts))
        enabled = [p for p in all_prompts if is_enabled(p)]

        skip_auth, token = _get_auth_context()
        authorized: list[Prompt] = []
        for p in enabled:
            if not skip_auth and p.auth is not None:
                ctx = AuthContext(token=token, component=p)
                try:
                    if not await run_auth_checks(p.auth, ctx):
                        continue
                except AuthorizationError:
                    continue
            authorized.append(p)

        if not authorized:
            return None
        return max(authorized, key=version_sort_key)

    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any] | None = None,
        *,
        version: VersionSpec | None = None,
        run_middleware: bool = True,
    ) -> ToolResult:
        """Call a tool by name.

        This is the public API for executing tools. By default, middleware is applied.

        Args:
            name: The tool name
            arguments: Tool arguments (optional)
            version: Specific version to call. If None, calls highest version.
            run_middleware: If True (default), apply the middleware chain.
                Set to False when called from middleware to avoid re-applying.

        Returns:
            ToolResult.

        A guard tool that requests client input (SEP-2322 multi-round-trip)
        returns an ``InputRequiredToolResult`` (a ``ToolResult`` subclass); it
        flows back through the middleware chain as an ordinary result and the
        wire handler unwraps it into an ``InputRequiredResult`` on the response.

        Raises:
            NotFoundError: If tool not found or disabled
            ToolError: If tool execution fails
            ValidationError: If arguments fail validation
        """
        # Note: fn_key enrichment happens here after finding the tool.
        # For mounted servers, the parent's provider sets fn_key to the
        # namespaced key before delegating, ensuring correct Docket routing.

        # Two routing paths:
        #   1. Display-name path — the name this server lists the tool
        #      under, resolved through `get_tool`.
        #   2. Hashed-name path — backend tools that opted into
        #      app-callable visibility, addressed as `<hash>_<local_name>`
        #      and resolved through `get_tool_by_hash`. It applies the same
        #      transforms, visibility, and auth as the display-name path.
        async with fastmcp.server.context.Context(fastmcp=self) as ctx:
            if run_middleware:
                mw_context = MiddlewareContext[CallToolRequestParams](
                    message=mcp_types.CallToolRequestParams(
                        name=name,
                        arguments=arguments or {},
                        # Reflect the continuation fields (SEP-2322) so middleware
                        # reading `context.message` sees a continuation round as
                        # such, not as an initial call. These are recovered from
                        # the raw wire request (unsealed to plaintext by the
                        # request-state boundary); they drive middleware
                        # visibility only — `call_next` routes on name/arguments.
                        input_responses=ctx.input_responses,
                        request_state=ctx.request_state,
                        _meta=_version_request_meta(version),
                    ),
                    source="client",
                    type="request",
                    method="tools/call",
                    fastmcp_context=ctx,
                )
                # Extension tools/call interceptors compose here, at the
                # innermost point of dispatch: the FastMCP middleware chain wraps
                # the whole thing (so it observes every call), and the
                # interceptors sit between it and the tool body (so each is the
                # last gate before execution).
                with _dispatching_tool_call(), _extension_tool_call_scope(self):
                    dispatched = await self._dispatch_component_middleware(
                        context=mw_context,
                        call_next=self._compose_tool_call_interceptors(
                            lambda context: self.call_tool(
                                context.message.name,
                                context.message.arguments or {},
                                version=version,
                                run_middleware=False,
                            )
                        ),
                    )
                # Above the chain, so a Prefab payload is re-addressed however
                # it was produced — middleware can answer a call itself, and
                # such a result never reaches the core path below.
                return await self._rebind_prefab_tool_names(dispatched)

            # Core logic: find and execute tool
            with server_span(
                f"tools/call {name}",
                "tools/call",
                self.name,
                "tool",
                name,
                tool_name=name,
            ) as span:
                # Try normal display-name resolution first.
                tool: Tool | None = await self.get_tool(name, version=version)

                # If that fails, try hashed-name dispatch, which finds the
                # tool whose stored hash matches the parsed prefix.
                if tool is None:
                    hashed = parse_hashed_backend_name(name)
                    if hashed is not None:
                        digest, local_name = hashed
                        tool = await self.get_tool_by_hash(digest, local_name)

                if tool is None:
                    raise NotFoundError(f"Unknown tool: {name!r}")
                span.set_attributes(tool.get_span_attributes())
                try:
                    return await tool._run(arguments or {})
                except ValidationError as e:
                    cause = e.__cause__
                    if isinstance(cause, PydanticValidationError):
                        logger.warning(
                            "Invalid arguments for tool %r: %s",
                            name,
                            _validation_error_summary(cause),
                        )
                    else:
                        logger.warning("Invalid arguments for tool %r", name)
                    raise
                except FastMCPError as e:
                    logger.log(
                        e.log_level, f"Error calling tool {name!r}", exc_info=False
                    )
                    raise
                except PydanticValidationError as e:
                    # A pydantic error that is NOT an argument-validation failure
                    # (e.g. raised by a non-FunctionTool's own validation). Kept
                    # for backward compatibility.
                    logger.warning(
                        "Invalid arguments for tool %r: %s",
                        name,
                        _validation_error_summary(e),
                    )
                    raise
                except Exception as e:
                    # Most MCPErrors raised under a tool describe how the call
                    # went — a timeout, an upstream error a proxy forwarded —
                    # and are masked into an `isError` result like any other
                    # failure. A missing-client-capability error is different:
                    # it says the request cannot be serviced at all, and
                    # SEP-2575 requires it on the wire as -32021 (HTTP 400).
                    # Flattening it into a result would drop the code and tell
                    # the client the call had succeeded.
                    if (
                        isinstance(e, MCPError)
                        and e.error.code == MISSING_REQUIRED_CLIENT_CAPABILITY
                    ):
                        logger.debug(
                            "Tool %r requires a client capability the client did "
                            "not declare",
                            name,
                        )
                        raise
                    # An upstream HTTP error response is an answer from the
                    # upstream API, not a crash in the tool: skip the traceback.
                    status_code = get_http_status_code(e)
                    logger.error(
                        f"Error calling tool {name!r}", exc_info=status_code is None
                    )
                    # Handle actionable errors that should reach the LLM
                    # even when masking is enabled
                    if status_code == 429:
                        raise ToolError(
                            "Rate limited by upstream API, please retry later"
                        ) from e
                    if is_timeout_error(e):
                        raise ToolError(
                            "Upstream request timed out, please retry"
                        ) from e
                    # Standard masking logic
                    if self._mask_error_details:
                        raise ToolError(f"Error calling tool {name!r}") from e
                    raise ToolError(f"Error calling tool {name!r}: {e}") from e

    async def _check_resource_access(
        self, uri: str, version: VersionSpec | None = None
    ) -> None:
        async with fastmcp.server.context.Context(fastmcp=self) as ctx:
            context = MiddlewareContext(
                message=mcp_types.ReadResourceRequestParams(
                    uri=uri, _meta=_version_request_meta(version)
                ),
                method="resources/read",
                fastmcp_context=ctx,
            )
            for middleware in self.middleware:
                await middleware.check_resource_access(context)

    async def read_resource(
        self,
        uri: str,
        *,
        version: VersionSpec | None = None,
        run_middleware: bool = True,
    ) -> ResourceResult:
        """Read a resource by URI.

        This is the public API for reading resources. By default, middleware is applied.
        Checks concrete resources first, then templates.

        Args:
            uri: The resource URI
            version: Specific version to read. If None, reads highest version.
            run_middleware: If True (default), apply the middleware chain.
                Set to False when called from middleware to avoid re-applying.

        Returns:
            ResourceResult.

        Raises:
            NotFoundError: If resource not found or disabled
            ResourceError: If resource read fails
        """
        async with fastmcp.server.context.Context(fastmcp=self) as ctx:
            if run_middleware:
                mw_context = MiddlewareContext(
                    message=mcp_types.ReadResourceRequestParams(
                        uri=str(uri),
                        _meta=_version_request_meta(version),
                    ),
                    source="client",
                    type="request",
                    method="resources/read",
                    fastmcp_context=ctx,
                )
                return await self._dispatch_component_middleware(
                    context=mw_context,
                    call_next=lambda context: self.read_resource(
                        str(context.message.uri),
                        version=version,
                        run_middleware=False,
                    ),
                )

            # Core logic: find and read resource (providers queried in parallel)
            with server_span(
                "resources/read",
                "resources/read",
                self.name,
                "resource",
                uri,
                resource_uri=uri,
            ) as span:
                # Intercept synthetic Prefab renderer URIs before normal
                # resolution. The resource isn't stored anywhere — we
                # build it on demand from the matching tool's CSP.
                from fastmcp.server.providers.prefab_synthesis import (
                    synthesize_prefab_resource_by_uri,
                )

                synthesized = await synthesize_prefab_resource_by_uri(self, uri)
                if synthesized is not None:
                    span.set_attributes(synthesized.get_span_attributes())
                    return await synthesized._read()

                # Try concrete resources first (transforms + auth via _get_resource)
                resource, exists = await self._lookup_resource(uri, version=version)
                if resource is not None:
                    span.set_attributes(resource.get_span_attributes())
                    try:
                        return await resource._read()
                    except FastMCPError as e:
                        logger.log(
                            e.log_level,
                            f"Error reading resource {uri!r}",
                            exc_info=True,
                        )
                        raise
                    except MCPError:
                        logger.exception(f"Error reading resource {uri!r}")
                        raise
                    except Exception as e:
                        logger.exception(f"Error reading resource {uri!r}")
                        # Handle actionable errors that should reach the LLM
                        if get_http_status_code(e) == 429:
                            raise ResourceError(
                                "Rate limited by upstream API, please retry later"
                            ) from e
                        if is_timeout_error(e):
                            raise ResourceError(
                                "Upstream request timed out, please retry"
                            ) from e
                        # Standard masking logic
                        if self._mask_error_details:
                            raise ResourceError(
                                f"Error reading resource {uri!r}"
                            ) from e
                        raise ResourceError(
                            f"Error reading resource {uri!r}: {e}"
                        ) from e

                # A hidden concrete resource shadows templates for its URI.
                # Otherwise a matching template, such as a proxy's, would
                # serve the resource that was hidden.
                if exists:
                    raise NotFoundError(f"Unknown resource: {uri!r}")

                # Try templates (transforms + auth via get_resource_template)
                template = await self.get_resource_template(uri, version=version)
                if template is None:
                    if version is None:
                        raise NotFoundError(f"Unknown resource: {uri!r}")
                    raise NotFoundError(
                        f"Unknown resource: {uri!r} version {version!r}"
                    )
                span.set_attributes(template.get_span_attributes())
                params = template.matches(uri)
                assert params is not None

                # Path-security screening: reject traversal / absolute-path /
                # null-byte payloads in extracted parameter values BEFORE the
                # handler runs. This is the single chokepoint for every
                # templated read (local decorator and provider-sourced), so
                # enforcement lives here rather than in any decorator.
                security = template.resolve_security(self._resource_security)
                if security is not None:
                    failed = security.validate(params)
                    if failed is not None:
                        logger.debug(
                            "Rejected resource %r: parameter %r failed "
                            "path-security screening",
                            uri,
                            failed,
                        )
                        raise ResourceSecurityError(f"Unknown resource: {uri!r}")

                try:
                    return await template._read(uri, params)
                except FastMCPError as e:
                    logger.log(
                        e.log_level, f"Error reading resource {uri!r}", exc_info=True
                    )
                    raise
                except MCPError:
                    logger.exception(f"Error reading resource {uri!r}")
                    raise
                except Exception as e:
                    logger.exception(f"Error reading resource {uri!r}")
                    # Handle actionable errors that should reach the LLM
                    if get_http_status_code(e) == 429:
                        raise ResourceError(
                            "Rate limited by upstream API, please retry later"
                        ) from e
                    if is_timeout_error(e):
                        raise ResourceError(
                            "Upstream request timed out, please retry"
                        ) from e
                    # Standard masking logic
                    if self._mask_error_details:
                        raise ResourceError(f"Error reading resource {uri!r}") from e
                    raise ResourceError(f"Error reading resource {uri!r}: {e}") from e

    async def render_prompt(
        self,
        name: str,
        arguments: dict[str, Any] | None = None,
        *,
        version: VersionSpec | None = None,
        run_middleware: bool = True,
    ) -> PromptResult:
        """Render a prompt by name.

        This is the public API for rendering prompts. By default, middleware is applied.
        Use get_prompt() to retrieve the prompt definition without rendering.

        Args:
            name: The prompt name
            arguments: Prompt arguments (optional)
            version: Specific version to render. If None, renders highest version.
            run_middleware: If True (default), apply the middleware chain.
                Set to False when called from middleware to avoid re-applying.

        Returns:
            PromptResult.

        Raises:
            NotFoundError: If prompt not found or disabled
            PromptError: If prompt rendering fails
        """
        async with fastmcp.server.context.Context(fastmcp=self) as ctx:
            if run_middleware:
                mw_context = MiddlewareContext(
                    message=mcp_types.GetPromptRequestParams(
                        name=name,
                        arguments=arguments,
                        _meta=_version_request_meta(version),
                    ),
                    source="client",
                    type="request",
                    method="prompts/get",
                    fastmcp_context=ctx,
                )
                return await self._dispatch_component_middleware(
                    context=mw_context,
                    call_next=lambda context: self.render_prompt(
                        context.message.name,
                        context.message.arguments,
                        version=version,
                        run_middleware=False,
                    ),
                )

            # Core logic: find and render prompt (providers queried in parallel)
            # Use get_prompt to apply transforms and filter disabled
            with server_span(
                f"prompts/get {name}",
                "prompts/get",
                self.name,
                "prompt",
                name,
                prompt_name=name,
            ) as span:
                prompt = await self.get_prompt(name, version=version)
                if prompt is None:
                    raise NotFoundError(f"Unknown prompt: {name!r}")
                span.set_attributes(prompt.get_span_attributes())
                try:
                    return await prompt._render(arguments)
                except FastMCPError as e:
                    logger.log(
                        e.log_level, f"Error rendering prompt {name!r}", exc_info=True
                    )
                    raise
                except MCPError:
                    logger.exception(f"Error rendering prompt {name!r}")
                    raise
                except Exception as e:
                    logger.exception(f"Error rendering prompt {name!r}")
                    if self._mask_error_details:
                        raise PromptError(f"Error rendering prompt {name!r}") from e
                    raise PromptError(f"Error rendering prompt {name!r}: {e}") from e

    def add_tool(self, tool: Tool | Callable[..., Any]) -> Tool:
        """Add a tool to the server.

        The tool function can optionally request a Context object by adding a parameter
        with the Context type annotation. See the @tool decorator for examples.

        Args:
            tool: The Tool instance or @tool-decorated function to register

        Returns:
            The tool instance that was added to the server.
        """
        return self._local_provider.add_tool(tool)

    @overload
    def tool(
        self,
        name_or_fn: F,
        *,
        name: str | None = None,
        version: str | int | None = None,
        title: str | None = None,
        description: str | None = None,
        icons: list[mcp_types.Icon] | None = None,
        tags: set[str] | None = None,
        output_schema: dict[str, Any] | NotSetT | None = NotSet,
        annotations: ToolAnnotations | dict[str, Any] | None = None,
        meta: dict[str, Any] | None = None,
        app: AppConfig | dict[str, Any] | bool | None = None,
        task: bool | TaskConfig | None = None,
        timeout: float | None = None,
        auth: AuthCheck | list[AuthCheck] | None = None,
        run_in_thread: bool = True,
    ) -> F: ...

    @overload
    def tool(
        self,
        name_or_fn: str | None = None,
        *,
        name: str | None = None,
        version: str | int | None = None,
        title: str | None = None,
        description: str | None = None,
        icons: list[mcp_types.Icon] | None = None,
        tags: set[str] | None = None,
        output_schema: dict[str, Any] | NotSetT | None = NotSet,
        annotations: ToolAnnotations | dict[str, Any] | None = None,
        meta: dict[str, Any] | None = None,
        app: AppConfig | dict[str, Any] | bool | None = None,
        task: bool | TaskConfig | None = None,
        timeout: float | None = None,
        auth: AuthCheck | list[AuthCheck] | None = None,
        run_in_thread: bool = True,
    ) -> Callable[[F], F]: ...

    def tool(
        self,
        name_or_fn: str | AnyFunction | None = None,
        *,
        name: str | None = None,
        version: str | int | None = None,
        title: str | None = None,
        description: str | None = None,
        icons: list[mcp_types.Icon] | None = None,
        tags: set[str] | None = None,
        output_schema: dict[str, Any] | NotSetT | None = NotSet,
        annotations: ToolAnnotations | dict[str, Any] | None = None,
        meta: dict[str, Any] | None = None,
        app: AppConfig | dict[str, Any] | bool | None = None,
        task: bool | TaskConfig | None = None,
        timeout: float | None = None,
        auth: AuthCheck | list[AuthCheck] | None = None,
        run_in_thread: bool = True,
    ) -> (
        Callable[[AnyFunction], FunctionTool]
        | FunctionTool
        | partial[Callable[[AnyFunction], FunctionTool] | FunctionTool]
    ):
        """Decorator to register a tool.

        Tools can optionally request a Context object by adding a parameter with the
        Context type annotation. The context provides access to MCP capabilities like
        logging, progress reporting, and resource access.

        This decorator supports multiple calling patterns:
        - @server.tool (without parentheses)
        - @server.tool (with empty parentheses)
        - @server.tool("custom_name") (with name as first argument)
        - @server.tool(name="custom_name") (with name as keyword argument)
        - server.tool(function, name="custom_name") (direct function call)

        Args:
            name_or_fn: Either a function (when used as @tool), a string name, or None
            name: Optional name for the tool (keyword-only, alternative to name_or_fn)
            description: Optional description of what the tool does
            tags: Optional set of tags for categorizing the tool
            output_schema: Optional JSON schema for the tool's output
            annotations: Optional annotations about the tool's behavior
            meta: Optional meta information about the tool

        Examples:
            Register a tool with a custom name:
            ```python
            @server.tool
            def my_tool(x: int) -> str:
                return str(x)

            # Register a tool with a custom name
            @server.tool
            def my_tool(x: int) -> str:
                return str(x)

            @server.tool("custom_name")
            def my_tool(x: int) -> str:
                return str(x)

            @server.tool(name="custom_name")
            def my_tool(x: int) -> str:
                return str(x)

            # Direct function call
            server.tool(my_function, name="custom_name")
            ```
        """
        # Merge app config into meta["ui"] (wire format) before passing to provider
        if app is not None and app is not False:
            meta = dict(meta) if meta else {}
            if app is True:
                meta["ui"] = True
            else:
                meta["ui"] = app_config_to_meta_dict(app)

        # Delegate to LocalProvider with server-level defaults
        result = self._local_provider.tool(
            name_or_fn,
            name=name,
            version=version,
            title=title,
            description=description,
            icons=icons,
            tags=tags,
            output_schema=output_schema,
            annotations=annotations,
            meta=meta,
            task=task if task is not None else self._support_tasks_by_default,
            timeout=timeout,
            auth=auth,
            run_in_thread=run_in_thread,
        )

        return result

    def add_resource(
        self, resource: Resource | Callable[..., Any]
    ) -> Resource | ResourceTemplate:
        """Add a resource to the server.

        Args:
            resource: A Resource instance or @resource-decorated function to add

        Returns:
            The resource instance that was added to the server.
        """
        return self._local_provider.add_resource(resource)

    def add_template(self, template: ResourceTemplate) -> ResourceTemplate:
        """Add a resource template to the server.

        Args:
            template: A ResourceTemplate instance to add

        Returns:
            The template instance that was added to the server.
        """
        return self._local_provider.add_template(template)

    def resource(
        self,
        uri: str,
        *,
        name: str | None = None,
        version: str | int | None = None,
        title: str | None = None,
        description: str | None = None,
        icons: list[mcp_types.Icon] | None = None,
        mime_type: str | None = None,
        tags: set[str] | None = None,
        annotations: Annotations | dict[str, Any] | None = None,
        meta: dict[str, Any] | None = None,
        app: AppConfig | dict[str, Any] | bool | None = None,
        auth: AuthCheck | list[AuthCheck] | None = None,
        security: ResourceSecurity | None | InheritSecurity = INHERIT_SECURITY,
    ) -> Callable[[F], F]:
        """Decorator to register a function as a resource.

        The function will be called when the resource is read to generate its content.
        The function can return:
        - str for text content
        - bytes for binary content
        - other types will be converted to JSON

        Resources can optionally request a Context object by adding a parameter with the
        Context type annotation. The context provides access to MCP capabilities like
        logging, progress reporting, and session information.

        If the URI contains parameters (e.g. "resource://{param}") or the function
        has parameters, it will be registered as a template resource.

        Args:
            uri: URI for the resource (e.g. "resource://my-resource" or "resource://{param}")
            name: Optional name for the resource
            description: Optional description of the resource
            mime_type: Optional MIME type for the resource
            tags: Optional set of tags for categorizing the resource
            annotations: Optional annotations about the resource's behavior
            meta: Optional meta information about the resource

        Examples:
            Register a resource with a custom name:
            ```python
            @server.resource("resource://my-resource")
            def get_data() -> str:
                return "Hello, world!"

            @server.resource("resource://my-resource")
            async get_data() -> str:
                data = await fetch_data()
                return f"Hello, world! {data}"

            @server.resource("resource://{city}/weather")
            def get_weather(city: str) -> str:
                return f"Weather for {city}"

            @server.resource("resource://{city}/weather")
            async def get_weather_with_context(city: str, ctx: Context) -> str:
                await ctx.info(f"Fetching weather for {city}")
                return f"Weather for {city}"

            @server.resource("resource://{city}/weather")
            async def get_weather(city: str) -> str:
                data = await fetch_weather(city)
                return f"Weather for {city}: {data}"
            ```
        """
        # Catch incorrect decorator usage early (before any processing)
        if not isinstance(uri, str):
            raise TypeError(
                "The @resource decorator was used incorrectly. "
                "It requires a URI as the first argument. "
                "Use @resource('uri') instead of @resource"
            )

        # Apply default MIME type for ui:// scheme resources
        mime_type = resolve_ui_mime_type(uri, mime_type)

        # Validate app config for resources — resource_uri and visibility
        # don't apply since the resource itself is the UI
        if isinstance(app, AppConfig):
            if app.resource_uri is not None:
                raise ValueError(
                    "resource_uri cannot be set on resources — "
                    "the resource itself is the UI. "
                    "Use resource_uri on tools to point to a UI resource."
                )
            if app.visibility is not None:
                raise ValueError(
                    "visibility cannot be set on resources — it only applies to tools."
                )

        # Merge app config into meta["ui"] (wire format) before passing to provider
        if app is not None and app is not False:
            meta = dict(meta) if meta else {}
            if app is True:
                meta["ui"] = True
            else:
                meta["ui"] = app_config_to_meta_dict(app)

        # Delegate to LocalProvider with server-level defaults
        inner_decorator = self._local_provider.resource(
            uri,
            name=name,
            version=version,
            title=title,
            description=description,
            icons=icons,
            mime_type=mime_type,
            tags=tags,
            annotations=annotations,
            meta=meta,
            auth=auth,
            security=security,
        )

        return inner_decorator

    def add_prompt(self, prompt: Prompt | Callable[..., Any]) -> Prompt:
        """Add a prompt to the server.

        Args:
            prompt: A Prompt instance or @prompt-decorated function to add

        Returns:
            The prompt instance that was added to the server.
        """
        return self._local_provider.add_prompt(prompt)

    @overload
    def prompt(
        self,
        name_or_fn: F,
        *,
        name: str | None = None,
        version: str | int | None = None,
        title: str | None = None,
        description: str | None = None,
        icons: list[mcp_types.Icon] | None = None,
        tags: set[str] | None = None,
        meta: dict[str, Any] | None = None,
        auth: AuthCheck | list[AuthCheck] | None = None,
    ) -> F: ...

    @overload
    def prompt(
        self,
        name_or_fn: str | None = None,
        *,
        name: str | None = None,
        version: str | int | None = None,
        title: str | None = None,
        description: str | None = None,
        icons: list[mcp_types.Icon] | None = None,
        tags: set[str] | None = None,
        meta: dict[str, Any] | None = None,
        auth: AuthCheck | list[AuthCheck] | None = None,
    ) -> Callable[[F], F]: ...

    def prompt(
        self,
        name_or_fn: str | AnyFunction | None = None,
        *,
        name: str | None = None,
        version: str | int | None = None,
        title: str | None = None,
        description: str | None = None,
        icons: list[mcp_types.Icon] | None = None,
        tags: set[str] | None = None,
        meta: dict[str, Any] | None = None,
        auth: AuthCheck | list[AuthCheck] | None = None,
    ) -> (
        Callable[[AnyFunction], FunctionPrompt]
        | FunctionPrompt
        | partial[Callable[[AnyFunction], FunctionPrompt] | FunctionPrompt]
    ):
        """Decorator to register a prompt.

        Prompts can optionally request a Context object by adding a parameter with the
        Context type annotation. The context provides access to MCP capabilities like
        logging, progress reporting, and session information.

        This decorator supports multiple calling patterns:
        - @server.prompt (without parentheses)
        - @server.prompt() (with empty parentheses)
        - @server.prompt("custom_name") (with name as first argument)
        - @server.prompt(name="custom_name") (with name as keyword argument)
        - server.prompt(function, name="custom_name") (direct function call)

        Args:
            name_or_fn: Either a function (when used as @prompt), a string name, or None
            name: Optional name for the prompt (keyword-only, alternative to name_or_fn)
            description: Optional description of what the prompt does
            tags: Optional set of tags for categorizing the prompt
            meta: Optional meta information about the prompt

        Examples:

            ```python
            @server.prompt
            def analyze_table(table_name: str) -> list[Message]:
                schema = read_table_schema(table_name)
                return [
                    {
                        "role": "user",
                        "content": f"Analyze this schema:\n{schema}"
                    }
                ]

            @server.prompt()
            async def analyze_with_context(table_name: str, ctx: Context) -> list[Message]:
                await ctx.info(f"Analyzing table {table_name}")
                schema = read_table_schema(table_name)
                return [
                    {
                        "role": "user",
                        "content": f"Analyze this schema:\n{schema}"
                    }
                ]

            @server.prompt("custom_name")
            async def analyze_file(path: str) -> list[Message]:
                content = await read_file(path)
                return [
                    {
                        "role": "user",
                        "content": {
                            "type": "resource",
                            "resource": {
                                "uri": f"file://{path}",
                                "text": content
                            }
                        }
                    }
                ]

            @server.prompt(name="custom_name")
            def another_prompt(data: str) -> list[Message]:
                return [{"role": "user", "content": data}]

            # Direct function call
            server.prompt(my_function, name="custom_name")
            ```
        """
        # Delegate to LocalProvider with server-level defaults
        return self._local_provider.prompt(
            name_or_fn,
            name=name,
            version=version,
            title=title,
            description=description,
            icons=icons,
            tags=tags,
            meta=meta,
            auth=auth,
        )

    def add_completion_handler(self, handler: CompletionHandler) -> None:
        """Register the server's argument-completion handler.

        A server has a single completion handler that answers every
        `completion/complete` request, switching on the reference (a prompt or
        resource template) and the argument being completed. Registering it also
        registers the low-level `completion/complete` handler, which is what
        makes the SDK declare the completions capability — so the capability is
        advertised exactly when the server can answer. Calling this again
        replaces the handler.

        Args:
            handler: A callable taking the reference, the
                `CompletionArgument`, and the optional `CompletionContext`, and
                returning candidate values (a `Completion`, a list of strings,
                or None). May be sync or async.
        """
        self._completion_handler = handler
        self._register_completion_handler()

    @overload
    def completion(self, handler: CompletionHandler) -> CompletionHandler: ...

    @overload
    def completion(
        self,
    ) -> Callable[[CompletionHandler], CompletionHandler]: ...

    def completion(
        self,
        handler: CompletionHandler | None = None,
    ) -> CompletionHandler | Callable[[CompletionHandler], CompletionHandler]:
        """Decorator to register the server's argument-completion handler.

        The handler answers `completion/complete` requests for prompt arguments
        and resource-template parameters. It receives the reference being
        completed, the argument (its name and the partial value typed so far),
        and the context of arguments already supplied, and returns candidate
        values. Return a list of strings, a `Completion` (to include pagination
        hints), or None when the reference/argument is not one it handles — an
        unhandled reference yields an empty completion, not an error.

        Registering a handler declares the completions capability; a server with
        none does not advertise it. This works identically on the handshake and
        modern protocol eras.

        Supports both `@mcp.completion` and `@mcp.completion()`.

        Example:

            ```python
            from fastmcp import FastMCP
            from mcp_types import Completion, PromptReference

            mcp = FastMCP("Completion Server")

            @mcp.prompt
            def poem(theme: str) -> str:
                return f"Write a poem about {theme}"

            @mcp.completion
            def complete(ref, argument, context):
                if isinstance(ref, PromptReference) and ref.name == "poem":
                    if argument.name == "theme":
                        options = ["nature", "love", "adventure"]
                        return [o for o in options if o.startswith(argument.value)]
                return None
            ```
        """

        def register(fn: CompletionHandler) -> CompletionHandler:
            self.add_completion_handler(fn)
            return fn

        if handler is None:
            return register
        return register(handler)

    def mount(
        self,
        server: FastMCP[LifespanResultT],
        namespace: str | None = None,
        tool_names: dict[str, str] | None = None,
    ) -> None:
        """Mount another FastMCP server on this server with an optional namespace.

        Mounting establishes a dynamic connection between servers. When a client
        interacts with a mounted server's objects through the parent server, requests
        are forwarded to the mounted server in real-time. This means changes to the
        mounted server are immediately reflected when accessed through the parent.

        When a server is mounted with a namespace:
        - Tools from the mounted server are accessible with namespaced names.
          Example: If server has a tool named "get_weather", it will be available as "namespace_get_weather".
        - Resources are accessible with namespaced URIs.
          Example: If server has a resource with URI "weather://forecast", it will be available as
          "weather://namespace/forecast".
        - Templates are accessible with namespaced URI templates.
          Example: If server has a template with URI "weather://location/{id}", it will be available
          as "weather://namespace/location/{id}".
        - Prompts are accessible with namespaced names.
          Example: If server has a prompt named "weather_prompt", it will be available as
          "namespace_weather_prompt".

        When a server is mounted without a namespace (namespace=None), its tools, resources, templates,
        and prompts are accessible with their original names. Multiple servers can be mounted
        without namespaces, and they will be tried in order until a match is found.

        The mounted server's lifespan is executed when the parent server starts, and its
        middleware chain is invoked for all operations (tool calls, resource reads, prompts).

        Args:
            server: The FastMCP server to mount.
            namespace: Optional namespace to use for the mounted server's objects. If None,
                the server's objects are accessible with their original names.
            tool_names: Optional mapping of original tool names to custom names. Use this
                to override namespaced names. Keys are the original tool names from the
                mounted server.
        """
        from fastmcp.server.providers.fastmcp_provider import FastMCPProvider

        if server is self:
            raise ValueError("Cannot mount a server onto itself")

        # Warn if parent masks errors but child doesn't (or vice versa)
        if self._mask_error_details and not server._mask_error_details:
            logger.warning(
                f"Parent server {self.name!r} has mask_error_details=True but "
                f"mounted server {server.name!r} does not. Error details from "
                f"{server.name!r} may leak through to clients. Set "
                f"mask_error_details=True on the child server to prevent this."
            )

        # Create provider and add it with namespace
        provider: Provider = FastMCPProvider(server)

        # Apply tool renames first (scoped to this provider), then namespace
        # So foo → bar with namespace="baz" becomes baz_bar
        if tool_names:
            transforms = {
                old_name: ToolTransformConfig(name=new_name)
                for old_name, new_name in tool_names.items()
            }
            provider = provider.wrap_transform(ToolTransform(transforms))

        # Use add_provider with namespace (applies namespace in AggregateProvider)
        self.add_provider(provider, namespace=namespace or "")

    @classmethod
    def from_openapi(
        cls,
        openapi_spec: dict[str, Any],
        client: httpx2.AsyncClient | None = None,
        name: str = "OpenAPI Server",
        route_maps: list[RouteMap] | None = None,
        route_map_fn: OpenAPIRouteMapFn | None = None,
        mcp_component_fn: OpenAPIComponentFn | None = None,
        mcp_names: dict[str, str] | None = None,
        tags: set[str] | None = None,
        validate_output: bool = True,
        **settings: Any,
    ) -> Self:
        """
        Create a FastMCP server from an OpenAPI specification.

        Args:
            openapi_spec: OpenAPI schema as a dictionary
            client: Optional httpx2 AsyncClient for making HTTP requests.
                If not provided, a default client is created using the first
                server URL from the OpenAPI spec with a 30-second timeout.
                Legacy httpx clients are temporarily accepted with a deprecation
                warning.
            name: Name for the MCP server
            route_maps: Optional list of RouteMap objects defining route mappings
            route_map_fn: Optional callable for advanced route type mapping
            mcp_component_fn: Optional callable for component customization
            mcp_names: Optional dictionary mapping operationId to component names
            tags: Optional set of tags to add to all components
            validate_output: If True (default), tools use the output schema
                extracted from the OpenAPI spec for response validation. If
                False, a permissive schema is used instead, allowing any
                response structure while still returning structured JSON.
            **settings: Additional settings passed to FastMCP

        Returns:
            A FastMCP server with an OpenAPIProvider attached.
        """
        from .providers.openapi import OpenAPIProvider

        provider: Provider = OpenAPIProvider(
            openapi_spec=openapi_spec,
            client=client,
            route_maps=route_maps,
            route_map_fn=route_map_fn,
            mcp_component_fn=mcp_component_fn,
            mcp_names=mcp_names,
            tags=tags,
            validate_output=validate_output,
        )
        return cls(name=name, providers=[provider], **settings)

    @classmethod
    def from_fastapi(
        cls,
        app: Any,
        name: str | None = None,
        route_maps: list[RouteMap] | None = None,
        route_map_fn: OpenAPIRouteMapFn | None = None,
        mcp_component_fn: OpenAPIComponentFn | None = None,
        mcp_names: dict[str, str] | None = None,
        httpx_client_kwargs: dict[str, Any] | None = None,
        tags: set[str] | None = None,
        **settings: Any,
    ) -> Self:
        """
        Create a FastMCP server from a FastAPI application.

        Args:
            app: FastAPI application instance
            name: Name for the MCP server (defaults to app.title)
            route_maps: Optional list of RouteMap objects defining route mappings
            route_map_fn: Optional callable for advanced route type mapping
            mcp_component_fn: Optional callable for component customization
            mcp_names: Optional dictionary mapping operationId to component names
            httpx_client_kwargs: Optional kwargs passed to httpx2.AsyncClient.
                Use this to configure timeout and other client settings.
            tags: Optional set of tags to add to all components
            **settings: Additional settings passed to FastMCP

        Returns:
            A FastMCP server with an OpenAPIProvider attached.
        """
        from .providers.openapi import OpenAPIProvider

        if httpx_client_kwargs is None:
            httpx_client_kwargs = {}
        httpx_client_kwargs.setdefault("base_url", "http://fastapi")

        client = httpx2.AsyncClient(
            transport=httpx2.ASGITransport(app=app),
            **httpx_client_kwargs,
        )

        server_name = name or app.title

        provider: Provider = OpenAPIProvider(
            openapi_spec=app.openapi(),
            client=client,
            route_maps=route_maps,
            route_map_fn=route_map_fn,
            mcp_component_fn=mcp_component_fn,
            mcp_names=mcp_names,
            tags=tags,
        )
        return cls(name=server_name, providers=[provider], **settings)

    @classmethod
    def generate_name(cls, name: str | None = None) -> str:
        class_name = cls.__name__

        if name is None:
            return f"{class_name}-{secrets.token_hex(2)}"
        else:
            return f"{class_name}-{name}-{secrets.token_hex(2)}"


# -----------------------------------------------------------------------------
# Module-level Factory Functions
# -----------------------------------------------------------------------------


def create_proxy(
    target: (
        Client[ClientTransportT]
        | ClientTransport
        | FastMCP[Any]
        | SDKServer
        | AnyUrl
        | Path
        | MCPConfig
        | dict[str, Any]
        | str
    ),
    *,
    mode: str | None = None,
    **settings: Any,
) -> FastMCPProxy:
    """Create a FastMCP proxy server for the given target.

    This is the recommended way to create a proxy server. For lower-level control,
    use `FastMCPProxy` or `ProxyProvider` directly from `fastmcp.server.providers.proxy`.

    Args:
        target: The backend to proxy to. Can be:
            - A Client instance (connected or disconnected)
            - A ClientTransport
            - A FastMCP server instance
            - A URL string or AnyUrl
            - A Path to a server script
            - An MCPConfig or dict
        mode: Protocol-era negotiation for auto-created proxy clients (a
            non-Client target). By default (``None``) the backend MIRRORS the
            front connection's negotiated era per request, so the whole chain
            speaks one era end-to-end: a modern front reaches a modern backend
            (a guard tool's `InputRequiredResult` (SEP-2322) round-trips) and a
            handshake front reaches a handshake backend (server-initiated
            sampling / elicitation / roots push-forwarding works). Pass an
            explicit mode (e.g. ``"auto"`` or a version string) to pin the
            backend era regardless of the front; this overrides mirroring and is
            appropriate when the backend only speaks one era. Ignored when
            `target` is already a `Client` (which carries its own mode).
        **settings: Additional settings passed to FastMCPProxy (name, etc.)

    Returns:
        A FastMCPProxy server that proxies to the target.

    Example:
        ```python
        from fastmcp.server import create_proxy

        # Create a proxy to a remote server
        proxy = create_proxy("http://remote-server/mcp")

        # Create a proxy to another FastMCP server
        proxy = create_proxy(other_server)
        ```
    """
    from fastmcp.server.providers.proxy import (
        FastMCPProxy,
        _create_client_factory,
    )

    client_factory = _create_client_factory(target, mode=mode)
    return FastMCPProxy(
        client_factory=client_factory,
        **settings,
    )
