"""FileUpload — a Provider that adds drag-and-drop file upload to any server.

Lets users upload files directly to the server through an interactive UI,
bypassing the LLM context window entirely. The LLM can then read and work
with uploaded files through model-visible tools.

Requires ``fastmcp[apps]`` (prefab-ui).

Usage::

    from fastmcp import FastMCP
    from fastmcp.apps import FileUpload

    mcp = FastMCP("My Server")
    mcp.add_provider(FileUpload())

For custom persistence, override the storage methods::

    class S3Upload(FileUpload):
        def on_store(self, files, ctx):
            # write to S3, return summaries
            ...

        def on_list(self, ctx):
            # list from S3
            ...

        def on_read(self, name, ctx):
            # read from S3
            ...
"""

from __future__ import annotations

try:
    from prefab_ui.actions import SetState, ShowToast
    from prefab_ui.actions.mcp import CallTool
    from prefab_ui.app import PrefabApp
    from prefab_ui.components import (
        H3,
        Badge,
        Button,
        Card,
        CardContent,
        CardFooter,
        CardHeader,
        Column,
        DropZone,
        Muted,
        Row,
        Separator,
        Small,
        Text,
    )
    from prefab_ui.components.control_flow import Else, ForEach, If
    from prefab_ui.rx import ERROR, RESULT, STATE, Rx
except ImportError as _exc:
    raise ImportError(
        "FileUpload requires prefab-ui. Install with: pip install 'fastmcp[apps]'"
    ) from _exc

import base64
import math
from datetime import datetime, timezone
from threading import RLock
from time import monotonic
from typing import Any

from fastmcp.apps.app import FastMCPApp
from fastmcp.exceptions import ToolError
from fastmcp.server.context import Context

_TEXT_EXTENSIONS = frozenset(
    (".csv", ".json", ".txt", ".md", ".py", ".yaml", ".yml", ".toml")
)


def _b64_decoded_size(b64: str) -> int:
    """Return the exact decoded byte-length of a base64 string without decoding it."""
    n = len(b64)
    if n == 0:
        return 0
    padding = b64.count("=", max(0, n - 2))
    return n * 3 // 4 - padding


def _format_size(size: int) -> str:
    if size < 1024:
        return f"{size} B"
    elif size < 1024 * 1024:
        return f"{size / 1024:.1f} KB"
    else:
        return f"{size / (1024 * 1024):.1f} MB"


def _make_summary(entry: dict[str, Any]) -> dict[str, Any]:
    return {
        "name": entry["name"],
        "type": entry["type"],
        "size": entry["size"],
        "size_display": _format_size(entry["size"]),
        "uploaded_at": entry["uploaded_at"],
    }


class FileUpload(FastMCPApp):
    """A Provider that adds file upload capabilities to a server.

    Registers a drag-and-drop UI tool, a backend storage tool, and
    model-visible tools for listing and reading uploaded files.

    Files are scoped by MCP session and stored in memory by default.
    Set `max_total_size` to limit decoded file bytes across all scopes or
    `file_ttl_seconds` to expire files by age since upload. Both default to
    None. Expired files are removed on storage operations, without a timer.
    These options apply to the default in-memory storage methods.
    Override ``on_store``, ``on_list``, and ``on_read`` for custom
    persistence (filesystem, S3, database, etc.). Each method receives
    the current ``Context``, giving access to session ID, auth tokens,
    and request metadata for partitioning and authorization.

    **Session scoping:** The default storage isolates files by MCP session
    on handshake-era connections. MCP 2026-07-28 connections have no
    session, so files are scoped to the authenticated user instead, or
    shared by the server process on stdio. Unauthenticated 2026-07-28 HTTP
    requests carry no client identity, so the default storage rejects them.
    In **stateless HTTP** mode, each request creates a new session, so
    files won't persist across requests. For stateless deployments,
    override the storage methods to partition by a stable identifier from
    the auth context::

        class UserScopedUpload(FileUpload):
            def on_store(self, files, ctx):
                user_id = ctx.access_token["sub"]
                ...

    Example::

        from fastmcp import FastMCP
        from fastmcp.apps.file_upload import FileUpload

        mcp = FastMCP("My Server")
        mcp.add_provider(FileUpload())
    """

    def __init__(
        self,
        name: str = "Files",
        *,
        max_file_size: int = 10 * 1024 * 1024,
        max_total_size: int | None = None,
        file_ttl_seconds: float | None = None,
        title: str = "File Upload",
        description: str = (
            "Drop files to upload them to the server. "
            "The model can then read and analyze them "
            "without using the context window."
        ),
        drop_label: str = "Drop files here",
    ) -> None:
        if max_total_size is not None and max_total_size < 0:
            raise ValueError("max_total_size must be nonnegative")
        if file_ttl_seconds is not None and (
            not math.isfinite(file_ttl_seconds) or file_ttl_seconds <= 0
        ):
            raise ValueError("file_ttl_seconds must be positive and finite")
        super().__init__(name)
        self._max_file_size = max_file_size
        self._max_total_size = max_total_size
        self._file_ttl_seconds = file_ttl_seconds
        self._store_lock = RLock()
        self._title = title
        self._description = description
        self._drop_label = drop_label

        # Default in-memory store, keyed by session_id
        self._store: dict[str, dict[str, dict[str, Any]]] = {}

        self._register_tools()

    def __repr__(self) -> str:
        return f"FileUpload({self.name!r})"

    # ------------------------------------------------------------------
    # Storage interface — override these for custom persistence
    # ------------------------------------------------------------------

    def _get_scope_key(self, ctx: Context) -> str:
        """Return the key used to partition file storage.

        Defaults to the MCP session on handshake-era connections. A 2026-07-28
        connection has no session, so files are scoped to the authenticated
        user, or shared by the server process on stdio, which serves a single
        client. An unauthenticated 2026-07-28 HTTP request has nothing to scope
        files to and raises a `ToolError`. The default
        ``on_store``/``on_list``/``on_read`` implementations call this to
        partition the in-memory store.

        Override to scope by user, tenant, or any other dimension::

            def _get_scope_key(self, ctx):
                return ctx.access_token["sub"]
        """
        try:
            scope = ctx._session_scope_key()
        except RuntimeError:
            return "__default__"
        if scope is None:
            raise ToolError(
                "File uploads are scoped to a client, and this unauthenticated "
                "request carries no client identity: MCP 2026-07-28 HTTP "
                "connections have no session. Add authentication to the server, "
                "or override FileUpload._get_scope_key."
            )
        return scope

    def _prune_expired(self, now: float) -> None:
        """Remove expired files while holding the default storage lock."""
        if self._file_ttl_seconds is None:
            return
        for scope, entries in list(self._store.items()):
            for name, entry in list(entries.items()):
                if entry["_expires_at"] <= now:
                    del entries[name]
            if not entries:
                del self._store[scope]

    def on_store(
        self,
        files: list[dict[str, Any]],
        ctx: Context,
    ) -> list[dict[str, Any]]:
        """Store uploaded files and return summaries.

        Args:
            files: List of file dicts, each with ``name``, ``size``,
                ``type``, and ``data`` (base64-encoded content).
            ctx: The current request context. Use for session ID,
                auth tokens, or any metadata needed for partitioning.

        Override this method for custom persistence. The default
        implementation stores files in memory, scoped by
        ``_get_scope_key(ctx)``. The optional `max_total_size` applies to
        decoded file bytes across every scope. An entire batch is rejected
        when its final contents would exceed the limit, including replacements.

        Returns:
            List of file summary dicts (``name``, ``type``, ``size``,
            ``size_display``, ``uploaded_at``).
        """
        scope = self._get_scope_key(ctx)
        with self._store_lock:
            now = monotonic()
            self._prune_expired(now)
            updates: dict[str, dict[str, Any]] = {}
            for f in files:
                entry = {
                    "name": f["name"],
                    "size": f["size"],
                    "type": f["type"],
                    "data": f["data"],
                    "uploaded_at": datetime.now(timezone.utc).isoformat(
                        timespec="seconds"
                    ),
                }
                if self._file_ttl_seconds is not None:
                    entry["_expires_at"] = now + self._file_ttl_seconds
                updates[f["name"]] = entry

            session_files = self._store.get(scope, {})
            if self._max_total_size is not None:
                total_size = sum(
                    max(0, _b64_decoded_size(entry["data"]))
                    for entries in self._store.values()
                    for entry in entries.values()
                )
                for name, entry in updates.items():
                    total_size += max(0, _b64_decoded_size(entry["data"]))
                    if name in session_files:
                        total_size -= max(
                            0, _b64_decoded_size(session_files[name]["data"])
                        )
                if total_size > self._max_total_size:
                    raise ValueError(
                        "Files exceed total storage size "
                        f"({_format_size(total_size)} > "
                        f"{_format_size(self._max_total_size)})"
                    )

            session_files = self._store.setdefault(scope, {})
            session_files.update(updates)
            return [_make_summary(e) for e in session_files.values()]

    def on_list(self, ctx: Context) -> list[dict[str, Any]]:
        """List all stored files.

        Args:
            ctx: The current request context.

        Override this method for custom persistence. The default
        implementation returns files from the current scope.

        Returns:
            List of file summary dicts.
        """
        scope = self._get_scope_key(ctx)
        with self._store_lock:
            self._prune_expired(monotonic())
            session_files = self._store.get(scope, {})
            return [_make_summary(e) for e in session_files.values()]

    def on_read(self, name: str, ctx: Context) -> dict[str, Any]:
        """Read a file's contents by name.

        Args:
            name: The filename to read.
            ctx: The current request context.

        Override this method for custom persistence. The default
        implementation reads from the current scope's in-memory store.
        Text files are decoded from base64; binary files return a
        truncated base64 preview.

        Returns:
            Dict with file metadata and ``content`` (text) or
            ``content_base64`` (binary preview).

        Raises:
            ValueError: If the file is not found.
        """
        scope = self._get_scope_key(ctx)
        with self._store_lock:
            self._prune_expired(monotonic())
            session_files = self._store.get(scope, {})
            if name not in session_files:
                available = list(session_files.keys())
                raise ValueError(f"File {name!r} not found. Available: {available}")
            entry = session_files[name]
        result: dict[str, Any] = {
            "name": entry["name"],
            "size": entry["size"],
            "type": entry["type"],
            "uploaded_at": entry["uploaded_at"],
        }
        is_text = entry["type"].startswith("text/") or any(
            entry["name"].endswith(ext) for ext in _TEXT_EXTENSIONS
        )
        if is_text:
            try:
                result["content"] = base64.b64decode(entry["data"]).decode("utf-8")
            except UnicodeDecodeError:
                result["content_base64"] = entry["data"][:200] + "..."
        else:
            result["content_base64"] = entry["data"][:200] + "..."
        return result

    # ------------------------------------------------------------------
    # Tool registration
    # ------------------------------------------------------------------

    def _register_tools(self) -> None:
        provider = self

        @self.tool()
        def store_files(files: list[dict], ctx: Context) -> list[dict]:
            """Store uploaded files. Receives file objects with name, size, type, data (base64)."""
            for f in files:
                # Compute actual data size from the base64 payload rather
                # than trusting the client-reported ``size`` field.
                actual_size = _b64_decoded_size(f.get("data", ""))
                if actual_size > provider._max_file_size:
                    raise ValueError(
                        f"File {f.get('name', '?')!r} exceeds max size "
                        f"({_format_size(actual_size)} > "
                        f"{_format_size(provider._max_file_size)})"
                    )
            return provider.on_store(files, ctx)

        @self.tool(model=True)
        def list_files(ctx: Context) -> list[dict]:
            """List all uploaded files with metadata."""
            return provider.on_list(ctx)

        @self.tool(model=True)
        def read_file(name: str, ctx: Context) -> dict:
            """Read an uploaded file's contents by name."""
            return provider.on_read(name, ctx)

        @self.ui()
        def file_manager(ctx: Context) -> PrefabApp:
            """Upload and manage files. Drop files here to send them to the server."""
            with Card(css_class="max-w-2xl mx-auto") as view:
                with CardHeader(), Row(gap=2, align="center"):
                    H3(provider._title)
                    with If(STATE.stored.length()):
                        Badge(
                            STATE.stored.length(),
                            variant="secondary",
                        )

                with CardContent(), Column(gap=4):
                    Muted(provider._description)

                    DropZone(
                        name="pending",
                        icon="inbox",
                        label=provider._drop_label,
                        description=(
                            "Any file type, up to "
                            f"{_format_size(provider._max_file_size)}"
                        ),
                        multiple=True,
                        max_size=provider._max_file_size,
                    )

                    with If(STATE.pending.length()), Column(gap=2):
                        with (
                            ForEach("pending"),
                            Row(gap=2, align="center"),
                            Column(gap=0),
                        ):
                            Small(Rx("$item.name"))
                            Muted(Rx("$item.type"))

                        Button(
                            "Upload to Server",
                            on_click=CallTool(
                                "store_files",
                                arguments={
                                    "files": Rx("pending"),
                                },
                                on_success=[
                                    SetState("stored", RESULT),
                                    SetState("pending", []),
                                    ShowToast(
                                        "Files uploaded!",
                                        variant="success",
                                    ),
                                ],
                                on_error=ShowToast(
                                    ERROR,
                                    variant="error",
                                ),
                            ),
                        )

                    with If(STATE.stored.length()):
                        Separator()
                        Text(
                            "Uploaded",
                            css_class="font-medium text-sm",
                        )
                        with (
                            ForEach("stored") as f,
                            Row(
                                gap=2,
                                align="center",
                                css_class="justify-between",
                            ),
                        ):
                            with Column(gap=0):
                                Small(f.name)
                                Muted(f.uploaded_at)
                            with Row(gap=2):
                                Badge(f.type, variant="secondary")
                                Badge(
                                    f.size_display,
                                    variant="outline",
                                )

                with CardFooter(), Row(align="center", css_class="w-full"):
                    with If(STATE.stored.length()):
                        Muted(
                            f"{STATE.stored.length()}"
                            f" {STATE.stored.length().pluralize('file')}"
                            " on server"
                        )
                    with Else():
                        Muted("No files uploaded yet")

            return PrefabApp(
                view=view,
                state={
                    "pending": [],
                    "stored": provider.on_list(ctx),
                },
            )
