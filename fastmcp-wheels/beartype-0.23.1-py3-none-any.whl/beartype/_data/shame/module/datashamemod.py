#!/usr/bin/env python3
# --------------------( LICENSE                            )--------------------
# Copyright (c) 2014-2026 Beartype authors.
# See "LICENSE" for further details.

'''
**Shameful module blacklist globals** (i.e., immutable data structures defining
the initial user-configurable contents of blacklists preventing problematic
third-party modules and packages known to be hostile to runtime type-checking in
general and :mod:`beartype` specifically from being inappropriately type-checked
by :mod:`beartype`).

This private submodule is *not* intended for importation by downstream callers.
'''

# ....................{ TODO                               }....................
#FIXME: [CONF] Actually do allow users to configure *ALL* of the blacklists
#defined below by defining one new "BeartypeConf" option for each whose default
#values are those data structures defined below. Currently, the codebase just
#uses those data structures directly. *shrug*

# ....................{ SETS                               }....................
#FIXME: Apply this blacklist to the following things:
#* Arbitrary callables to be decorated by @beartype, possibly. Consider defining
#  a new beartype._util.bear.utilbearfunc.is_func_thirdparty_blacklisted()
#  tester returning True *ONLY* if the passed callable has a "__module__" dunder
#  attribute whose value is a string residing in this frozenset.
BLACKLIST_PACKAGE_NAMES = frozenset((
    # ....................{ ANTIPATTERN ~ stdlib           }....................
    # These first-party packages and modules residing in the standard Python
    # library employ the "if False:" antipattern and are thus runtime-hostile.

    #FIXME: Technically resolved by Python 3.15.0rc1 (thanks to the super-hard
    #efforts of @DavidCEllis), but preserved in the likelihood that we'll need
    #something like this again in the near future. Consider this a horrifying
    #template we hope we'll never need but know deep down we absolutely will.
    #FIXME: *WAIT*. Still busted, yo. Oh, wells. Who cares anymore!? We gotta
    #ship @beartype 0.23.0 out the door. Let's do this, yoooooooooooooooooooo!
    # The private pure-Python "_colorize" module introduced by Python 3.15
    # employs the "if False:" antipattern: e.g.,
    #     # types
    #     if False:
    #         from typing import IO, Literal, Self, ClassVar
    #         _theme: Theme
    #
    # That should instead read:
    #     # types
    #     lazy from typing import IO, Literal, Self, ClassVar
    #     if False:
    #         _theme: Theme
    #
    # See also the following issue resolved by this blacklist:
    #     https://github.com/beartype/beartype/issues/656
    '_colorize',

    # ....................{ ANTIPATTERN ~ forward ref      }....................
    # These third-party packages and modules widely employ the forward reference
    # antipattern throughout their codebases and are thus runtime-hostile.

    # Pydantic employs the forward reference antipattern everywhere: e.g.,
    #     from __future__ import annotations as _annotations
    #     import typing
    #     ...
    #
    #     if typing.TYPE_CHECKING:
    #         ...
    #         from ..main import BaseModel  # <-- undefined at runtime
    #
    #     ...
    #     def wrapped_model_post_init(
    #         self: BaseModel, context: Any, /) -> None:  # <-- unresolvable at runtime
    #
    # See also this @beartype-specific issue on Pydantic:
    #     https://github.com/beartype/beartype/issues/444
    'pydantic',

    # "urllib3" employs the forward reference antipattern everywhere: e.g.,
    #     import typing
    #     ...
    #
    #     if typing.TYPE_CHECKING:
    #         from typing import Final  # <-- undefined at runtime
    #
    #     ...
    #
    #     _DEFAULT_TIMEOUT: Final[_TYPE_DEFAULT] = _TYPE_DEFAULT.token
    #
    # See also this @beartype-specific comment on "urllib3":
    #     https://github.com/beartype/beartype/issues/223#issuecomment-2525261497
    'urllib3',

    # xarray employs the forward reference antipattern everywhere: e.g.,
    #     from __future__ import annotations
    #     from typing import IO, TYPE_CHECKING, Any, Generic, Literal, cast, overload
    #     ...
    #
    #     if TYPE_CHECKING:
    #         ...
    #         from xarray.core.dataarray import DataArray  # <-- undefined at runtime
    #
    #     ...
    #
    #     class Dataset(
    #         DataWithCoords,
    #         DatasetAggregations,
    #         DatasetArithmetic,
    #         Mapping[Hashable, "DataArray"],  # <-- unresolvable at runtime
    #     ):
    #
    # See also this @beartype-specific issue on xarray:
    #     https://github.com/beartype/beartype/issues/456
    'xarray',
))
'''
Frozen set of the fully-qualified names of all **beartype-blacklisted
third-party packages** well-known to be hostile to runtime type-checking in
general and :mod:`beartype` specifically, usually due to employing one or more
of the following antipatterns:

* The **forward reference antipattern,** a `harmful design pattern officially
  promoted throughout "mypy" documentation <antipattern_>`__. This antipattern
  leverages both :pep:`563` *and* the :pep:`484`-compliant
  :obj:`typing.TYPE_CHECKING` global (both of which are well-known to be hostile
  to runtime type-checking) to conditionally define relative forward references
  visible *only* to pure static type-checkers like ``mypy`` and ``pyright``.
  These references are undefined at runtime and thus inaccessible to hybrid
  runtime-static type-checkers like :mod:`beartype` or :mod:`typeguard`.

  As an example, consider this hypothetical usage of the forward reference
  antipattern in a mock third-party package named ``"awful_package"``:

  .. code-block:: python

     from __future__ import annotations  # <-- pep 563
     from typing import TYPE_CHECKING    # <-- pep 484

     if TYPE_CHECKING:                         # <---- "False" at runtime
         from awful_package import AwfulClass  # <-- undefined at runtime

     # PEP 563 (i.e., "from __future__ import annotations") stringifies the
     # undefined "AwfulClass" class to the string "'AwfulClass'" at runtime.
     # Since the "AwfulClass" class is undefined, however, neither @beartype nor
     # any other runtime type-checker can resolve this relative forward
     # reference to the external "awful_package.AwfulClass" class it refers to.
     def awful_func(awful_arg: AwfulClass): ...

.. _antipattern:
   https://mypy.readthedocs.io/en/latest/runtime_troubles.html#import-cycles
'''
