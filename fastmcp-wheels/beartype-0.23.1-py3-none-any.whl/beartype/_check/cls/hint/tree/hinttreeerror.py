#!/usr/bin/env python3
# --------------------( LICENSE                            )--------------------
# Copyright (c) 2014-2026 Beartype authors.
# See "LICENSE" for further details.

'''
Beartype **exception-generating type hint tree dataclasses** (i.e., low-level
subclasses recursively fabricating human-readable strings and associated
metadata detailing why the currently type-checked objects violate the type
hints annotating those objects).

This private submodule is *not* intended for importation by downstream callers.
'''

# ....................{ TODO                               }....................
#FIXME: The recursive "HintTreeError" class strongly overlaps with the equally
#recursive (and substantially superior) "beartype.door.TypeHint" class. Ideally:
#* Define a new private "beartype.door._doorerror" submodule.
#* Shift the "HintTreeError" class to
#  "beartype.door._doorerror._TypeHintUnbearability".
#* Shift the _TypeHintUnbearability.find_cause() method to a new
#  *PRIVATE* TypeHint._find_cause() method.
#* Preserve most of the remainder of the "_TypeHintUnbearability" class as a
#  dataclass encapsulating metadata describing the current type-checking
#  violation. That metadata (e.g., "cause_indent") is inappropriate for
#  general-purpose type hints. Exceptions include:
#  * "hint", "hint_sign", and "_hint_childs_sane" -- all of which are subsumed
#    by the "TypeHint" dataclass and should thus be excised.
#* Refactor the TypeHint._find_cause() method to accept an instance of
#  the "_TypeHintUnbearability" dataclass: e.g.,
#      class TypeHint(...):
#          def _get_unbearability_cause_or_none(
#              self, unbearability: _TypeHintUnbearability) -> Optional[str]:
#              ...
#* Refactor existing find_cause_*() getters (e.g.,
#  find_cause_sequence_args_1(), find_cause_pep484604_union()) into
#  _get_unbearability_cause_or_none() methods of the corresponding "TypeHint"
#  subclasses, please.
#
#This all seems quite reasonable. Now, let's see whether it is. *gulp*
#FIXME: Actually, the above comment now ties directly into feature request #235.
#Resolving the above comment mostly suffices to resolve #235. That said, the
#above isn't *QUITE* right. It's pretty nice -- but we can do better. See the
#following comment at #235 for that better:
#    https://github.com/beartype/beartype/issues/235#issuecomment-1707127231
#FIXME: *LOL*. Guess we're not doing any of that for the moment, huh? We just
#went ahead and started merging "HintTreeError" with "HintTreeCode". Well, that's
#fine. As long as we start streamlining this class with *SOMETHING* else, it
#doesn't particularly matter what that *SOMETHING* else even is. There's a good
#deal more of commonality to be refactored out, of course. Still, this is an
#excellent start, anyway. Great job for finally doing something, us! \o/

# ....................{ IMPORTS                            }....................
from beartype.roar._roarexc import _BeartypeCallHintPepRaiseException
from beartype._cave._cavemap import NoneTypeOr
from beartype._check.convert.convmain import sanify_hint_child
from beartype._check.cls.call.calldataabc import BeartypeCallDataABC
from beartype._check.cls.hint.hintsane import (
    HINT_SANE_IGNORABLE,
    HintSane,
    TupleHintSane,
)
from beartype._check.cls.hint.data.hintdataerror import HintDataError
from beartype._check.cls.hint.tree.hinttreeabc import HintTreeABC
from beartype._conf.confmain import BeartypeConf
from beartype._data.typing.datatyping import TypeException
from beartype._data.typing.datatypingport import Hint
from beartype._data.hint.sign.datahintsignset import (
    HINT_SIGNS_SUPPORTED_DEEP,
    HINT_SIGNS_ORIGIN_ISINSTANCEABLE,
)
from beartype._data.kind.datakindiota import (
    SENTINEL,
    Iota,
)
from beartype._util.hint.pep.utilpepget import get_hint_pep_childs
from beartype._util.hint.pep.utilpeptest import is_hint_pep
from beartype._util.utilobjmake import permute_object
from collections.abc import Callable
from typing import (
    TYPE_CHECKING,
    Any,
    Optional,
    Union,
)

# ....................{ SUBCLASSES                         }....................
class HintTreeError(HintTreeABC):
    '''
    **Type-checking violation cause** (i.e., object recursively fabricating the
    human-readable string describing the failure of the pith associated with
    this cause to satisfy the type hint associated with this cause).

    Attributes
    ----------
    cause_indent : str
        **Indentation** (i.e., string of zero or more spaces) preceding each
        line of the string returned by this getter if this string spans
        multiple lines *or* ignored otherwise (i.e., if this string is instead
        embedded in the current line).
    cause_str_or_none : Optional[str]
        If this pith either:

        * Violates this hint, a human-readable string describing this violation.
        * Satisfies this hint, :data:`None`.
    exception_cls : type[Exception]
        Type of violation to be raised.
    hint_curr : HintDataError
        Metadata describing this hint.
    pith : Any
        Arbitrary object to be validated.
    pith_name : Optional[str]
        Either:

        * If this hint directly annotates a callable parameter (as the root type
          hint of that parameter), the name of this parameter.
        * If this hint directly annotates a callable return (as the root type
          hint of that return), the magic string ``"return"``.
        * Else, :data:`None`.
    random_int : Optional[int]
        **Pseudo-random integer** (i.e., unsigned 32-bit integer
        pseudo-randomly generated by the parent :func:`beartype.beartype`
        wrapper function in type-checking randomly indexed container items by
        the current call to that function) if that function generated such an
        integer *or* ``None`` otherwise (i.e., if that function generated *no*
        such integer). See the same parameter accepted by the higher-level
        :func:`beartype._check.error.errmain.get_func_pith_violation` function.
    _hint_childs_sane : Union[Iota, TupleHintSane]
        Either:

        * If the :meth:`.hint_childs_sane` property has yet to be accessed, the
          sentinel placeholder.
        * Else, the :meth:`.hint_childs_sane` property has been accessed at
          least once. In this case, either:

          * If this hint is PEP-compliant, the possibly empty tuple of all child
            hints subscripting (indexing) this hint such that each item is
            either:

            * If sanifying this child hint generated supplementary metadata,
              that metadata (i.e., :class:`.HintSane` object).
            * Else, this child hint as is.

          * Else, the empty tuple.
    '''

    # ..................{ CLASS VARIABLES                    }..................
    # Slot *ALL* instance variables defined on this object to both:
    # * Prevent accidental declaration of erroneous instance variables.
    # * Minimize space and time complexity.
    __slots__ = (
        'cause_indent',
        'cause_str_or_none',
        'exception_cls',
        'pith',
        'pith_name',
        'random_int',
        '_hint_childs_sane',
    )

    # Squelch false negatives from mypy. This is absurd. This is mypy. See:
    #     https://github.com/python/mypy/issues/5941
    if TYPE_CHECKING:
        cause_indent: str
        cause_str_or_none: Optional[str]
        exception_cls: TypeException
        hint_curr: HintDataError
        pith: Any
        pith_name: Optional[str]
        random_int: Optional[int]
        _hint_childs_sane: Union[Iota, TupleHintSane]

    # ..................{ CLASS VARIABLES ~ set              }..................
    _COPY_VAR_NAMES = frozenset((
        'call_curr',
        'cause_indent',
        'cause_str_or_none',
        'conf',
        'exception_cls',
        'exception_prefix',
        'hint_curr',
        'pith',
        'pith_name',
        'random_int',
    ))
    '''
    Frozen set of the names of *all* instance variables whose values will be
    reused as the default values of all **unpassed parameters** (i.e.,
    parameters *not* explicitly passed by callers to the :meth:`.permute_cause`
    method), defined as a frozen set to enable efficient membership testing.
    '''


    _INIT_ARG_NAMES = _COPY_VAR_NAMES
    '''
    Frozen set of the names of *all* parameters accepted by the :meth:`init`
    method, defined as a frozen set to enable efficient membership testing.
    '''

    # ..................{ INITIALIZERS                       }..................
    #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    # CAUTION: Whenever adding, deleting, or renaming any parameter accepted by
    # this method, make similar changes to the "_INIT_ARG_NAMES" set above.
    #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    def __init__(
        self,

        # Mandatory parameters.
        call_curr: BeartypeCallDataABC,
        cause_indent: str,
        conf: BeartypeConf,
        hint_curr: HintDataError,
        pith: Any,
        pith_name: Optional[str],
        random_int: Optional[int],
        exception_cls: TypeException,
        exception_prefix: str,

        # Optional parameters.
        cause_str_or_none: Optional[str] = None,
    ) -> None:
        '''
        Initialize this violation cause.

        Parameters
        ----------
        See the class docstring for a description of all remaining parameters.
        '''
        assert isinstance(cause_indent, str), (
            f'{repr(cause_indent)} not string.')
        assert isinstance(cause_str_or_none, NoneTypeOr[str]), (
            f'{repr(cause_str_or_none)} not string or "None".')
        assert isinstance(hint_curr, HintDataError), (
            f'{repr(hint_curr)} not "HintDataError" object.')
        assert isinstance(pith_name, NoneTypeOr[str]), (
            f'{repr(pith_name)} not string or "None".')
        assert isinstance(random_int, NoneTypeOr[int]), (
            f'{repr(random_int)} not integer or "None".')
        assert isinstance(exception_cls, type), (
            f'{repr(exception_cls)} not type.')
        assert issubclass(exception_cls, Exception), (
            f'{repr(exception_cls)} not exception type.')

        # Initialize our superclass.
        super().__init__(
            call_curr=call_curr,
            conf=conf,
            exception_prefix=exception_prefix,
        )

        # Classify all passed parameters.
        self.cause_indent = cause_indent
        self.cause_str_or_none = cause_str_or_none
        self.exception_cls = exception_cls
        self.hint_curr = hint_curr  # pyright: ignore
        self.pith = pith
        self.pith_name = pith_name
        self.random_int = random_int

        # Nullify all remaining parameters for safety.
        self._hint_childs_sane = SENTINEL

    # ..................{ DUNDERS                            }..................
    def __repr__(self) -> str:
        '''
        Machine-readable representation of this error cause.
        '''

        # Represent this metadata with just the minimal subset of metadata
        # needed to reasonably describe this metadata.
        return (
            f'{self.__class__.__name__}('
            f'hint_curr={repr(self.hint_curr)}, '
            f'call_curr={repr(self.call_curr)}, '
            f'cause_indent={repr(self.cause_indent)}, '
            f'cause_str_or_none={repr(self.cause_str_or_none)}, '
            f'conf={repr(self.conf)}, '
            f'pith={repr(self.pith)}, '
            f'pith_name={repr(self.pith_name)}, '
            f'random_int={repr(self.random_int)}, '
            f'exception_cls={repr(self.exception_cls)}, '
            f'exception_prefix={repr(self.exception_prefix)}, '
            f')'
        )

    # ..................{ PROPERTIES                          }..................
    @property
    def hint_curr_sanified(self) -> Hint:
        '''
        Currently visited type hint to validate the currently visited pith
        against.

        Note that this dynamic property is a convenient shorthand for the
        static nested instance variable ``hint_curr.hint_sane.hint``.
        '''

        # If at ain't a one-liner, it ain't broke. Isn't that how it goes!?
        return self.hint_curr.hint_sane.hint


    #FIXME: This should almost certainly be cached via @property_cached. Doing
    #so simplifies all of that awkward "SENTINEL" caching logic below. *shrug*
    @property
    def hint_childs_sane(self) -> TupleHintSane:
        '''
        Either:

        * If this hint is PEP-compliant, the possibly empty tuple of all child
          hints subscripting (indexing) this hint such that each item is either:

          * If sanifying this child hint generated supplementary metadata, that
            metadata (i.e., a :class:`.HintSane` object).
          * Else, this child hint as is.

        * Else, the empty tuple.
        '''

        # If this instance variable is *NOT* the sentinel placeholder, this
        # tuple has already been computed by a prior access of this property.
        # In this case, reduce to a noop by returning this pre-computed tuple.
        if self._hint_childs_sane is not SENTINEL:
            return self._hint_childs_sane  # type: ignore[return-value]
        # Else, this instance variable is still the sentinel placeholder,
        # implying this tuple has yet to be computed.
        #
        # If this hint is either...
        elif (
            # Ignorable *OR*...
            self.hint_curr.hint_sane is HINT_SANE_IGNORABLE or
            # PEP-noncompliant...
            not is_hint_pep(self.hint_curr_sanified)
        # Then this hint *CANNOT* by definition be subscripted by any meaningful
        # child hints. In this case...
        ):
            # Cache that this tuple is ignorable.
            self._hint_childs_sane = ()

            # Return the same value.
            return ()
        # Else, this is an unignorable PEP-compliant hint. Since this hint
        # *COULD* be subscripted by meaningful child hints, continue.

        # Tuple of the zero or more arguments subscripting this hint.
        hint_childs_insane = get_hint_pep_childs(self.hint_curr_sanified)

        # List of the zero or more possibly ignorable metadata generated by
        # sanifying these child hints, initialized to the empty list.
        hint_childs_sane_list = []

        # For each possibly ignorable insane child hints subscripting this
        # parent hint...
        for hint_child_insane in hint_childs_insane:
            # Metadata encapsulating the sanification of this child hint.
            hint_child_sane: HintSane = None  # type: ignore[assignment]

            # If this child hint is either...
            #
            # Note that arbitrary PEP-noncompliant arguments *CANNOT* be safely
            # sanified. Arbitrary arguments are *NOT* necessarily valid hints.
            # Consider the hint "tuple[()]", where the argument "()" is invalid
            # as a hint but valid an argument to that hint.
            if (
                # PEP-compliant *OR*...
                is_hint_pep(hint_child_insane) or
                # A type, which is effectively PEP 484-compliant.
                isinstance(hint_child_insane, type)
            ):
                # Sanify this child hint into this metadata.
                hint_child_sane = self.sanify_hint_child(
                    hint_child_insane=hint_child_insane,
                    hint_parent_sane=self.hint_curr.hint_sane,
                )
            # Else, this child hint is PEP-noncompliant. In this case, preserve
            # this child hint as is.
            else:
                hint_child_sane = hint_child_insane

            # Append this possibly ignorable sane child hint to this lists.
            hint_childs_sane_list.append(hint_child_sane)

        # Cache a tuple of the zero or more possibly ignorable sane child hints,
        # coerced from this list.
        self._hint_childs_sane = tuple(hint_childs_sane_list)

        # Return the same tuple.
        return self._hint_childs_sane

    # ..................{ FINDERS                            }..................
    def find_cause(self) -> 'HintTreeError':
        '''
        Output cause describing whether the pith of this input cause either
        satisfies or violates the type hint of this input cause.

        Design
        ------
        This method is intentionally generalized to support objects both
        satisfying and *not* satisfying hints as equally valid use cases. While
        the parent
        :func:`beartype._check.error.errmain.get_func_pith_violation` function
        calling this method is *always* passed an object *not* satisfying the
        passed hint, this method is under no such constraints. Why? Because this
        method is also called to find which of an arbitrary number of objects
        transitively nested in the object passed to
        :func:`beartype._check.error.errmain.get_func_pith_violation` fails to
        satisfy the corresponding hint transitively nested in the hint passed to
        that function.

        For example, consider the type hint ``list[Union[int, str]]`` describing
        a list whose items are either integers or strings and the list
        ``list(range(256)) + [False,]`` consisting of the integers 0 through 255
        followed by boolean :data:`False`. Since that list is a sequence, the
        :func:`._peperrorsequence.find_cause_sequence_args_1` function must
        decide the cause of this list's failure to comply with this hint by
        finding the list item that is neither an integer nor a string,
        implemented by by iteratively passing each list item to the
        :func:`._peperrorunion.find_cause_pep484604_union` function. Since the
        first 256 items of this list are integers satisfying this hint,
        :func:`._peperrorunion.find_cause_pep484604_union` returns a dataclass
        instance whose :attr:`cause` field is :data:`None` up to
        :func:`._peperrorsequence.find_cause_sequence_args_1` before finally
        finding the non-compliant boolean item and returning its cause.

        Returns
        -------
        HintTreeError
            Output cause type-checking this pith against this type hint.

        Raises
        ------
        _BeartypeCallHintPepRaiseException
            If this type hint is either:

            * PEP-noncompliant (e.g., tuple union).
            * PEP-compliant but no getter function has been implemented to
              handle this category of PEP-compliant type hint yet.
        '''
        # print(f'Finding cause for {self.hint_curr}...')

        # ..................{ NOOP                           }..................
        # If this hint is ignorable, all possible objects satisfy this hint.
        # Since this hint *CANNOT* (by definition) be the cause of this failure,
        # return the same cause as is.
        if self.hint_curr.hint_sane is HINT_SANE_IGNORABLE:
            return self
        # Else, this hint is unignorable.

        # ..................{ LOCALS                         }..................
        # Getter function returning the desired string.
        cause_finder: Callable[[HintTreeError], HintTreeError] = None  # type: ignore[assignment]

        # ..................{ SHALLOW                        }..................
        # If this hint...
        if (
            # Originates from an origin type and may thus be shallowly
            # type-checked against that type *AND is either...
            self.hint_curr.hint_sign in HINT_SIGNS_ORIGIN_ISINSTANCEABLE and (
                # Unsubscripted *OR*...
                not get_hint_pep_childs(self.hint_curr_sanified) or
                # Currently unsupported with deep type-checking...
                self.hint_curr.hint_sign not in HINT_SIGNS_SUPPORTED_DEEP
            )
        # Then this hint is both unsubscripted and originating from a standard
        # type origin. In this case, this hint was type-checked shallowly.
        ):
            # Avoid circular import dependencies.
            from beartype._check.error._nonpep.errnonpeptype import (
                find_cause_type_instance_origin)

            # Defer to the getter function supporting hints originating from
            # origin types.
            cause_finder = find_cause_type_instance_origin
        # ..................{ DEEP                           }..................
        # Else, this hint is either subscripted *OR* unsubscripted but not
        # originating from a standard type origin. In either case, this hint was
        # type-checked deeply.
        else:
            # Avoid circular import dependencies.
            from beartype._check.error._errmap import (
                HINT_SIGN_TO_GET_CAUSE_FUNC)

            # Getter function returning the desired string for this attribute if
            # any *OR* "None" otherwise.
            cause_finder = HINT_SIGN_TO_GET_CAUSE_FUNC.get(  # type: ignore[assignment]
                self.hint_curr.hint_sign, None)  # type: ignore[arg-type]

            # If no such function has been implemented to handle this attribute
            # yet, raise an exception.
            if cause_finder is None:
                raise _BeartypeCallHintPepRaiseException(
                    f'{self.exception_prefix}type hint '
                    f'{repr(self.hint_curr_sanified)} unsupported '
                    f'(i.e., no "find_cause_"-prefixed getter function defined '
                    f'for this category of hint).'
                )
            # Else, a getter function has been implemented to handle this
            # attribute.

        # ..................{ RETURN                         }..................
        # Call this getter function with ourselves and return the string
        # returned by this getter.
        return cause_finder(self)

    # ..................{ PERMUTERS                          }..................
    def permute_cause(self, **kwargs) -> 'HintTreeError':
        '''
        Shallow copy of this violation cause such that each passed keyword
        parameter overwrites the instance variable of the same name in this
        copy.

        Parameters
        ----------
        Keyword parameters of the same name and type as instance variables of
        this object (e.g., ``pith: object``).

        Returns
        -------
        HintTreeError
            Shallow copy of this violation cause such that each keyword
            parameter overwrites the instance variable of the same name in this
            copy.

        Raises
        ------
        _BeartypeCallHintPepRaiseException
            If the name of any passed keyword parameter is *not* that of an
            existing instance variable of this violation cause.

        Examples
        --------
        .. code-block:: pycon

           >>> sleuth = HintTreeError(
           ...     pith=[42,]
           ...     hint=typing.List[int],
           ...     cause_indent='',
           ...     exception_prefix='List of integers',
           ... )
           >>> sleuth_copy = sleuth.permute_cause(pith=[24,])
           >>> sleuth_copy.pith
           [24,]
           >>> sleuth_copy.hint
           typing.List[int]
        '''

        #FIXME: Unsure if this suffices. If the caller explicitly passes
        #"hint_curr", this probably suffices. However, if the caller fails to
        #explicitly pass "hint_curr", we probably want to redefine it *WITHOUT*
        #preserving the prior "hint_sign": e.g.,
        #    if 'hint_curr' not in kwargs:
        #        kwargs['hint_curr'] = HintDataError(self.hint_curr.hint_sane)
        #
        #Why? This now-deleted docstring fragment:
        #    Note that the :attr:`.hint_sign` instance variable is intentionally omitted.
        #    This variable's value is unique to the current cause and thus *not* safely
        #    copyable from parent to child hints by the :meth:`permute_cause` method.

        # Set us up the permutation! Make your time!
        return permute_object(
            obj=self,
            init_arg_name_to_value=kwargs,
            init_arg_names=self._INIT_ARG_NAMES,
            copy_var_names=self._COPY_VAR_NAMES,
            exception_cls=_BeartypeCallHintPepRaiseException,
        )


    def permute_cause_hint_child_insane(
        self, hint_child_insane: Hint, **kwargs) -> 'HintTreeError':
        '''
        Shallow copy of this violation cause such that each passed keyword
        parameter overwrites the instance variable of the same name in this copy
        *after* sanifying (i.e., sanitizing) the passed **possibly insane child
        hint** (i.e., child hint that has yet to be sanified subscripting the
        current hint encapsulated by this cause) and passing the metadata
        encapsulating that sanification as the ``hint_sane`` parameter of this
        dictionary.

        Parameters
        ----------
        hint_child_insane : Hint
            Possibly insane child hint to be sanified.

        All other keyword parameters are of the same name and type as instance
        variables of this object (e.g., ``pith: object``).

        Returns
        -------
        HintTreeError
            Shallow copy of this violation cause, permuted as detailed above.

        Raises
        ------
        _BeartypeCallHintPepRaiseException
            If the name of any passed keyword parameter is *not* that of an
            existing instance variable of this violation cause.

        See Also
        --------
        :meth:`permute_cause`
            Further details.
        '''

        # Metadata encapsulating the sanification of the passed hint relative to
        # the current previously sanified hint, which effectively serves as the
        # "parent" of the passed hint for all intents and purposes.
        hint_sane = self.sanify_hint_child(
            hint_child_insane=hint_child_insane,
            hint_parent_sane=self.hint_curr.hint_sane,
        )

        # Higher-level metadata encapsulating that lower-level metadata. *sigh*
        hint_curr = HintDataError(hint_sane)

        # Violation cause permuted from this metadata and these keywords.
        cause_permuted = self.permute_cause(hint_curr=hint_curr, **kwargs)

        # Return this permuted cause.
        return cause_permuted

    # ..................{ SANIFIERS                          }..................
    #FIXME: DRY violation. This is extremely similar to the
    #HintTreeCode.sanify_hint_child() implementation. Let's try to push up all
    #code shared in common to a new concrete HintTreeABC.sanify_hint_child()
    #implementation, please. *sigh*
    def sanify_hint_child(
        self,

        # Mandatory parameters.
        hint_child_insane: Hint,

        # Optional parameters.
        hint_parent_sane: Optional[HintSane] = None,
    ) -> HintSane:
        '''
        Metadata encapsulating the sanification (i.e., sanitization) of the
        passed **possibly insane child type hint** (i.e., possibly
        PEP-noncompliant hint transitively subscripting the root hint annotating
        a parameter or return of the currently decorated callable) if this hint
        is both reducible and unignorable, this hint unmodified if this hint is
        both irreducible and unignorable, or :obj:`.HINT_SANE_IGNORABLE`
        otherwise (i.e., if this hint is ignorable).

        This method is merely a convenience wrapper for the lower-level
        :func:`.sanify_hint_child` sanifier.

        Parameters
        ----------
        hint_child_insane : Hint
            Child type hint to be sanified.
        hint_parent_sane : Optional[HintSane], default: None
            **Sanified parent type hint metadata** (i.e., immutable and thus
            hashable object encapsulating *all* metadata previously returned by
            :mod:`beartype._check.convert.convmain` sanifiers after sanitizing
            the possibly PEP-noncompliant parent hint of this child hint into a
            fully PEP-compliant parent hint). Defaults to :data:`None`, in which
            case this parameter actually defaults to ``self.hint_sane``, the
            previously sanified metadata encapsulating the direct parent hint of
            this child hint. Since this default suffices in the common case,
            callers should only pass this parameter when explicitly sanifying
            the parent hint of this child hint.

        Returns
        -------
        HintSane
            Either:

            * If this child hint is ignorable, :data:`.HINT_SANE_IGNORABLE`.
            * Else if this unignorable child hint is reducible to another hint,
              metadata encapsulating this reduction.
            * Else, this unignorable child hint is irreducible. In this case,
              metadata encapsulating this child hint unmodified.
        '''

        # If the caller explicitly passed *NO* sanified parent hint metadata,
        # default this metadata to that of the currently visited hint.
        if hint_parent_sane is None:
            hint_parent_sane = self.hint_curr.hint_sane
        # Else, the caller explicitly passed sanified parent hint metadata.
        # Silently preserve this metadata as is.

        # Metadata encapsulating the sanification of this child hint.
        hint_sane_child = sanify_hint_child(
            call_curr=self.call_curr,
            conf=self.conf,
            hint=hint_child_insane,
            hint_parent_sane=hint_parent_sane,

            #FIXME: Pretty weird, honestly. We should at least document *WHY*
            #exactly child hints require a "pith_name". In theory, only root
            #hints should require a "pith_name". Since we currently have *NO*
            #idea what this is about, I suppose the only means of documenting
            #this is to just comment this out and see which tests break. *UGH*!
            pith_name=self.pith_name,

            exception_prefix=self.exception_prefix,
        )
        # print(f'Sanified child hint {hint_child_insane} to {hint_sane_child} of parent {hint_parent_sane}!')

        # Return this metadata.
        return hint_sane_child
