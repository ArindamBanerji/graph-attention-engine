#!/usr/bin/env python3
# --------------------( LICENSE                            )--------------------
# Copyright (c) 2014-2026 Beartype authors.
# See "LICENSE" for further details.

'''
Project-wide :pep:`484`- and :pep:`585`-compliant **generic type hint
testers** (i.e., low-level callables generically validating and detecting both
:pep:`484`- and :pep:`585`-compliant generic classes).

This private submodule is *not* intended for importation by downstream callers.
'''

# ....................{ IMPORTS                            }....................
from beartype.roar import BeartypeDecorHintPep484585Exception
from beartype._data.cls.datacls import TYPES_PEP484544_GENERIC
from beartype._data.typing.datatypingport import Hint
from beartype._data.typing.datatyping import TypeException
from beartype._util.bear.utilbearblack import is_object_blacklisted
from beartype._util.cache.func.utilcachefunc import callable_cached
from beartype._util.hint.pep.proposal.pep484.pep484generic import (
    is_hint_pep484_generic_subbed,
    is_hint_pep484_generic_unsubbed,
)
from beartype._util.hint.pep.proposal.pep585 import (
    is_hint_pep585_generic_subbed,
    is_hint_pep585_generic_unsubbed,
    is_hint_pep585_builtin_subbed,
)
from typing import TypeVar

# ....................{ RAISERS ~ if                       }....................
def die_if_hint_pep484585_generic_invalid(
    # Mandatory parameters.
    hint: Hint,

    # Optional parameters.
    exception_cls: TypeException = BeartypeDecorHintPep484585Exception,
    exception_prefix: str = '',
) -> None:
    '''
    Raise the passed exception if the passed type hint is an **invalid generic**
    (i.e., :pep:`585`-compliant generic subscripted by more child type hints
    than the number of PEP-compliant type parameters originally parametrizing
    the unsubscripted form of this generic).

    This raiser is effectively memoized for efficiency.

    Motivation
    ----------
    This raiser generically applies to both :pep:`484`- and :pep:`585`-compliant
    generics in both unsubscripted and subscripted form. Technically, this
    raiser currently guards against *only* :pep:`585`-compliant invalid
    unsubscripted generics (because those are currently the *only* generics that
    can even be invalid at runtime). Pragmatically, this raiser is generically
    intended to guard against *all* invalid generics (including future forms of
    invalidity that do *not* currently exist). This raiser thus has the
    intentionally future-proofed name ``die_if_hint_pep484585_generic_invalid``
    rather than a more specifically applicable but less future-proofed name
    (e.g., ``die_if_hint_pep585_generic_subbed_invalid``).

    Whereas :pep:`484`-compliant subscripted generics explicitly prohibit
    subscription invalidities by raising runtime exceptions at early
    subscription time, :pep:`585`-compliant subscripted generics implicitly
    promote such invalidities by failing to do so: e.g.,

    .. code-block:: python

       # Python loudly prohibits invalid PEP 484 subscripted generics! WIN.
       >>> class Pep484GenericT[T]: ...
       >>> Pep484GenericT[str, bytes]
       Traceback (most recent call last):
           ...
       TypeError: Too many arguments for <class '__main__.Pep484GenericT'>;
       actual 2, expected 1

       # Python silently accepts invalid PEP 484 subscripted generics. *sigh*
       >>> class Pep585ListU[U](list[U]): ...
       >>> Pep585ListU[str, bytes]
       __main__.Pep585ListU[str, bytes]  # <-- tnx fer nuthin python

    Parameters
    ----------
    hint : Hint
        Type hint to be inspected.
    exception_cls : TypeException, default: BeartypeDecorHintPep484585Exception
        Type of exception to be raised in the event of a fatal error. Defaults
        to :exc:`.BeartypeDecorHintPep484585Exception`.
    exception_prefix : str, default: ''
        Human-readable substring prefixing raised exception messages. Defaults
        to the empty string.
    '''

    # If this hint is an invalid generic...
    if is_hint_pep484585_generic_invalid(hint):
        # Avoid circular import dependencies.
        from beartype._util.hint.pep.utilpepget import (
            get_hint_pep_childs,
            get_hint_pep_typeargs_unpacked,
        )
        from beartype._util.hint.pep.proposal.pep484585.generic.pep484585genget import (
            get_hint_pep484585_generic_unsubbed_type)

        # This generic in unsubscripted form.
        hint_unsubbed = get_hint_pep484585_generic_unsubbed_type(
            hint=hint,
            exception_cls=exception_cls,
            exception_prefix=exception_prefix,
        )

        # Tuple of the zero or more unbound type parameters transitively
        # parametrizing this generic in unsubscripted form.
        hint_typeargs = get_hint_pep_typeargs_unpacked(hint_unsubbed)

        # Tuple of the zero or more child hints directly subscripting this
        # generic if this generic is subscripted *OR* the empty tuple otherwise
        # (i.e., if this generic is unsubscripted).
        hint_args = get_hint_pep_childs(hint)

        # Number of unbound type parameters transitively parametrizing this
        # generic in unsubscripted form.
        hint_typeargs_len = len(hint_typeargs)

        # Number of child hints directly subscripting this generic.
        hint_args_len = len(hint_args)

        # Raise an exception of this type prefixed by this prefix.
        raise exception_cls(
            f'{exception_prefix}'
            f'PEP 585 generic {repr(hint)} '
            f'subscripted by {hint_args_len} child type hints but '
            f'parametrized by {hint_typeargs_len} type parameters. '
            f'Since the total number of child type hints exceeds '
            f'the total number of type parameters '
            f'(i.e., {hint_args_len} > {hint_typeargs_len}), '
            f'this PEP 585 subscripted generic is invalid. '
            f'The number of child type hints subscripting a generic '
            f'must be less than or equal to the number of '
            f'type parameters subscripting that generic. '
            f'Thus spake Bearry the Elder, '
            f'the wise and venerable QA old man '
            f'that totters before you.'
        )
    # Else, this hint is *NOT* an invalid generic (e.g., is either a valid
    # generic *OR* is not a generic at all). In either case, ignore this hint.

# ....................{ RAISERS ~ unless                   }....................
#FIXME: Unit test us up, please. *sigh*
def die_unless_hint_pep484585_generic(
    # Mandatory parameters.
    hint: Hint,

    # Optional parameters.
    exception_cls: TypeException = BeartypeDecorHintPep484585Exception,
    exception_prefix: str = '',
) -> None:
    '''
    Raise the passed exception unless the passed type hint is a **generic**
    (i.e., type originally subclassing at least one :pep:`484`- or
    :pep:`585`-compliant pseudo-superclass parametrized by one or more
    :pep:`484`-, :pep:`612`-, or :pep:`646`-compliant type parameters).

    Note that this raiser does *not* validate this generic to be **valid**
    (i.e., subscripted by no more child type hints than the number of
    PEP-compliant type parameters originally parametrizing the unsubscripted
    form of this generic). To do so, instead call the higher-level
    :func:`.die_if_hint_pep484585_generic_invalid` raiser.

    Parameters
    ----------
    hint : Hint
        Type hint to be inspected.
    exception_cls : TypeException, default: BeartypeDecorHintPep484585Exception
        Type of exception to be raised in the event of a fatal error. Defaults
        to :exc:`.BeartypeDecorHintPep484585Exception`.
    exception_prefix : str, default: ''
        Human-readable substring prefixing raised exception messages. Defaults
        to the empty string.

    Raises
    ------
    exception_cls
        If this hint is *not* an unsubscripted generic.
    '''

    # If this hint is *NOT* a generic...
    if not is_hint_pep484585_generic(hint):
        assert isinstance(exception_cls, type), (
            f'{repr(exception_cls)} not type.')
        assert isinstance(exception_prefix, str), (
            f'{repr(exception_prefix)} not string.')

        # Raise an exception of this type prefixed by this prefix.
        raise exception_cls(
            f'{exception_prefix}type hint {repr(hint)} not '
            f'PEP 484 or 585 generic.'
        )
    # Else, this hint is a generic.


def die_unless_hint_pep484585_generic_unsubbed(
    # Mandatory parameters.
    hint: Hint,

    # Optional parameters.
    exception_cls: TypeException = BeartypeDecorHintPep484585Exception,
    exception_prefix: str = '',
) -> None:
    '''
    Raise the passed exception unless the passed type hint is an **unsubscripted
    generic** (i.e., type originally subclassing at least one subscripted
    :pep:`484`- or :pep:`585`-compliant pseudo-superclass).

    Parameters
    ----------
    hint : Hint
        Type hint to be inspected.
    exception_cls : TypeException, default: BeartypeDecorHintPep484585Exception
        Type of exception to be raised in the event of a fatal error. Defaults
        to :exc:`.BeartypeDecorHintPep484585Exception`.
    exception_prefix : str, default: ''
        Human-readable substring prefixing raised exception messages. Defaults
        to the empty string.

    Raises
    ------
    exception_cls
        If this hint is *not* an unsubscripted generic.
    '''

    # If this hint is *NOT* an unsubscripted generic...
    if not is_hint_pep484585_generic_unsubbed(hint):
        assert isinstance(exception_cls, type), (
            f'{repr(exception_cls)} not type.')
        assert isinstance(exception_prefix, str), (
            f'{repr(exception_prefix)} not string.')

        # Raise an exception of this type prefixed by this prefix.
        raise exception_cls(
            f'{exception_prefix}type hint {repr(hint)} not '
            f'PEP 484 or 585 unsubscripted generic.'
        )
    # Else, this hint is an unsubscripted generic.


# ....................{ TESTERS                            }....................
@callable_cached
def is_hint_pep484585_generic(hint: Hint) -> bool:
    '''
    :data:`True` only if the passed object is either a :pep:`484`- or
    :pep:`585`-compliant **generic** (i.e., either a type originally subclassing
    at least one subscripted :pep:`484`- or :pep:`585`-compliant
    pseudo-superclass *or* an object subscripted by one or more child type hints
    originating from such a type).

    This tester returns :data:`True` only if this object is either:

    * A :pep:`484`-compliant generic as tested by the lower-level
      :func:`.is_hint_pep484_generic` function.
    * A :pep:`585`-compliant generic as tested by the lower-level
      :func:`.is_hint_pep585_generic` function.

    This tester is memoized for efficiency.

    Caveats
    -------
    **Generics are not necessarily classes,** despite originally being declared
    as classes. Although *most* generics are classes, subscripting a generic
    class usually produces a generic non-class that *must* nonetheless be
    transparently treated as a generic class: e.g.,

    .. code-block:: pycon

       >>> from typing import Generic, TypeVar
       >>> S = TypeVar('S')
       >>> T = TypeVar('T')
       >>> class MuhGeneric(Generic[S, T]): pass
       >>> non_class_generic = MuhGeneric[S, T]
       >>> isinstance(non_class_generic, type)
       False

    Parameters
    ----------
    hint : Hint
        Object to be inspected.

    Returns
    -------
    bool
        :data:`True` only if this object is a generic.

    See Also
    --------
    :func:`beartype._util.hint.pep.utilpepget.get_hint_pep_typeargs_packed`
        Commentary on the relation between generics and parametrized hints.
    '''

    # Return true only if...
    return (
        # This hint is either a...
        (
            # PEP 484-compliant generic *OR*...
            #
            # Note these tests trivially reduce to fast O(1) operations and are
            # thus tested first.
            is_hint_pep484_generic_unsubbed(hint) or
            is_hint_pep484_generic_subbed(hint) or
            # PEP 585-compliant generic.
            #
            # Note this test is O(n) for n the number of pseudo-superclasses
            # originally subclassed by this generic and is thus tested last.
            is_hint_pep585_generic_unsubbed(hint) or
            is_hint_pep585_generic_subbed(hint)
        # *AND*...
        ) and
        # This generic is *NOT* beartype-blacklisted.
        not _is_hint_pep484585_generic_blacklisted(hint)
    )


#FIXME: Unit test us up, please. *sigh*
@callable_cached
def is_hint_pep484585_generic_invalid(hint: Hint) -> bool:
    '''
    :data:`True` only if the passed type hint is an **invalid generic** (i.e.,
    :pep:`585`-compliant generic subscripted by more child type hints than the
    number of PEP-compliant type parameters originally parametrizing the
    unsubscripted form of this generic).

    This tester is memoized for efficiency.

    Parameters
    ----------
    hint : Hint
        Type hint to be inspected.

    Returns
    -------
    bool

    See Also
    --------
    :func:`.die_if_hint_pep484585_generic_invalid`
        Further details.
    '''

    # ....................{ IMPORTS                        }....................
    # Avoid circular import dependencies.
    from beartype._util.hint.pep.utilpepget import (
        get_hint_pep_childs,
        get_hint_pep_typeargs_unpacked,
    )
    from beartype._util.hint.pep.proposal.pep484585.generic.pep484585genget import (
        get_hint_pep484585_generic_unsubbed_type)

    # ....................{ NOOP                           }....................
    # If this hint is *NOT* actually a PEP 484- or 585-compliant generic,
    # silently reduce to a noop by returning false immediately.
    if not is_hint_pep484585_generic(hint):
        return False
    # Else,this hint is a PEP 484- or 585-compliant generic.

    # ....................{ LOCALS                         }....................
    # This generic in unsubscripted form (i.e., unsubscripted generic underlying
    # this generic if this generic is subscripted *OR* this unsubscripted
    # generic as is otherwise).
    hint_unsubbed = get_hint_pep484585_generic_unsubbed_type(hint)

    # Tuple of the zero or more unbound type parameters transitively
    # parametrizing this generic in unsubscripted form. Note that this tuple can
    # differ from the tuple of the one or more type parameters parametrizing
    # this generic if this generic is subscripted: e.g.,
    #    >>> T = TypeVar('T')
    #    >>> class Ugh(Generic[T]): pass
    #    >>> get_hint_pep_typeargs_packed(Ugh)
    #    (~T,)  # <-- good
    #    >>> get_hint_pep_typeargs_packed(Ugh[int])
    #    ()  # <----- less good for this use case, but understandable
    hint_typeargs = get_hint_pep_typeargs_unpacked(hint_unsubbed)

    # If even the unsubscripted form of this generic is unparametrized by any
    # unbound type parameters, return false immediately, as this generic is
    # valid by definition. Only parametrized generics admit the possibility of
    # invalidity. This is *NOT* merely a negligible microoptimization. If this
    # edge case was *NOT* elided here, logic below would erroneously treat any
    # subscription of this generic as invalid.
    #
    # Examples of valid generics detected by this test include:
    # * The PEP 484-compliant "typing.Generic" unsubscripted root superclass of
    #   all PEP 484-compliant generics.
    # * Any arbitrary subscription of that superclass.
    # * Any PEP 484-compliant generic transitively subclassing an unparametrized
    #   deprecated "typing" factory: e.g.,
    #       from typing import List
    #       class MuhGenericList(List): ...
    if not hint_typeargs:
        return False
    # Else, the unsubscripted form of this generic is unparametrized by one or
    # more unbound type parameters and thus warrants validation.

    # Tuple of the zero or more child hints directly subscripting this generic
    # if this generic is subscripted *OR* the empty tuple otherwise (i.e., if
    # this generic is unsubscripted).
    hint_args = get_hint_pep_childs(hint)

    # Number of unbound type parameters transitively parametrizing this generic
    # in unsubscripted form.
    hint_typeargs_len = len(hint_typeargs)

    # Number of child hints directly subscripting this generic.
    hint_args_len = len(hint_args)

    # ....................{ SEARCH                         }....................
    # If this generic is subscripted by less than or equal to the number of
    # child hints as the number of unbound type parameters transitively
    # parametrizing this generic in unsubscripted form, then *ALL* such child
    # hints safely bind to a subset of these type parameters, implying this
    # generic to be valid. Return false immediately.
    if hint_args_len <= hint_typeargs_len:
        return False
    # Else, this generic is subscripted by more child hints than this generic is
    # transitively parametrized by unbound type parameters. This generic *COULD*
    # be either valid or invalid. Only an exhaustive search through these type
    # parameters suffices to decide which is the case. We're already exhausted.

    #FIXME: Validate PEP 612-compliant "typing.ParamSpec" as well. Pretty
    #sure they also require a corresponding child hint, with the additional
    #constraint that... what, exactly? Surely one can't map arbitrary child
    #hints to parameter specifications, right? *sigh*
    #FIXME: Validate PEP 646-compliant "typing.TypeVarTuple" as well. Tons
    #we can do here, including:
    #* Check that "hint_typeargs" contains at most one "TypeVarTuple". I
    #  dimly recall already performing that validation elsewhere. Hmm...
    #* Relax the constraint below as follows:
    #  * If "hint_typeargs" contains exactly one "TypeVarTuple", then it's
    #    totally fine for "hint_args_len > hint_typeargs_len". Note,
    #    however, that we still can't return noop immediately. Why? Because
    #    we need to iterate the whole "hint_typeargs" to ensure that
    #    "hint_typeargs" contains no other "TypeVarTuple".
    #  * Else, "hint_args_len > hint_typeargs_len" implies invalidity.

    # For each unbound type parameter transitively parametrizing the
    # unsubscripted form of this generic...
    for hint_typearg in hint_typeargs:
        #FIXME: Not a great assumption, obviously. See "FIXME:" comments above!
        # If this type parameter is *NOT* a PEP 484-compliant type variable,
        # assume this generic to be valid. Return false immediately.
        if not isinstance(hint_typearg, TypeVar):
            return False
        # Else, this type parameter is a PEP 484-compliant type variable.
    # Else, this iteration failed to return, implying *ALL* unbound type
    # parameters transitively parametrizing the unsubscripted form of this
    # generic are PEP 484-compliant type variables. However, this generic
    # was subscripted by more child hints than this generic was parametrized
    # by type variables! Ergo, this generic is invalid.

    # Return true with interminable reluctance. Sadness intensifies.
    return True


def is_hint_pep484585_generic_user(hint: Hint) -> bool:
    '''
    :data:`True` only if the passed :pep:`484`- or :pep:`585`-compliant generic
    is **user-defined** (i.e., defined by a third-party downstream codebase
    rather than CPython's first-party upstream standard library).

    Specifically, this tester returns :data:`True` only if this generic is
    neither:

    * A :pep:`484`- or :pep:`544`-compliant superclass defined by the
      :mod:`typing` module (e.g., :class:`typing.Generic`,
      :class:`typing.Protocol`) *nor*...
    * A :pep:`585`-compliant superclass (e.g., ``list[T]``).

    This tester is intentionally *not* memoized (e.g., by the
    ``callable_cached`` decorator), as the implementation trivially reduces to
    an efficient one-liner.

    Parameters
    ----------
    hint : Hint
        Type hint to be inspected.

    Returns
    -------
    bool
        :data:`True` only if this is a user-defined generic.
    '''

    # Avoid circular import dependencies.
    from beartype._util.hint.pep.utilpepget import (
        get_hint_pep_origin_type_or_none)

    # Return true only if...
    return (
        # This object is a generic that is neither...
        is_hint_pep484585_generic(hint) and not (
            # A PEP 585-compliant subscripted superclass (e.g., "list[T]")
            # *NOR*...
            is_hint_pep585_builtin_subbed(hint) or

            #FIXME: *YIKES.* This approach omits "typing_extensions.Protocol",
            #which is a distinct type from "typing.Protocol". Instead of
            #dogmatically testing raw types, consider a more flexible approach
            #that portably tests higher-level names: e.g.,
            #    hint_origin = get_hint_pep_origin_type_or_none(
            #        hint=hint,
            #        # Preserve "typing.Generic" and "typing.Protocol" as themselves,
            #        # as doing so dramatically simplifies this test. *shrug*
            #        is_self_fallback=True,
            #    )
            #    if (
            #        is_hint_pep_type_typing(hint_origin) and
            #        hint_origin.__name__ in frozenset(('Generic', 'Protocol',))
            #    ):
            #        return False
            #FIXME: *HMM.* The above approach is certainly better, but still
            #falls short. Below, we suggest that the PEP 484-compliant
            #subscripted pseudo-superclass "typing.Generic[S]" should also be
            #seen as *NOT* a user-defined generic. Makes sense... except that
            #the above logic erroneously returns "True" for "typing.Generic[S]"!
            #Clearly, we also need to discard subscriptions. *sigh*
            #FIXME: Excise "TYPES_PEP484544_GENERIC" entirely. That tuple is
            #implicitly non-portable and thus bad news all around, really.

            # A subscripted or unsubscripted PEP 484- or 544-compliant
            # superclass defined by the standard "typing" module, including:
            # * "typing.Generic".
            # * "typing.Generic[S]".
            # * "typing.Protocol".
            # * "typing.Protocol[S]".
            get_hint_pep_origin_type_or_none(
                hint=hint,
                # Preserve "typing.Generic" and "typing.Protocol" as themselves,
                # as doing so dramatically simplifies this test. *shrug*
                is_self_fallback=True,
            ) in TYPES_PEP484544_GENERIC
        )
    )

# ....................{ TESTERS ~ (un)subbed               }....................
def is_hint_pep484585_generic_subbed(hint: Hint) -> bool:
    '''
    :data:`True` only if the passed object is either a :pep:`484`- or
    :pep:`585`-compliant **subscripted generic** (i.e., object subscripted by
    one or more child type hints originating from a type originally subclassing
    at least one subscripted :pep:`484`- or :pep:`585`-compliant generic
    pseudo-superclass).

    This tester returns :data:`True` only if this object is either:

    * A :pep:`484`-compliant subscripted generic as tested by the lower-level
      :func:`.is_hint_pep484_generic_subbed` function.
    * A :pep:`585`-compliant subscripted generic as tested by the lower-level
      :func:`.is_hint_pep585_generic_subbed` function.

    This tester is memoized for efficiency.

    Parameters
    ----------
    hint : Hint
        Object to be inspected.

    Returns
    -------
    bool
        :data:`True` only if this object is a subscripted generic.
    '''

    # Return true only if...
    return (
        # This hint is either a...
        (
            # PEP 484-compliant subscripted generic *OR*...
            #
            # Note this test trivially reduces to a fast O(1) operation and is
            # thus tested first.
            is_hint_pep484_generic_subbed(hint) or
            # PEP 585-compliant subscripted generic.
            #
            # Note this test is O(n) for n the number of pseudo-superclasses
            # originally subclassed by this generic and is thus tested last.
            is_hint_pep585_generic_subbed(hint)
        # *AND*...
        ) and
        # This generic is *NOT* beartype-blacklisted.
        not _is_hint_pep484585_generic_blacklisted(hint)
    )


def is_hint_pep484585_generic_unsubbed(hint: Hint) -> bool:
    '''
    :data:`True` only if the passed object is either a :pep:`484`- or
    :pep:`585`-compliant **unsubscripted generic** (i.e., type originally
    subclassing at least one subscripted :pep:`484`- or :pep:`585`-compliant
    pseudo-superclass).

    This tester returns :data:`True` only if this object is either:

    * A :pep:`484`-compliant unsubscripted generic as tested by the lower-level
      :func:`.is_hint_pep484_generic_unsubbed` function.
    * A :pep:`585`-compliant unsubscripted generic as tested by the lower-level
      :func:`.is_hint_pep585_generic_unsubbed` function.

    This tester is memoized for efficiency.

    Parameters
    ----------
    hint : Hint
        Object to be inspected.

    Returns
    -------
    bool
        :data:`True` only if this object is a unsubscripted generic.
    '''

    # Return true only if...
    return (
        # This hint is either a...
        (
            # PEP 484-compliant unsubscripted generic *OR*...
            #
            # Note this test trivially reduces to a fast O(1) operation and is
            # thus tested first.
            is_hint_pep484_generic_unsubbed(hint) or
            # PEP 585-compliant unsubscripted generic.
            #
            # Note this test is O(n) for n the number of pseudo-superclasses
            # originally subclassed by this generic and is thus tested last.
            is_hint_pep585_generic_unsubbed(hint)
        # *AND*...
        ) and
        # This generic is *NOT* beartype-blacklisted.
        not _is_hint_pep484585_generic_blacklisted(hint)
    )

# ....................{ PRIVATE ~ testers                  }....................
#FIXME: Call above, please.
@callable_cached
def _is_hint_pep484585_generic_blacklisted(hint: Hint) -> bool:
    '''
    :data:`True` only if the passed :pep:`484`- or :pep:`585`-compliant generic
    is **beartype-blacklisted** (i.e., defined in a third-party package or
    module known to be hostile to runtime type-checking).

    This tester is memoized for efficiency.

    Parameters
    ----------
    hint : Hint
        Generic to be inspected.

    Returns
    -------
    bool
        :data:`True` only if this generic is beartype-blacklisted.

    See Also
    --------
    :func:`.is_object_blacklisted`
        Further details on beartype-blacklisting.
    '''

    # Avoid circular import dependencies.
    from beartype._util.hint.pep.proposal.pep484585.generic.pep484585genget import (
        get_hint_pep484585_generic_unsubbed_type)

    # Either:
    # * If this generic is already unsubscripted, this generic as is.
    # * Else, this generic is subscripted. In this case, the unsubscripted
    #   generic underlying this subscripted generic.
    hint_type = get_hint_pep484585_generic_unsubbed_type(hint)

    # For each possibly erased superclass of this generic, arbitrarily iterated
    # according to the method resolution order (MRO) for this generic...
    for hint_base in hint_type.__mro__:
        # If this superclass is beartype-blacklisted (i.e., defined in a
        # third-party package or module known to be hostile to runtime
        # type-checking), return true immediately.
        if is_object_blacklisted(hint_base):
            return True
        # Else, this superclass is *NOT* beartype-blacklisted. In this case,
        # continue to the next such superclass of this generic.
    # Else, all superclasses of this generic are *NOT* beartype-blacklisted.

    # Return false as a sane fallback.
    return False
