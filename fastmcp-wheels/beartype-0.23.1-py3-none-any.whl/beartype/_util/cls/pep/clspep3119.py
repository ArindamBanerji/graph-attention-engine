#!/usr/bin/env python3
# --------------------( LICENSE                            )--------------------
# Copyright (c) 2014-2026 Beartype authors.
# See "LICENSE" for further details.

'''
Project-wide :pep:`3119`-compliant **class detectors** (i.e., callables
validating and testing various properties of arbitrary classes standardized by
:pep:`3119`).

This private submodule is *not* intended for importation by downstream callers.
'''

# ....................{ IMPORTS                            }....................
from beartype.roar import BeartypeDecorHintPep3119Exception
from beartype.roar._roarexc import _BeartypeHintForwardRefExceptionMixin
from beartype.typing import Callable
# from beartype._cave._cavefast import Pep3119CheckableTypes
from beartype._data.cls.datacls import TYPES_EXCEPTION_NAMESPACE
from beartype._data.typing.datatypingport import TypeIs
from beartype._data.typing.datatyping import (
    Pep3119Checkable,
    TypeException,
)
from beartype._util.cache.func.utilcachefunc import callable_cached

# ....................{ RAISERS ~ isinstanceable           }....................
def die_unless_object_isinstanceable(
    # Mandatory parameters.
    obj: Pep3119Checkable,

    # Optional parameters.
    is_ref_proxy_valid: bool = False,
    exception_cls: TypeException = BeartypeDecorHintPep3119Exception,
    exception_prefix: str = '',
) -> None:
    '''
    Raise an exception of the passed type unless the passed object is
    **isinstanceable** (i.e., valid as the second parameter to the
    :func:`isinstance` builtin).

    Specifically, this function raises an exception unless this object is
    either:

    * An **isinstanceable class** (i.e., class whose metaclass does *not* define
      an ``__instancecheck__()`` dunder method that raises a :exc:`TypeError`
      exception).
    * Tuple of one or more isinstanceable classes.
    * A :pep:`604`-compliant **new union** (i.e., objects created by expressions
      of the form ``{type1} | {type2} | ... | {typeN}``) under Python >= 3.10.
      By definition, *all* new unions are isinstanceable.

    Parameters
    ----------
    obj : Pep3119Checkable
        Object to be validated.
    is_ref_proxy_valid : bool, default: False
        :data:`True` only if this function permits this object to be a
        **forward reference proxy** (i.e., :mod:`beartype`-specific private type
        proxying an external type hint that may currently be undefined). If this
        boolean is:

        * :data:`True`, this object is valid only when this object is either an
          isinstanceable class *or* forward reference proxy.
        * :data:`False`, this object is valid only when this object is an
          isinstanceable class. Note that forward reference proxies are
          isinstanceable classes *if and only if* the external classes they
          refer to have already been defined.

        Defaults to :data:`False`.
    exception_cls : TypeException, default: BeartypeDecorHintPep3119Exception
        Type of exception to be raised in the event of a fatal error. Defaults
        to :exc:`.BeartypeDecorHintPep3119Exception`.
    exception_prefix : str, default: ''
        Human-readable substring prefixing raised exception messages. Defaults
        to the empty string.

    Raises
    ------
    BeartypeDecorHintPep3119Exception
        If this object is neither:

        * An isinstanceable class.
        * A tuple containing only isinstanceable classes.
        * A :pep:`604`-compliant new union.

    See Also
    --------
    :func:`.die_unless_type_isinstanceable`
        Further details.
    '''

    # Defer to this lower-level general-purpose raiser.
    _die_if_object_uncheckable(
        obj=obj,
        is_ref_proxy_valid=is_ref_proxy_valid,
        type_raiser=die_unless_type_isinstanceable,
        type_tester=is_type_isinstanceable,
        builtin_tester=isinstance,  # type: ignore[arg-type]
        builtin_tester_pith=None,
        exception_cls=exception_cls,
        exception_prefix=exception_prefix,
    )


def die_unless_type_isinstanceable(
    # Mandatory parameters.
    cls: type,

    # Optional parameters.
    is_ref_proxy_valid: bool = False,
    exception_cls: TypeException = BeartypeDecorHintPep3119Exception,
    exception_prefix: str = '',
) -> None:
    '''
    Raise an exception of the passed type unless the passed object is an
    **isinstanceable class** (i.e., class whose metaclass does *not* define an
    ``__instancecheck__()`` dunder method raising unexpected exceptions).

    Classes that are *not* isinstanceable include most PEP-compliant type hints,
    notably:

    * **Generic aliases** (i.e., subscriptable classes overriding the
      ``__class_getitem__()`` class dunder method standardized by :pep:`560`
      subscripted by an arbitrary object) under Python >= 3.9, whose metaclasses
      define an ``__instancecheck__()`` dunder method to unconditionally raise
      an exception. Generic aliases include:

      * :pep:`484`-compliant **subscripted generics.**
      * :pep:`585`-compliant type hints.

    * User-defined classes whose metaclasses define an ``__instancecheck__()``
      dunder method to unconditionally raise an exception, including:

      * :pep:`544`-compliant protocols *not* decorated by the
        :func:`typing.runtime_checkable` decorator.

    Motivation
    ----------
    When a class whose metaclass defines an ``__instancecheck__()`` dunder
    method is passed as the second parameter to the :func:`isinstance` builtin,
    that builtin defers to that method rather than testing whether the first
    parameter passed to that builtin is an instance of that class. If that
    method raises an exception, that builtin raises the same exception,
    preventing callers from deciding whether arbitrary objects are instances
    of that class. For brevity, we refer to that class as "non-isinstanceable."

    Most classes are isinstanceable, because deciding whether arbitrary objects
    are instances of those classes is a core prerequisite for object-oriented
    programming. Most classes that are also PEP-compliant type hints, however,
    are *not* isinstanceable, because they're *never* intended to be
    instantiated into objects (and typically prohibit instantiation in various
    ways); they're only intended to be referenced as type hints annotating
    callables, an arguably crude form of callable markup.

    :mod:`beartype`-decorated callables typically check the types of arbitrary
    objects at runtime by passing those objects and types as the first and
    second parameters to the :func:`isinstance` builtin. If those types are
    non-isinstanceable, those type-checks will typically raise
    non-human-readable exceptions (e.g., ``"TypeError: isinstance() argument 2
    cannot be a parameterized generic"`` for :pep:`585`-compliant type hints).
    This is non-ideal both because those exceptions are non-human-readable *and*
    because those exceptions are raised at call rather than decoration time,
    where users expect the :func:`beartype.beartype` decorator to raise
    exceptions for erroneous type hints.

    Thus the existence of this function, which the :func:`beartype.beartype`
    decorator frequently calls to validate the usability of type hints that are
    classes *before* checking objects against those classes at call time.

    Caveats
    -------
    **This function considers all classes whose metaclasses define
    ``__instancecheck__()`` dunder methods that raise exceptions other than**
    :exc:`TypeError` **to be isinstanceable.** This function *only* considers
    classes whose metaclasses define ``__instancecheck__()`` dunder methods that
    raise :exc:`TypeError` exceptions to be non-isinstanceable; all other
    classes are isinstanceable.

    Ideally, this function would consider any class whose metaclass defines an
    ``__instancecheck__()`` dunder method that raises any exception (rather than
    merely a :exc:`TypeError` exception) to be non-isinstanceable.
    Pragmatically, doing so would raise false positives in common edge cases --
    and previously did so, in fact, which is why we no longer do so.

    In particular, the metaclass of the passed class may *not* necessarily be
    fully initialized at the early time that this function is called (typically,
    at :func:`beartype.beartype` decoration time). If this is the case, then
    eagerly passing that class to :func:`isinstance` is likely to raise an
    exception. For example, doing so raises an :exc:`AttributeError` when the
    ``__instancecheck__()`` dunder method defined by that metaclass references
    an external attribute that has yet to be defined:

    .. code-block:: python

       from beartype import beartype

       class MetaFoo(type):
           def __instancecheck__(cls, other):
               return g()

       class Foo(metaclass=MetaFoo):
           pass

       # @beartype transitively calls this function to validate that "Foo" is
       # isinstanceable. However, since g() has yet to be defined at this time,
       # doing so raises an "AttributeError" exception despite this logic
       # otherwise being sound.
       @beartype
       def f(x: Foo):
           pass

       def g():
           return True

    This function thus constrains itself to merely the :exc:`TypeError`
    exception, which all non-isinstanceable classes defined by the standard
    :mod:`typing` module unconditionally raise. This suggests that there is
    currently an unambiguous one-to-one mapping between non-isinstanceable
    classes and classes whose metaclass ``__instancecheck__()`` dunder methods
    raise :exc:`TypeError` exceptions. May this mapping hold true forever!

    Parameters
    ----------
    cls : object
        Object to be validated.
    is_ref_proxy_valid : bool, default: False
        :data:`True` only if this function permits this object to be a
        **forward reference proxy** (i.e., :mod:`beartype`-specific private type
        proxying an external type hint that may currently be undefined). See the
        :func:`.die_unless_object_isinstanceable` raiser for further details.
    exception_cls : TypeException, default: BeartypeDecorHintPep3119Exception
        Type of exception to be raised in the event of a fatal error. Defaults to
        :exc:`.BeartypeDecorHintPep3119Exception`.
    exception_prefix : str, default: ''
        Human-readable substring prefixing raised exception messages. Defaults
        to the empty string.

    Raises
    ------
    BeartypeDecorHintPep3119Exception
        If this object is *not* an isinstanceable class.

    See Also
    --------
    :func:`.die_unless_type_isinstanceable`
        Further details.
    '''

    # Avoid circular import dependencies.
    from beartype._util.cls.utilclstest import die_unless_type

    # If this object is *NOT* a class, raise an exception.
    die_unless_type(
        cls=cls, exception_cls=exception_cls, exception_prefix=exception_prefix)
    # Else, this object is a class.

    # If this class is isinstanceable, silently reduce to a noop.
    #
    # Note that this merely constitutes an optimization -- albeit a
    # non-negligible optimization. The is_type_isinstanceable() tester is
    # memoized against inefficiencies, including:
    # * An inefficient implementation leveraging the EAFP (Easier to Ask for
    #   Permission than Foregiveness) principle.
    # * Worst-case behaviour in which the metaclass of this class defines an
    #   inefficient __instancecheck__() method outside our control.
    if is_type_isinstanceable(cls, is_ref_proxy_valid):
        return
    # Else, this class is *NOT* isinstanceable. In this case, raise a
    # human-readable exception embedding the original (typically unreadable)
    # "TypeError" exception implicitly raised by the metaclass of this class.

    # Defer to this lower-level general-purpose raiser.
    return _die_unless_object_builtin_checkable(
        obj=cls,
        is_ref_proxy_valid=is_ref_proxy_valid,
        type_tester=is_type_isinstanceable,
        builtin_tester=isinstance,  # type: ignore[arg-type]
        builtin_tester_pith=None,
        exception_cls=exception_cls,
        exception_prefix=exception_prefix,
    )

# ....................{ RAISERS ~ subclass                 }....................
def die_unless_object_issubclassable(
    # Mandatory parameters.
    obj: Pep3119Checkable,

    # Optional parameters.
    is_ref_proxy_valid: bool = False,
    exception_cls: TypeException = BeartypeDecorHintPep3119Exception,
    exception_prefix: str = '',
) -> None:
    '''
    Raise an exception of the passed type unless the passed object is
    **issubclassable** (i.e., valid as the second parameter to the
    :func:`issubclass` builtin).

    Specifically, this function raises an exception unless this object is
    either:

    * An **issubclassable class** (i.e., class whose metaclass does *not* define
      an ``__subclasscheck__()`` dunder method that raises a :exc:`TypeError`
      exception).
    * Tuple of one or more issubclassable classes.
    * A :pep:`604`-compliant **new union** (i.e., objects created by expressions
      of the form ``{type1} | {type2} | ... | {typeN}``) under Python >= 3.10.
      By definition, *all* new unions are issubclassable.

    Parameters
    ----------
    obj : object
        Object to be validated.
    is_ref_proxy_valid : bool, default: False
        :data:`True` only if this function permits this object to be a
        **forward reference proxy** (i.e., :mod:`beartype`-specific private type
        proxying an external type hint that may currently be undefined). See the
        :func:`.die_unless_object_isinstanceable` raiser for further details.
    exception_cls : TypeException, default: BeartypeDecorHintPep3119Exception
        Type of exception to be raised in the event of a fatal error. Defaults to
        :exc:`.BeartypeDecorHintPep3119Exception`.
    exception_prefix : str, default: ''
        Human-readable substring prefixing raised exception messages. Defaults
        to the empty string.

    Raises
    ------
    BeartypeDecorHintPep3119Exception
        If this object is neither:

        * An issubclassable class.
        * A tuple containing only issubclassable classes.
        * A :pep:`604`-compliant new union.
    '''

    # Defer to this lower-level general-purpose raiser.
    _die_if_object_uncheckable(
        obj=obj,
        is_ref_proxy_valid=is_ref_proxy_valid,
        type_raiser=die_unless_type_issubclassable,
        type_tester=is_type_issubclassable,
        builtin_tester=issubclass,  # type: ignore[arg-type]
        builtin_tester_pith=type,
        exception_cls=exception_cls,
        exception_prefix=exception_prefix,
    )


def die_unless_type_issubclassable(
    # Mandatory parameters.
    cls: type,

    # Optional parameters.
    is_ref_proxy_valid: bool = False,
    exception_cls: TypeException = BeartypeDecorHintPep3119Exception,
    exception_prefix: str = '',
) -> None:
    '''
    Raise an exception of the passed type unless the passed object is an
    **issubclassable class** (i.e., class whose metaclass does *not* define a
    ``__subclasscheck__()`` dunder method that raise a :exc:`TypeError`
    exception).

    Classes that are *not* issubclassable include most PEP-compliant type
    hints, notably:

    * **Generic aliases** (i.e., subscriptable classes overriding the
      ``__class_getitem__()`` class dunder method standardized by :pep:`560`
      subscripted by an arbitrary object) under Python >= 3.9, whose
      metaclasses define an ``__subclasscheck__()`` dunder method to
      unconditionally raise an exception. Generic aliases include:

      * :pep:`484`-compliant **subscripted generics.**
      * :pep:`585`-compliant type hints.

    * User-defined classes whose metaclasses define a ``__subclasscheck__()``
      dunder method to unconditionally raise an exception, including:

      * :pep:`544`-compliant protocols *not* decorated by the
        :func:`typing.runtime_checkable` decorator.

    Motivation
    ----------
    See also the "Motivation" and "Caveats" sections of the
    :func:`.die_unless_type_isinstanceable` docstring for further discussion,
    substituting:

    * ``__instancecheck__()`` for ``__subclasscheck__()``.
    * :func:`isinstance` for :func:`issubclass`.

    Parameters
    ----------
    cls : object
        Object to be validated.
    is_ref_proxy_valid : bool, default: False
        :data:`True` only if this function permits this object to be a
        **forward reference proxy** (i.e., :mod:`beartype`-specific private type
        proxying an external type hint that may currently be undefined). See the
        :func:`.die_unless_object_isinstanceable` raiser for further details.
    exception_cls : TypeException, default: BeartypeDecorHintPep3119Exception
        Type of exception to be raised in the event of a fatal error. Defaults to
        :exc:`.BeartypeDecorHintPep3119Exception`.
    exception_prefix : str, default: ''
        Human-readable substring prefixing raised exception messages. Defaults
        to the empty string.

    Raises
    ------
    BeartypeDecorHintPep3119Exception
        If this object is *not* an issubclassable class.
    '''

    # Avoid circular import dependencies.
    from beartype._util.cls.utilclstest import die_unless_type

    # If this hint is *NOT* a class, raise an exception.
    die_unless_type(
        cls=cls, exception_cls=exception_cls, exception_prefix=exception_prefix)
    # Else, this hint is a class.

    # If this class is issubclassable, silently reduce to a noop.
    #
    # Note that this merely constitutes an optimization -- albeit a
    # non-negligible optimization. The is_type_issubclassable() tester is
    # memoized against inefficiencies, including:
    # * An inefficient implementation leveraging the EAFP (Easier to Ask for
    #   Permission than Foregiveness) principle.
    # * Worst-case behaviour in which the metaclass of this class defines an
    #   inefficient __subclasscheck__() method outside our control.
    if is_type_issubclassable(cls, is_ref_proxy_valid):
        return
    # Else, this class is *NOT* issubclassable. In this case, raise a
    # human-readable exception embedding the original (typically unreadable)
    # "TypeError" exception implicitly raised by the metaclass of this class.

    # Defer to this lower-level general-purpose raiser.
    return _die_unless_object_builtin_checkable(
        obj=cls,
        is_ref_proxy_valid=is_ref_proxy_valid,
        type_tester=is_type_isinstanceable,
        builtin_tester=issubclass,  # type: ignore[arg-type]
        builtin_tester_pith=type,
        exception_cls=exception_cls,
        exception_prefix=exception_prefix,
    )

# ....................{ TESTERS                            }....................
#FIXME: Preserved for posterity. Pretty cool little tester. Nice name, anyway.
#We just have *NO* pragmatic use for this at the moment. *shrug*
#FIXME: Unit test us up, please. *sigh*
# def is_object_isinstanceorsubclassable_maybe(
#     obj: object) -> TypeIs[Pep3119Checkable]:
#     '''
#     :data:`True` only if the passed object is **possibly runtime-checkable**
#     (i.e., passable as the second parameter to the :func:`isinstance` and
#     :func:`issubclass` builtins, assuming those calls raise *no* exceptions from
#     :pep:`3119`-compliant ``__instancecheck__()`` or ``__subclasscheck__()``
#     dunder methods defined on relevant metaclasses).
#
#     This tester returns :data:`True` only if this object is either:
#
#     * A single type.
#     * A tuple of zero or more types.
#     * A :pep:`604`-compliant **new union** (i.e., two or more types delimited by
#       the ``|`` operator under Python >= 3.10).
#
#     Caveats
#     -------
#     **This low-level tester should always be called before passing arbitrary
#     objects to higher-level testers like** :func:`.is_object_isinstanceable` or
#     :func:`.is_object_issubclassable`. If this tester returns:
#
#     * :data:`False`, those testers are guaranteed to return :data:`False` when
#       passed the same object as well.
#     * :data:`True`, no such guarantee exists. Those testers may either return
#       :data:`True` or :data:`False` when passed the same object, depending on
#       whether that object is genuinely isinstanceable or issubclassable.
#
#     Parameters
#     ----------
#     obj : object
#         Object to be tested.
#
#     Returns
#     -------
#     bool
#         :data:`True` only if this object is possibly runtime-checkable.
#     '''
#
#     # Maximal one-liner. Minimal effort. Truly, these are the days.
#     return isinstance(obj, Pep3119CheckableTypes)

# ....................{ TESTERS ~ isinstanceable           }....................
@callable_cached
def is_object_isinstanceable(
    # Mandatory parameters.
    obj: object,

    # Optional parameters.
    is_ref_proxy_valid: bool = False,
) -> TypeIs[Pep3119Checkable]:
    '''
    :data:`True` only if the passed object is **isinstanceable** (i.e., valid as
    the second parameter to the :func:`isinstance` builtin).

    This tester is a higher-level generalization of the
    :func:`is_type_isinstanceable` tester, which only supports a proper subset
    of all objects permissible as the second parameter to that builtin (i.e.,
    isinstanceable types). By compare, this tester supports *all* such objects.
    This includes:

    * An isinstanceable class.
    * A tuple containing only isinstanceable classes.
    * A :pep:`604`-compliant new union.

    This tester is memoized for efficiency.

    Parameters
    ----------
    obj : Pep3119Checkable
        Object to be tested.
    is_ref_proxy_valid : bool, default: False
        :data:`True` only if this function permits this object to be a
        **forward reference proxy** (i.e., :mod:`beartype`-specific private type
        proxying an external type hint that may currently be undefined). See the
        :func:`.die_unless_object_isinstanceable` raiser for further details.

    Returns
    -------
    bool
        :data:`True` only if this object is either:

        * An isinstanceable class.
        * A tuple containing only isinstanceable classes.
        * A :pep:`604`-compliant new union.

    See Also
    --------
    :func:`.die_unless_type_isinstanceable`
    :func:`.is_type_isinstanceable`
        Further details.
    '''

    # Defer to this lower-level general-purpose raiser.
    return _is_object_checkable(
        obj=obj,
        is_ref_proxy_valid=is_ref_proxy_valid,
        type_tester=is_type_isinstanceable,
        builtin_tester=isinstance,  # type: ignore[arg-type]
        builtin_tester_pith=None,
    )


#FIXME: Unit test up the "is_ref_proxy_valid" parameter, please.
@callable_cached
def is_type_isinstanceable(
    # Mandatory parameters.
    cls: object,

    # Optional parameters.
    is_ref_proxy_valid: bool = False,
) -> TypeIs[type]:
    '''
    :data:`True` only if the passed object is an **isinstanceable type** (i.e.,
    class whose metaclass does *not* define an ``__instancecheck__()`` dunder
    method that raises a :exc:`TypeError` exception).

    This tester is memoized for efficiency.

    Caveats
    -------
    **This tester may return false positives in unlikely edge cases.**
    Internally, this tester tests whether this class is isinstanceable by
    detecting whether passing the :data:`None` singleton and this class to the
    :func:`isinstance` builtin raises a :exc:`TypeError` exception. If that call
    raises *no* exception, this class is probably but *not* necessarily
    isinstanceable. Since the metaclass of this class could define an
    ``__instancecheck__()`` dunder method to conditionally raise exceptions
    *except* when passed the :data:`None` singleton, there exists *no* perfect
    means of deciding whether an arbitrary class is fully isinstanceable in the
    general sense. Since most classes that are *not* isinstanceable are
    unconditionally isinstanceable (i.e., the metaclasses of those classes
    define an ``__instancecheck__()`` dunder method to unconditionally raise
    exceptions), this distinction is generally meaningless in the real world.
    This test thus generally suffices.

    Parameters
    ----------
    cls : object
        Object to be tested.
    is_ref_proxy_valid : bool, default: False
        :data:`True` only if this function permits this object to be a
        **forward reference proxy** (i.e., :mod:`beartype`-specific private type
        proxying an external type hint that may currently be undefined). See the
        :func:`.die_unless_object_isinstanceable` raiser for further details.

    Returns
    -------
    bool
        :data:`True` only if this object is an isinstanceable class.

    See Also
    --------
    :func:`.die_unless_type_isinstanceable`
        Further details.
    '''

    # Defer to this lower-level general-purpose tester.
    return _is_type_checkable(
        cls=cls,
        is_ref_proxy_valid=is_ref_proxy_valid,
        builtin_tester=isinstance,  # type: ignore[arg-type]
        builtin_tester_pith=None,
    )

# ....................{ TESTERS ~ issubclassable           }....................
#FIXME: Unit test us up, please.
@callable_cached
def is_object_issubclassable(
    # Mandatory parameters.
    obj: object,

    # Optional parameters.
    is_ref_proxy_valid: bool = False,
) -> TypeIs[Pep3119Checkable]:
    '''
    :data:`True` only if the passed object is **issubclassable** (i.e., valid as
    the second parameter to the :func:`issubclass` builtin).

    This tester is a higher-level generalization of the
    :func:`is_type_issubclassable` tester, which only supports a proper subset
    of all objects permissible as the second parameter to that builtin (i.e.,
    issubclassable types). By compare, this tester supports *all* such objects.
    This includes:

    * An isinstanceable class.
    * A tuple containing only isinstanceable classes.
    * A :pep:`604`-compliant new union.


    This tester is memoized for efficiency.

    Parameters
    ----------
    obj : Pep3119Checkable
        Object to be tested.
    is_ref_proxy_valid : bool, default: False
        :data:`True` only if this function permits this object to be a
        **forward reference proxy** (i.e., :mod:`beartype`-specific private type
        proxying an external type hint that may currently be undefined). See the
        :func:`.die_unless_object_isinstanceable` raiser for further details.

    Returns
    -------
    bool
        :data:`True` only if this object is either:

        * An issubclassable class.
        * A tuple containing only issubclassable classes.
        * A :pep:`604`-compliant new union.

    See Also
    --------
    :func:`.die_unless_type_issubclassable`
    :func:`.is_type_isinstanceable`
        Further details.
    '''

    # Defer to this lower-level general-purpose raiser.
    return _is_object_checkable(
        obj=obj,
        is_ref_proxy_valid=is_ref_proxy_valid,
        type_tester=is_type_isinstanceable,
        builtin_tester=issubclass,  # type: ignore[arg-type]
        builtin_tester_pith=type,
    )


#FIXME: Unit test up the "is_ref_proxy_valid" parameter, please.
@callable_cached
def is_type_issubclassable(
    # Mandatory parameters.
    cls: object,

    # Optional parameters.
    is_ref_proxy_valid: bool = False,
) -> TypeIs[type]:
    '''
    :data:`True` only if the passed object is an **issubclassable class** (i.e.,
    class whose metaclass does *not* define a ``__subclasscheck__()`` dunder
    method that raises a :exc:`TypeError` exception).

    This tester is memoized for efficiency.

    Parameters
    ----------
    cls : object
        Object to be tested.
    is_ref_proxy_valid : bool, default: False
        :data:`True` only if this function permits this object to be a
        **forward reference proxy** (i.e., :mod:`beartype`-specific private type
        proxying an external type hint that may currently be undefined). See the
        :func:`.die_unless_object_isinstanceable` raiser for further details.

    Returns
    -------
    bool
        :data:`True` only if this object is an issubclassable class.

    See Also
    --------
    :func:`.die_unless_type_issubclassable`
    :func:`.is_type_isinstanceable`
        Further details.
    '''

    # Defer to this lower-level general-purpose tester.
    return _is_type_checkable(
        cls=cls,
        is_ref_proxy_valid=is_ref_proxy_valid,
        builtin_tester=issubclass,  # type: ignore[arg-type]
        builtin_tester_pith=type,
    )

# ....................{ PRIVATE ~ hints                    }....................
_NontypeTester = Callable[[object, Pep3119Checkable], bool]
'''
:pep:`585`-compliant type hint matching both the :func:`.isinstance` and
:func:`.issubclass` builtins.
'''

# ....................{ PRIVATE ~ raisers                  }....................
def _die_if_object_uncheckable(
    obj: Pep3119Checkable,
    is_ref_proxy_valid: bool,
    type_raiser: Callable,
    type_tester: Callable,
    builtin_tester: _NontypeTester,
    builtin_tester_pith: object,
    exception_cls: TypeException,
    exception_prefix: str,
) -> None:
    '''
    Raise an exception unless the passed object is **runtime-checkable** (i.e.,
    valid as the second parameter to either the :func:`isinstance` or
    :func:`issubclass` builtins) according to the passed object tester and
    raiser.

    Parameters
    ----------
    obj : object
        Object to be validated.
    is_ref_proxy_valid : bool
        :data:`True` only if this function permits this object to be a
        **forward reference proxy** (i.e., :mod:`beartype`-specific private type
        proxying an external type hint that may currently be undefined). See the
        :func:`.die_unless_object_isinstanceable` raiser for further details.
    type_raiser : Callable
        Callable raising an exception unless this object is runtime-checkable
        according to this predicate, which should be either:

        * :func:`.die_unless_type_isinstanceable`.
        * :func:`.die_unless_type_issubclassable`.
    type_tester : Callable
        Callable returning :data:`True` only if this object is a
        runtime-checkable type according to this predicate, which should be
        either:

        * :func:`.is_type_isinstanceable`.
        * :func:`.is_type_issubclassable`.
    builtin_tester : Callable[[object, Pep3119Checkable], bool]
        Callable returning :data:`True` only if this object is runtime-checkable
        according to this predicate, which should be either:

        * :func:`isinstance`.
        * :func:`issubclass`.
    builtin_tester_pith : object
        Object guaranteed to satisfy the ``builtin_tester`` callable when
        ``obj`` is **runtime-typecheckable** -- that is, when ``builtin_tester``
        is called as ``builtin_tester(builtin_tester_pith, obj)``.
    exception_cls : TypeException
        Type of exception to be raised in the event of a fatal error.
    exception_prefix : str
        Human-readable substring prefixing raised exception messages.

    Raises
    ------
    exception_cls
        If this object is *not* runtime-checkable according to the passed
        object tester and raiser.
    '''
    assert callable(type_raiser), f'{repr(type_raiser)} uncallable.'
    assert callable(builtin_tester), f'{repr(builtin_tester)} uncallable.'

    # Avoid circular import dependencies.
    from beartype._util.cls.utilclstest import die_unless_type_or_types
    from beartype._util.hint.pep.proposal.pep484.pep484604union import (
        is_hint_pep604)

    # If this object is *NOT* a PEP 604-compliant new union...
    if not is_hint_pep604(obj):
        # If this object is neither a type *NOR* tuple of types, raise an
        # exception.
        die_unless_type_or_types(
            type_or_types=obj,
            exception_cls=exception_cls,
            exception_prefix=exception_prefix,
        )
        # Else, this object is either a type *OR* tuple of types.
    # Else, this object is a PEP 604-compliant new union.
    #
    # In any case, this object is either a type, tuple of types, *OR* a PEP
    # 604-compliant new union. In all three of these cases, this object *COULD*
    # now be runtime-checkable. Further detection is required to decide.

    # If this object is a type...
    if isinstance(obj, type):
        # If this type is *NOT* runtime-checkable, raise an exception.
        type_raiser(
            cls=obj,
            is_ref_proxy_valid=is_ref_proxy_valid,
            exception_cls=exception_cls,
            exception_prefix=exception_prefix,
        )
        # Else, this type is runtime-checkable.
    # Else, this object *MUST* (by process of elimination and validation above)
    # be either a tuple of types *OR* a PEP 604-compliant new union.

    # Defer to this lower-level general-purpose raiser.
    return _die_unless_object_builtin_checkable(
        obj=obj,
        is_ref_proxy_valid=is_ref_proxy_valid,
        type_tester=type_tester,
        builtin_tester=builtin_tester,
        builtin_tester_pith=builtin_tester_pith,
        exception_cls=exception_cls,
        exception_prefix=exception_prefix,
    )


#FIXME: Unit test us up, please. *sigh*
def _die_unless_object_builtin_checkable(
    obj: Pep3119Checkable,
    is_ref_proxy_valid: bool,
    type_tester: Callable,
    builtin_tester: _NontypeTester,
    builtin_tester_pith: object,
    exception_cls: TypeException,
    exception_prefix: str,
) -> None:
    '''
    Raise an exception unless the passed object is **runtime-checkable** (i.e.,
    safely passable without raising exceptions when passed as the second
    parameter) with respect to the passed **builtin tester** (i.e., either the
    :func:`isinstance` or :func:`issubclass` builtin).

    Parameters
    ----------
    obj : object
        Object to be validated.
    is_ref_proxy_valid : bool
        :data:`True` only if this function permits this object to be a
        **forward reference proxy** (i.e., :mod:`beartype`-specific private type
        proxying an external type hint that may currently be undefined). See the
        :func:`.die_unless_object_isinstanceable` raiser for further details.
    type_tester : Callable
        Callable returning :data:`True` only if this object is a
        runtime-checkable type according to this predicate, which should be
        either:

        * :func:`.is_type_isinstanceable`.
        * :func:`.is_type_issubclassable`.
    builtin_tester : Callable[[object, Pep3119Checkable], bool]
        Callable returning :data:`True` only if this object is runtime-checkable
        according to this predicate, which should be either:

        * :func:`isinstance`.
        * :func:`issubclass`.
    builtin_tester_pith : object
        Object guaranteed to satisfy the ``builtin_tester`` callable when
        ``obj`` is **runtime-typecheckable** -- that is, when ``builtin_tester``
        is called as ``builtin_tester(builtin_tester_pith, obj)``.
    exception_cls : TypeException
        Type of exception to be raised in the event of a fatal error.
    exception_prefix : str
        Human-readable substring prefixing raised exception messages.

    Raises
    ------
    exception_cls
        If this object is *not* runtime-checkable according to the passed
        builtin tester.
    '''
    assert callable(type_tester), f'{repr(type_tester)} uncallable.'
    assert callable(builtin_tester), f'{repr(builtin_tester)} uncallable.'

    #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    # CAUTION: Synchronize with _is_object_builtin_checkable().
    #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    # Attempt to pass this object as the second parameter to this builtin tester
    # to decide whether or not this object is safely runtime-checkable or not.
    #
    # Note that this leverages an EAFP (i.e., "It is easier to ask forgiveness
    # than permission") approach and thus imposes a minor performance penalty,
    # but that there exists *NO* faster alternative applicable to arbitrary
    # user-defined objects, whose metaclasses may define an __instancecheck__()
    # dunder method to raise exceptions and thus prohibit being passed as the
    # second parameter to this builtin tester, the primary means employed by
    # @beartype wrapper functions to check arbitrary hints.
    try:
        builtin_tester(builtin_tester_pith, obj)  # type: ignore[arg-type]
    # If doing so raised *ANY* exception, this object is probably (but *NOT*
    # necessarily) *NOT* runtime-checkable. Disambiguate these two cases and, in
    # all likelihood, raise a human-readable exception.
    #
    # See the docstring for further discussion.
    except Exception as exception:
        # If this exception ambiguously fails to indicate non-isinstanceability,
        # silently reduce to a noop.
        if _is_exception_ambiguous(exception):
            return
        # Else, this exception unambiguously indicates non-isinstanceability.
        #
        # If this exception already human-readably describes this
        # non-isinstanceability, re-raise this exception as is.
        elif _is_exception_sufficient(exception):
            raise
        # Else, this exception fails to human-readably describe this
        # non-isinstanceability.

        # Validate sanity.
        assert isinstance(exception_cls, type), (
            f'{repr(exception_cls)} not exception class.')
        assert isinstance(exception_prefix, str), (
            f'{repr(exception_prefix)} not string.')

        # Avoid circular import dependencies.
        from beartype._util.hint.pep.utilpepget import get_hint_pep_childs
        from beartype._util.text.utiltextlabel import (
            label_exception_traceback)
        from beartype._util.utilobjget import (
            get_object_type_basename,
            get_object_type_name,
        )

        # Unqualified basename of this builtin tester.
        builtin_tester_basename = builtin_tester.__name__

        # Unqualified basename of the PEP 3119-compliant dunder method of the
        # metaclass raising this exception corresponding to this builtin tester.
        metaclass_tester_basename = (
            '__instancecheck__'
            if builtin_tester is isinstance else
            '__subclasscheck__'
        )

        # Unqualified basename of the type of this exception.
        exception_type_basename = get_object_type_basename(exception)

        # Human-readable traceback formatted from this exception, indented to
        # improve readability when embedded below.
        exception_traceback = label_exception_traceback(exception)

        # Human-readable substring describing this object.
        message_prefix: str = None  # type: ignore[assignment]

        # Human-readable substring identifying the child item of this parent
        # container responsible for this failure (if any) *OR* the empty string
        # (e.g., if this object is either not a container *OR* is a container
        # but no culprit item can be found).
        message_clause_prefix = ''

        # PEP 3119-noncompliant object directly responsible for raising this
        # exception, defaulting to this object itself.
        obj_culprit = obj

        # If this object is a type, label this object accordingly.
        if isinstance(obj, type):
            message_prefix = 'type hint '
        # Else, this object is *NOT* a type. By process of elimination and
        # validation above, this object *MUST* be either a tuple of types *OR*
        # PEP 604-compliant new union. In either case, detect the first child
        # item of this parent container responsible for preventing this entire
        # container from being runtime-checkable. Specifically...
        else:
            # Tuple of all items of this container.
            obj_items: tuple = None  # type: ignore[assignment]

            # Human-readable label describing the first non-runtime-checkable
            # child item of this parent container.
            obj_item_prefix: str = None  # type: ignore[assignment]

            # If this object is a tuple, define these locals accordingly.
            if isinstance(obj, tuple):
                message_prefix = 'non-PEP tuple union type hint '
                obj_items = obj
                obj_item_prefix = 'tuple union item '
            # Else, this object is a new union. Define these locals accordingly.
            else:
                message_prefix = 'PEP 604 new union type hint '
                obj_items = get_hint_pep_childs(obj)
                obj_item_prefix = 'new union child '

            # For the 0-based index of each item of this container and that
            # item...
            for obj_item_index, obj_item in enumerate(obj_items):
                # If this item is *NOT* a runtime-checkable type...
                #
                # Note that this tester is memoized and thus requires parameters
                # be only passed positionally.
                if not type_tester(obj_item, is_ref_proxy_valid):
                    # This item is the culprit! Found him, boys.
                    obj_culprit = obj_item

                    # Human-readable substring identifying this child item.
                    message_clause_prefix = (
                        f'{obj_item_prefix}{obj_item_index} '
                        f'child type hint {repr(obj_item)} '
                    )

                    # Immediately halt this iteration.
                    break
                # Else, this item is runtime-checkable. Continue to the next.

        # Unqualified basename of this culprit.
        obj_culprit_basename = get_object_type_basename(obj_culprit)

        # Fully-qualified name of the metaclass of this culprit.
        metaclass_name = get_object_type_name(type(obj_culprit))

        # Fully-qualified name of the PEP 3119-compliant dunder method of the
        # metaclass of this culprit.
        metaclass_tester_name = (
            f'{metaclass_name}.{metaclass_tester_basename}')

        # Human-readable message to be raised.
        #
        # Note that this exception traceback is implicitly indented by the
        # lower-level function creating this traceback called above.
        exception_message = (
            f'{exception_prefix}'
            f'{message_prefix}{repr(obj)} uncheckable at runtime, as '
            f'{message_clause_prefix}'
            f'metaclass {metaclass_tester_name}() dunder method raises '
            f'unexpected "{exception_type_basename}: {exception}":\n'
            f'    >>> {builtin_tester_basename}({builtin_tester_pith}, {obj_culprit_basename})\n'
            f'{exception_traceback}'
        )

        # Raise this exception chained onto this lower-level exception.
        raise exception_cls(exception_message) from exception

# ....................{ PRIVATE ~ testers                  }....................
#FIXME: Unit test us up, please. *sigh*
def _is_object_checkable(
    obj: object,
    is_ref_proxy_valid: bool,
    type_tester: Callable,
    builtin_tester: _NontypeTester,
    builtin_tester_pith: object,
) -> TypeIs[Pep3119Checkable]:
    '''
    :data:`True` only if the passed object is **runtime-checkable** (i.e., valid
    as the second parameter to either the :func:`isinstance` or
    :func:`issubclass` builtins) according to the passed tester callables.

    This tester is intentionally *not* memoized (e.g., by the
    ``@callable_cached`` decorator), due to all higher-level testers calling
    this lower-level tester already being memoized.

    Parameters
    ----------
    obj : object
        Object to be validated.
    is_ref_proxy_valid : bool
        :data:`True` only if this function permits this object to be a
        **forward reference proxy** (i.e., :mod:`beartype`-specific private type
        proxying an external type hint that may currently be undefined). See the
        :func:`.die_unless_object_isinstanceable` raiser for further details.
    type_tester : Callable
        Callable returning :data:`True` only if this object is a
        runtime-checkable type according to this predicate, which should be
        either:

        * :func:`.is_type_isinstanceable`.
        * :func:`.is_type_issubclassable`.
    builtin_tester : Callable[[object, Pep3119Checkable], bool]
        Callable returning :data:`True` only if this object is a
        runtime-checkable non-type according to this predicate, which should be
        either:

        * :func:`isinstance`.
        * :func:`issubclass`.
    builtin_tester_pith : object
        Object guaranteed to satisfy the ``builtin_tester`` callable when
        ``obj`` is **runtime-typecheckable** -- that is, when ``builtin_tester``
        is called as ``builtin_tester(builtin_tester_pith, obj)``.

    Raises
    ------
    exception_cls
        If this object is *not* runtime-checkable according to the passed
        object tester and raiser.
    '''
    assert callable(type_tester), f'{repr(type_tester)} uncallable.'

    # Avoid circular import dependencies.
    from beartype._util.cls.utilclstest import is_type_or_types
    from beartype._util.hint.pep.proposal.pep484.pep484604union import (
        is_hint_pep604)

    # If it is *NOT* the case that...
    if not (
        # This object is a PEP 604-compliant new union *OR*...
        #
        # Note that this test trivially reduces to an efficient one-liner and is
        # thus intentionally tested first.
        is_hint_pep604(obj) or
        # This object is either a type or tuple of types.
        #
        # Note that this test is computationally expensive (even despite being
        # memoized) and is thus intentionally tested last.
        is_type_or_types(obj)
    ):
        return False
    # Else, this object is either a type, tuple of types, *OR* PEP 604-compliant
    # new union. In all three of these cases, this object *COULD* now be
    # runtime-checkable. Further detection is required to decide.
    #
    # If this object is a type...
    elif isinstance(obj, type):
        # Return true only if this type is runtime-checkable.
        #
        # Note that this tester is memoized and thus requires parameters be
        # only passed positionally.
        return type_tester(obj, is_ref_proxy_valid)
    # Else, this object *MUST* (by process of elimination and validation above)
    # be either a tuple of types *OR* a PEP 604-compliant new union.

    # Defer to this lower-level general-purpose tester.
    return _is_object_builtin_checkable(
        obj=obj,
        builtin_tester=builtin_tester,
        builtin_tester_pith=builtin_tester_pith,
    )


#FIXME: Unit test us up, please. *sigh*
def _is_type_checkable(
    cls: object,
    is_ref_proxy_valid: bool,
    builtin_tester: _NontypeTester,
    builtin_tester_pith: object,
) -> TypeIs[type]:
    '''
    :data:`True` only if the passed object is a **runtime-checkable type** (i.e.,
    type that is safely passable without raising exceptions when passed as the
    second parameter) with respect to the passed **builtin tester** (i.e.,
    either the :func:`isinstance` or :func:`issubclass` builtin).

    This tester is intentionally *not* memoized (e.g., by the
    ``@callable_cached`` decorator), due to all higher-level testers calling
    this lower-level tester already being memoized.

    Parameters
    ----------
    cls : object
        Type to be tested.
    is_ref_proxy_valid : bool
        :data:`True` only if this function permits this object to be a
        **forward reference proxy** (i.e., :mod:`beartype`-specific private type
        proxying an external type hint that may currently be undefined). See the
        :func:`.die_unless_object_isinstanceable` raiser for further details.
    builtin_tester : Callable[[object, Pep3119Checkable], bool]
        Callable returning :data:`True` only if this type is runtime-checkable
        according to this predicate, which should be either:

        * :func:`isinstance`.
        * :func:`issubclass`.
    builtin_tester_pith : object
        Object guaranteed to satisfy the ``builtin_tester`` callable when
        ``cls`` is **runtime-typecheckable** -- that is, when ``builtin_tester``
        is called as ``builtin_tester(builtin_tester_pith, cls)``.

    Returns
    -------
    bool
        :data:`True` only if this object is a runtime-checkable type.

    See Also
    --------
    :func:`.die_unless_type_issubclassable`
    :func:`.is_type_isinstanceable`
        Further details.
    '''
    assert isinstance(is_ref_proxy_valid, bool), (
        f'{repr(is_ref_proxy_valid)} not bool.')

    # Avoid circular import dependencies.
    from beartype._check.forward.reference.fwdreftest import (
        is_beartype_ref_proxy)

    # If this object is *NOT* a class, immediately return false.
    if not isinstance(cls, type):
        return False
    # Else, this object is a class.
    #
    # If the caller allows this class to be a forward reference proxy type
    # regardless of whether the external type this proxy refers to has been
    # defined yet and this class is such a type, immediately return true.
    #
    # Note that this test is efficient and thus tested *BEFORE*
    # isinstanceability, which is less efficient.
    elif is_ref_proxy_valid and is_beartype_ref_proxy(cls):
        return True
    # Else, either the caller prefers to disregard this distinction *OR* this
    # class is not a forward reference proxy type.

    # Defer to this lower-level general-purpose tester.
    return _is_object_builtin_checkable(
        obj=cls,
        builtin_tester=builtin_tester,
        builtin_tester_pith=builtin_tester_pith,
    )


#FIXME: Unit test us up, please. *sigh*
def _is_object_builtin_checkable(
    obj: object,
    builtin_tester: _NontypeTester,
    builtin_tester_pith: object,
) -> TypeIs[Pep3119Checkable]:
    '''
    :data:`True` only if the passed object is **runtime-checkable** (i.e.,
    safely passable without raising exceptions when passed as the second
    parameter) with respect to the passed **builtin tester** (i.e., either the
    :func:`isinstance` or :func:`issubclass` builtin).

    This tester is intentionally *not* memoized (e.g., by the
    ``@callable_cached`` decorator), due to all higher-level testers calling
    this lower-level tester already being memoized.

    Parameters
    ----------
    obj : object
        Object to be validated.
    builtin_tester : Callable[[object, Pep3119Checkable], bool]
        Callable returning :data:`True` only if this object is runtime-checkable
        according to this predicate, which should be either:

        * :func:`isinstance`.
        * :func:`issubclass`.
    builtin_tester_pith : object
        Object guaranteed to satisfy the ``builtin_tester`` callable when
        ``obj`` is **runtime-typecheckable** -- that is, when ``builtin_tester``
        is called as ``builtin_tester(builtin_tester_pith, obj)``.

    Raises
    ------
    exception_cls
        If this object is *not* runtime-checkable according to the passed
        object tester and raiser.
    '''
    assert callable(builtin_tester), f'{repr(builtin_tester)} uncallable.'

    #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    # CAUTION: Synchronize with _die_unless_object_builtin_checkable().
    #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    # Attempt to pass this object as the second parameter to this builtin tester
    # to decide whether or not this object is safely runtime-checkable or not.
    #
    # Note that this leverages an EAFP (i.e., "It is easier to ask forgiveness
    # than permission") approach and thus imposes a minor performance penalty,
    # but that there exists *NO* faster alternative applicable to arbitrary
    # user-defined objects, whose metaclasses may define an __instancecheck__()
    # dunder method to raise exceptions and thus prohibit being passed as the
    # second parameter to this builtin tester, the primary means employed by
    # @beartype wrapper functions to check arbitrary hints.
    try:
        builtin_tester(builtin_tester_pith, obj)  # type: ignore[arg-type]
    # If doing so raised *ANY* exception, return true only if this exception
    # ambiguously suggests that this object could still be
    # runtime-checkable.
    except Exception as exception:
        return _is_exception_ambiguous(exception)

    # Return true, as the prior call to this builtin tester raised *NO* exception,
    # implying this object to probably (but *NOT* necessarily) be
    # runtime-checkable.
    return True

# ....................{ PRIVATE ~ testers : exception      }....................
#FIXME: Unit test us up, please.
def _is_exception_ambiguous(exception: Exception) -> bool:
    '''
    :data:`True` only if the passed exception is **ambiguous** (i.e., an
    instance of the standard :exc:`AttributeError` or :exc:`NameError` types).

    Equivalently, this tester returns :data:`True` only if it cannot be decided
    whether this exception unambiguously signifies the failure of an associated
    class to be isinstanceable or issubclassable when the metaclass of this
    class defines the ``__instancecheck__()`` or ``__subclasscheck__()`` dunder
    method raising this exception. Why? Because that metaclass may *not*
    necessarily be fully initialized at the early time that this tester is
    called (typically, at :func:`beartype.beartype` decoration time). When this
    is the case, eagerly passing this class to the :func:`isinstance` or
    :func:`issubclass` builtins is likely to raise an :exc:`AttributeError`
    after referencing an undefined external attribute: e.g.,

    .. code-block:: python

       from beartype import beartype

       class MetaFoo(type):
           def __instancecheck__(cls, other):
               return g()

       class Foo(metaclass=MetaFoo):
           pass

       # @beartype transitively calls this function to validate that "Foo" is
       # isinstanceable. However, since g() has yet to be defined at this time,
       # doing so raises an "AttributeError" exception despite this logic
       # otherwise being sound.
       @beartype
       def f(x: Foo):
           pass

       def g():
           return True

    Parameters
    ----------
    exception : Exception
        Exception previously raised by a recent call to either the
        ``__instancecheck__()`` or ``__subclasscheck__()`` dunder method defined
        by the metaclass of the class passed as the second parameter to the
        :func:`isinstance` or :func:`issubclass` builtins.

    Returns
    -------
    bool
        :data:`True` only if this exception is ambiguous.
    '''

    # Faster than one-liner speed!
    return isinstance(exception, TYPES_EXCEPTION_NAMESPACE)


def _is_exception_sufficient(exception: Exception) -> bool:
    '''
    :data:`True` only if the passed exception is **sufficient** (i.e., an
    instance of the :mod:`beartype`-specific
    :exc:`._BeartypeHintForwardRefExceptionMixin` type).

    Equivalently, this tester returns :data:`True` only if this exception's
    message already suffices to human-readably describe the failure of an
    associated class to be isinstanceable or issubclassable when the metaclass
    of this class defines the ``__instancecheck__()`` or ``__subclasscheck__()``
    dunder method raising this exception. Currently, this includes *all*
    exceptions pertaining to :mod:`beartype`-specific forward references. Why?
    Because these exceptions already convey the issue. Wrapping these exceptions
    in additional exceptions only obfuscates the underlying issue: e.g.,

    .. code-block:: python

       # This original exception...
       BeartypeCallHintForwardRefException: Forward reference "OfPearl"
       unimportable from module
       "beartype_test.a00_unit.data.pep.pep563.data_pep563_resolve".

       # ...is considerably more useful to end users than this insane wrapper.
       beartype.roar.BeartypeDecorHintNonpepException: Die_if_unbearable()
       <forwardref OfPearl(__hint_name_beartype__='OfPearl',
       __scope_name_beartype__='beartype_test.a00_unit.data.pep.pep563.data_pep563_resolve')>
       uncheckable at runtime (i.e., not passable as second parameter to
       isinstance(), due to raising "BeartypeCallHintForwardRefException:
       Forward reference "OfPearl" unimportable from module
       "beartype_test.a00_unit.data.pep.pep563.data_pep563_resolve"." from
       metaclass BeartypeForwardRefMetaclass.__instancecheck__() method).

    Parameters
    ----------
    exception : Exception
        Exception previously raised by a recent call to either the
        ``__instancecheck__()`` or ``__subclasscheck__()`` dunder method defined
        by the metaclass of the class passed as the second parameter to the
        :func:`isinstance` or :func:`issubclass` builtins.

    Returns
    -------
    bool
        :data:`True` only if this exception is sufficient.
    '''

    # Fear the one-liner reaper!
    return isinstance(exception, _BeartypeHintForwardRefExceptionMixin)
